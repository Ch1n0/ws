-- ═══════════════════════════════════════════════════════════════════════════════
--  AO Chat — Migración 005: Favoritos, mensajes programados, backup, mantenimiento
--  Idempotente: usa IF NOT EXISTS / ON CONFLICT DO NOTHING
-- ═══════════════════════════════════════════════════════════════════════════════

-- ── Mensajes favoritos ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS message_favorites (
    user_id    UUID NOT NULL REFERENCES users(id)    ON DELETE CASCADE,
    message_id UUID NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (user_id, message_id)
);
CREATE INDEX IF NOT EXISTS idx_favs_user ON message_favorites(user_id, created_at DESC);

-- ── Mensajes programados (sistema) ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS scheduled_messages (
    id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_id    UUID NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
    content    TEXT NOT NULL,
    cron_expr  VARCHAR(64) NOT NULL,  -- expresión cron: '0 9 * * *'
    is_active  BOOLEAN NOT NULL DEFAULT TRUE,
    created_by UUID REFERENCES users(id),
    last_run   TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Log de backups ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS db_backups (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    filename    VARCHAR(255) NOT NULL,
    size_bytes  BIGINT DEFAULT 0,
    created_by  UUID REFERENCES users(id),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    note        TEXT
);

-- ── Settings nuevos ───────────────────────────────────────────────────────────
INSERT INTO settings (key, value) VALUES
    ('maintenance_mode',      'false'),
    ('maintenance_message',   'El servidor está en mantenimiento. Volvé pronto.'),
    ('backup_schedule',       ''),
    ('backup_retention_days', '7'),
    ('backup_dir',            '')
ON CONFLICT (key) DO NOTHING;

-- ── Permisos ──────────────────────────────────────────────────────────────────
GRANT ALL PRIVILEGES ON TABLE message_favorites   TO ao_admin;
GRANT ALL PRIVILEGES ON TABLE scheduled_messages  TO ao_admin;
GRANT ALL PRIVILEGES ON TABLE db_backups          TO ao_admin;
