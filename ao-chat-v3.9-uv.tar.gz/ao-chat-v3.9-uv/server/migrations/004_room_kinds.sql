-- Migration 004: New room kinds (docs + web) + bug fix columns
-- Run this against your PostgreSQL database

-- Add kind column: 'chat' (default), 'docs', 'web'
ALTER TABLE rooms ADD COLUMN IF NOT EXISTS kind VARCHAR(16) NOT NULL DEFAULT 'chat'
    CHECK (kind IN ('chat','docs','web'));

-- Add embed_url for 'web' rooms
ALTER TABLE rooms ADD COLUMN IF NOT EXISTS embed_url TEXT;

-- Add upload_permission for 'docs' rooms: 'all' = any member, 'staff' = admin/mod only
ALTER TABLE rooms ADD COLUMN IF NOT EXISTS upload_permission VARCHAR(16) NOT NULL DEFAULT 'all'
    CHECK (upload_permission IN ('all','staff'));

-- Add slow_mode_sec and admin_only if missing (defensive)
ALTER TABLE rooms ADD COLUMN IF NOT EXISTS slow_mode_sec INT NOT NULL DEFAULT 0;
ALTER TABLE rooms ADD COLUMN IF NOT EXISTS admin_only BOOLEAN NOT NULL DEFAULT false;

-- Mark existing rooms as kind='chat'
UPDATE rooms SET kind = 'chat' WHERE kind IS NULL OR kind = '';

-- Index for docs room file queries
CREATE INDEX IF NOT EXISTS idx_files_room_id ON files(room_id) WHERE room_id IS NOT NULL;

-- Add deleted_at to files (needed for docs room document listing)
ALTER TABLE files ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;
CREATE INDEX IF NOT EXISTS idx_files_room ON files(room_id, created_at DESC) WHERE deleted_at IS NULL;

-- FK safety: rooms can now be deleted even with associated files/connections
-- (files just lose their room reference, connections are cleared on disconnect anyway)
-- These ALTER TABLE commands are safe to run multiple times (they are no-ops if already correct)
-- Note: PostgreSQL doesn't support ALTER CONSTRAINT directly, so we recreate the FK
DO $$ BEGIN
    -- Drop old FK on files.room_id if it exists without SET NULL, recreate with SET NULL
    ALTER TABLE files DROP CONSTRAINT IF EXISTS files_room_id_fkey;
    ALTER TABLE files ADD CONSTRAINT files_room_id_fkey
        FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE SET NULL;

    ALTER TABLE active_connections DROP CONSTRAINT IF EXISTS active_connections_room_id_fkey;
    ALTER TABLE active_connections ADD CONSTRAINT active_connections_room_id_fkey
        FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE SET NULL;
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'FK migration: %', SQLERRM;
END $$;
