'use strict';
const path = require('path');
const fs   = require('fs');
const DIR  = __dirname;

require('dotenv').config({ path: path.join(DIR, '.env') });

process.on('uncaughtException', (err) => {
    try { fs.appendFile(path.join(DIR,'logs','error.log'),
        `[${new Date().toISOString()}] UNCAUGHT: ${err.stack||err.message}\n`, ()=>{}); } catch(_){}
});
process.on('unhandledRejection', (r) => {
    try { fs.appendFile(path.join(DIR,'logs','error.log'),
        `[${new Date().toISOString()}] REJECTION: ${r}\n`, ()=>{}); } catch(_){}
});

const express    = require('express');
const http       = require('http');
const { Server } = require('socket.io');
const compress   = require('compression');
const cors       = require('cors');
const rateLimit  = require('express-rate-limit');
const logger     = require('./config/logger');
const { pool }   = require('./config/db');
const redis      = require('./config/redis');

// ── Ultraviolet — Bare Server ─────────────────────────────────────────────────
// Maneja las peticiones HTTPS del Service Worker de UV (/bare/...).
// Corre como middleware Express — Socket.IO maneja sus propios upgrades sin interferencia.
let bare = null;
try {
    const { createBareServer } = require('@tomphttp/bare-server-node/dist/createServer.js');
    bare = createBareServer('/bare/');
    logger.info('Bare Server (UV) activo en /bare/');
} catch (e) {
    logger.warn(`Bare Server no disponible: ${e.message}`);
}

const LOGS_DIR = process.env.LOGS_DIR  || path.join(DIR,'logs');
const UPLOADS  = process.env.UPLOAD_DIR || path.join(DIR,'uploads');
[LOGS_DIR,UPLOADS].forEach(d => { try { fs.mkdirSync(d,{recursive:true,mode:0o750}); } catch(_){} });
const ACCESS_LOG = path.join(LOGS_DIR,'access.log');

const PORT = parseInt(process.env.PORT||'8080',10);
const app  = express();
const srv  = http.createServer(app);

// BUG FIX: origin:'*' + credentials:true is rejected by browsers.
// Use explicit allowlist from env (comma-separated) or reflect Origin (safe behind same-domain proxy).
const ALLOWED_ORIGINS = process.env.ALLOWED_ORIGINS
    ? process.env.ALLOWED_ORIGINS.split(',').map(s => s.trim())
    : true;

const io = new Server(srv, {
    cors:{ origin: ALLOWED_ORIGINS, credentials: true },
    pingTimeout:60000, pingInterval:25000,
    maxHttpBufferSize:10*1024*1024,
});

app.set('trust proxy',1);
// Security headers
app.use((_req,res,next)=>{
    res.setHeader('X-Content-Type-Options','nosniff');
    res.setHeader('X-Frame-Options','SAMEORIGIN');
    res.setHeader('X-XSS-Protection','1; mode=block');
    res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');
    res.removeHeader('X-Powered-By');
    next();
});
app.use(compress());
app.use(express.json({limit:'10mb'}));
app.use(express.urlencoded({extended:true,limit:'10mb'}));
app.use(cors({origin: ALLOWED_ORIGINS, credentials:true}));

const rl = (max,w=15) => rateLimit({
    windowMs:w*60*1000, max, standardHeaders:true, legacyHeaders:false,
    message:{error:'Demasiadas solicitudes. Intentá más tarde.'},
    skip: (req) => req.ip === '127.0.0.1' || req.ip === '::1',
});
app.use('/api/',            rl(500, 15));
app.use('/api/auth/',       rl(20,  15));
app.use('/api/files/',      rl(60,  15));
app.use('/api/admin/',      rl(200, 15));
app.use('/api/web-proxy/',  rl(120, 15));   // web-proxy

// Logger HTTP — BUG FIX: use async appendFile, not appendFileSync (blocked event loop)
app.use((req,res,next) => {
    const t=Date.now();
    res.on('finish',()=>{
        const l=`"${req.method} ${req.path} ${res.statusCode} ${Date.now()-t}ms" ${req.ip}`;
        logger.http(l);
        fs.appendFile(ACCESS_LOG,`${new Date().toISOString()} ${l}\n`, ()=>{});
    });
    next();
});

// Bare Server como middleware — NO modifica el http.createServer
// para no interferir con los upgrades WebSocket de Socket.IO
if (bare) {
    app.use((req, res, next) => {
        if (bare.shouldRoute(req)) return bare.routeRequest(req, res);
        next();
    });
    srv.on('upgrade', (req, socket, head) => {
        if (bare.shouldRoute(req)) bare.routeUpgrade(req, socket, head);
        // Si no es bare → Socket.IO lo maneja solo
    });
}

app.use(require('./middleware/ipBan').ipBanCheck);

// Rutas
app.use('/api/auth',        require('./routes/auth'));
app.use('/api/users',       require('./routes/users'));
app.use('/api/rooms',       require('./routes/rooms'));
app.use('/api/messages',    require('./routes/messages'));
app.use('/api/files',       require('./routes/files'));
app.use('/api/admin',       require('./routes/admin'));
app.use('/api/audit',       require('./routes/audit'));
app.use('/api/settings',    require('./routes/settings'));
app.use('/api/polls',       require('./routes/polls'));
app.use('/api/reactions',   require('./routes/reactions'));
app.use('/api/dm',          require('./routes/dm'));
app.use('/api/warnings',    require('./routes/warnings'));
app.use('/api/leaderboard', require('./routes/leaderboard'));
app.use('/api/search',      require('./routes/search'));
app.use('/api/tunnel',      require('./routes/tunnel'));
app.use('/api/roles',       require('./routes/roles'));       // BUG FIX: removed duplicate
app.use('/api/link-preview',require('./routes/linkpreview')); // OG preview cards
app.use('/api/web-proxy',   require('./routes/webproxy'));    // proxy para salas web

app.get('/api/health', async (req,res) => {
    const db = await pool.query('SELECT 1').then(()=>'ok').catch(e=>e.message);
    const rd = await redis.ping().then(()=>'ok').catch(e=>e.message);
    res.json({status:(db==='ok'&&rd==='ok')?'ok':'degraded',db,redis:rd,
              uptime:Math.round(process.uptime()),port:PORT,version:'3.8.0'});
});

const PUB = path.join(DIR,'public');

// Ultraviolet: bundle + SW + bare-mux desde node_modules
try {
    const UV   = path.join(DIR,'node_modules','@titaniumnetwork-dev','ultraviolet','dist');
    const BMUX = path.join(DIR,'node_modules','@mercuryworkshop','bare-mux','dist');
    if (require('fs').existsSync(UV))   app.use('/uv',       require('express').static(UV,   {maxAge:'1h'}));
    if (require('fs').existsSync(BMUX)) app.use('/bare-mux', require('express').static(BMUX, {maxAge:'1h'}));
} catch(_) {}

app.use('/assets', require('express').static(path.join(PUB,'assets'),{maxAge:'1h', etag:true}));
app.use('/admin',  express.static(path.join(PUB,'admin')));
app.use(express.static(PUB));
app.get('*',(req,res)=>{
    if (req.path.startsWith('/api/')) return res.status(404).json({error:'No encontrado'});
    if (req.path.startsWith('/admin')) return res.redirect('/');
    res.sendFile(path.join(PUB,'index.html'));
});
// eslint-disable-next-line no-unused-vars
app.use((err,req,res,_n)=>{
    logger.error(`${err.message} — ${req.method} ${req.path}`);
    if (!res.headersSent) res.status(err.status||500).json({error:'Error interno'});
});

io.use(require('./middleware/socketAuth').socketAuth);
require('./socket/chatHandler')(io);
require('./socket/adminHandler')(io);
require('./services/ddnsService').startCron().catch(e=>logger.warn('DDNS: '+e.message));
require('./services/schedulerService').start(io).catch(e=>logger.warn('Scheduler: '+e.message));

srv.listen(PORT,'0.0.0.0',()=>{
    logger.info(`AO Chat v3.9-UV — puerto ${PORT} — ${DIR}`);
});

const shutdown = (sig) => {
    logger.info(sig+' — cerrando...');
    pool.query('TRUNCATE TABLE active_connections').catch(()=>{});
    srv.close(()=>{ pool.end().catch(()=>{}); redis.quit().catch(()=>{}); process.exit(0); });
    setTimeout(()=>process.exit(0),6000).unref();
};
process.on('SIGTERM',()=>shutdown('SIGTERM'));
process.on('SIGINT', ()=>shutdown('SIGINT'));
module.exports={app,io};
