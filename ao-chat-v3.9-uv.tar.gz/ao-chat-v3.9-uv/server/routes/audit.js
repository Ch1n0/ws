'use strict';
const router   = require('express').Router();
const { pool } = require('../config/db');
const { requireAuth } = require('../middleware/auth');

router.get('/me', requireAuth, async (req, res) => {
    try {
        const { rows } = await pool.query(
            `SELECT action, ip_address, geo_country, geo_city, created_at
             FROM audit_logs
             WHERE user_id = $1
             ORDER BY created_at DESC LIMIT 50`,
            [req.user.id]);
        res.json(rows);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
