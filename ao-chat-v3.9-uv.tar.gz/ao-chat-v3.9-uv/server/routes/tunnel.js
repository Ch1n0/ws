'use strict';
const { spawn, execSync } = require('child_process');
const router   = require('express').Router();
const { requireAuth, requireAdmin } = require('../middleware/auth');

let tunnelProc = null;
let tunnelUrl  = null;
let tunnelLog  = [];
const MAX_LOG  = 80;

function log(line) {
    tunnelLog.push(`[${new Date().toLocaleTimeString()}] ${line}`);
    if (tunnelLog.length > MAX_LOG) tunnelLog.shift();
}

// ── Estado actual ────────────────────────────────────────────────────────────
router.get('/status', requireAuth, requireAdmin, (req, res) => {
    res.json({
        running: !!tunnelProc,
        url:     tunnelUrl,
        log:     tunnelLog.slice(-30),
        pid:     tunnelProc?.pid || null,
    });
});

// ── Iniciar túnel ────────────────────────────────────────────────────────────
router.post('/start', requireAuth, requireAdmin, (req, res) => {
    if (tunnelProc) return res.status(409).json({ error: 'El túnel ya está corriendo', url: tunnelUrl });

    const port = process.env.PORT || '8080';

    // Verificar que cloudflared esté instalado
    try { execSync('which cloudflared', { stdio:'ignore' }); }
    catch {
        return res.status(500).json({
            error: 'cloudflared no está instalado',
            install_cmd: 'curl -fsSL https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o /usr/local/bin/cloudflared && chmod +x /usr/local/bin/cloudflared',
        });
    }

    tunnelUrl = null;
    tunnelLog = [];
    log(`Iniciando túnel en puerto ${port}...`);

    tunnelProc = spawn('cloudflared', ['tunnel', '--url', `http://localhost:${port}`], {
        stdio: ['ignore', 'pipe', 'pipe'],
        detached: false,
    });

    // cloudflared imprime la URL en stderr
    tunnelProc.stderr.on('data', (data) => {
        const text = data.toString();
        text.split('\n').filter(Boolean).forEach(line => {
            log(line);
            // Detectar la URL del túnel
            const m = line.match(/https:\/\/[a-z0-9\-]+\.trycloudflare\.com/);
            if (m && !tunnelUrl) {
                tunnelUrl = m[0];
                log(`✓ URL del túnel: ${tunnelUrl}`);
            }
        });
    });
    tunnelProc.stdout.on('data', (data) => {
        data.toString().split('\n').filter(Boolean).forEach(line => log(line));
    });

    tunnelProc.on('exit', (code, signal) => {
        log(`Túnel terminado (código ${code || signal})`);
        tunnelProc = null;
        tunnelUrl  = null;
    });
    tunnelProc.on('error', (err) => {
        log(`Error: ${err.message}`);
        tunnelProc = null;
        tunnelUrl  = null;
    });

    // Esperar hasta 20s para que aparezca la URL
    let waited = 0;
    const check = setInterval(() => {
        waited += 500;
        if (tunnelUrl || waited >= 20000) {
            clearInterval(check);
            res.json({ ok: true, url: tunnelUrl, message: tunnelUrl ? 'Túnel activo' : 'Iniciando... esperá unos segundos' });
        }
    }, 500);
});

// ── Detener túnel ─────────────────────────────────────────────────────────────
router.post('/stop', requireAuth, requireAdmin, (req, res) => {
    if (!tunnelProc) return res.status(404).json({ error: 'No hay túnel activo' });
    try {
        tunnelProc.kill('SIGTERM');
        setTimeout(() => { if (tunnelProc) { tunnelProc.kill('SIGKILL'); tunnelProc = null; tunnelUrl = null; } }, 2000);
        log('Túnel detenido manualmente');
        res.json({ ok: true });
    } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── Logs del túnel ─────────────────────────────────────────────────────────────
router.get('/log', requireAuth, requireAdmin, (req, res) => {
    res.json({ log: tunnelLog });
});

module.exports = router;
