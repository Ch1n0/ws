'use strict';
const router   = require('express').Router();
const { pool } = require('../config/db');
const { requireAuth } = require('../middleware/auth');

router.post('/:messageId', requireAuth, async (req, res) => {
    const { type } = req.body;
    if (!['like','dislike'].includes(type))
        return res.status(400).json({ error: 'Tipo inválido — debe ser like o dislike' });

    const { messageId } = req.params;
    const userId        = req.user.id;

    try {
        const { rows: existing } = await pool.query(
            `SELECT type FROM message_reactions
             WHERE message_id=$1 AND user_id=$2`,
            [messageId, userId]);

        if (existing.length > 0) {
            if (existing[0].type === type) {
                // mismo tipo → quitar reacción (toggle off)
                await pool.query(
                    `DELETE FROM message_reactions
                     WHERE message_id=$1 AND user_id=$2`,
                    [messageId, userId]);
            } else {
                // distinto tipo → cambiar
                await pool.query(
                    `UPDATE message_reactions SET type=$1
                     WHERE message_id=$2 AND user_id=$3`,
                    [type, messageId, userId]);
            }
        } else {
            // nueva reacción
            await pool.query(
                `INSERT INTO message_reactions (message_id, user_id, type)
                 VALUES ($1, $2, $3)`,
                [messageId, userId, type]);
        }

        // Conteos actualizados
        const { rows: [counts] } = await pool.query(
            `SELECT
               COUNT(*) FILTER (WHERE type='like')    AS likes,
               COUNT(*) FILTER (WHERE type='dislike') AS dislikes
             FROM message_reactions WHERE message_id=$1`,
            [messageId]);

        // Voto actual del usuario
        const { rows: mine } = await pool.query(
            `SELECT type FROM message_reactions
             WHERE message_id=$1 AND user_id=$2`,
            [messageId, userId]);

        res.json({
            likes:    parseInt(counts.likes,    10),
            dislikes: parseInt(counts.dislikes, 10),
            my_vote:  mine[0]?.type || null,
        });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

module.exports = router;
