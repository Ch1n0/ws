'use strict';
const router   = require('express').Router();
const { pool } = require('../config/db');
const { requireAuth, requireAdmin } = require('../middleware/auth');

// Permisos disponibles por categoría
const ROLE_PERMS = {
    user: [
        'send_message','send_file','create_poll','vote_poll',
        'react_message','send_dm','use_dice','use_emotes',
    ],
    moderator: [
        'delete_message','mute_user','warn_user','kick_user',
        'view_audit','view_connections','view_ip',
        'purge_room','admin_only_mode',
        // heredan todos los de usuario
        'send_message','send_file','create_poll','vote_poll',
        'react_message','send_dm','use_dice','use_emotes',
    ],
};

// GET /api/roles — leer permisos actuales desde settings
router.get('/', requireAuth, requireAdmin, async (req, res) => {
    try {
        const { rows } = await pool.query(
            `SELECT key, value FROM settings WHERE key LIKE 'perm_%' ORDER BY key`);
        const result = { user: [], moderator: [] };
        for (const { key, value } of rows) {
            if (value !== 'true') continue;
            // perm_user_send_message -> user: send_message
            const m = key.match(/^perm_(user|moderator|mod)_(.+)$/);
            if (!m) continue;
            const role  = m[1] === 'mod' ? 'moderator' : m[1];
            const perm  = m[2];
            if (role in result) result[role].push(perm);
        }
        // Si no hay settings aún, devolver defaults
        if (result.user.length === 0) {
            result.user      = ROLE_PERMS.user;
            result.moderator = ROLE_PERMS.moderator;
        }
        res.json(result);
    } catch(e) { res.status(500).json({ error: e.message }); }
});

// PUT /api/roles — guardar permisos en settings
router.put('/', requireAuth, requireAdmin, async (req, res) => {
    const { user, moderator } = req.body;
    if (!Array.isArray(user) || !Array.isArray(moderator))
        return res.status(400).json({ error: 'Formato inválido' });

    // Whitelist de permisos permitidos para evitar inyección de keys arbitrarias
    const ALLOWED_PERMS = new Set([
        'send_message','send_file','create_poll','vote_poll',
        'react_message','send_dm','use_dice','use_emotes',
        'delete_message','mute_user','warn_user','kick_user',
        'view_audit','view_connections','view_ip',
        'purge_room','admin_only_mode',
    ]);

    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        // Actualizar todos los permisos de user y moderator
        for (const perm of ALLOWED_PERMS) {
            await client.query(
                `INSERT INTO settings(key,value,updated_at) VALUES($1,$2,NOW())
                 ON CONFLICT(key) DO UPDATE SET value=$2, updated_at=NOW()`,
                [`perm_user_${perm}`,      user.includes(perm)       ? 'true' : 'false']);
            await client.query(
                `INSERT INTO settings(key,value,updated_at) VALUES($1,$2,NOW())
                 ON CONFLICT(key) DO UPDATE SET value=$2, updated_at=NOW()`,
                [`perm_moderator_${perm}`,  moderator.includes(perm)  ? 'true' : 'false']);
        }
        await client.query('COMMIT');
        res.json({ ok: true });
    } catch(e) {
        await client.query('ROLLBACK');
        res.status(500).json({ error: e.message });
    } finally { client.release(); }
});

module.exports = router;
