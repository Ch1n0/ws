'use strict';
const router   = require('express').Router();
const { pool } = require('../config/db');
const { requireAuth } = require('../middleware/auth');

router.get('/:roomId', requireAuth, async (req, res) => {
    const q = (req.query.q||'').trim();
    if (q.length < 2) return res.status(400).json({error:'Mínimo 2 caracteres'});
    const limit = Math.min(parseInt(req.query.limit||'30'), 50);
    try {
        const { rows } = await pool.query(`
            SELECT m.id, m.content, m.created_at, m.type,
                   u.username, c.face_id, c.class
            FROM messages m
            JOIN users u ON u.id=m.user_id
            LEFT JOIN characters c ON c.user_id=m.user_id
            WHERE m.room_id=$1 AND m.deleted_at IS NULL
              AND m.type IN ('text','emote','me')
              AND m.content ILIKE $2
            ORDER BY m.created_at DESC LIMIT $3`,
            [req.params.roomId, `%${q}%`, limit]);
        res.json(rows);
    } catch(e) { res.status(500).json({error:e.message}); }
});

module.exports = router;
