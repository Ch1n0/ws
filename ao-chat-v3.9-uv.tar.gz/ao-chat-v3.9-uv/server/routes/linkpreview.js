'use strict';
const router  = require('express').Router();
const https   = require('https');
const http    = require('http');
const { URL } = require('url');
const { requireAuth } = require('../middleware/auth');

const CACHE = new Map(); // simple in-memory cache, keyed by URL
const CACHE_TTL = 10 * 60 * 1000; // 10 min

const ALLOWED_PROTOCOLS = new Set(['https:', 'http:']);

// Fetch raw HTML from a URL (follows one redirect, 5s timeout)
function fetchHTML(rawUrl) {
    return new Promise((resolve, reject) => {
        let parsed;
        try { parsed = new URL(rawUrl); } catch { return reject(new Error('URL inválida')); }
        if (!ALLOWED_PROTOCOLS.has(parsed.protocol)) return reject(new Error('Protocolo no permitido'));

        const lib = parsed.protocol === 'https:' ? https : http;
        const opts = {
            hostname: parsed.hostname,
            port:     parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
            path:     parsed.pathname + parsed.search,
            method:   'GET',
            timeout:  5000,
            headers:  {
                'User-Agent': 'Mozilla/5.0 (compatible; AOChatBot/1.0; +https://ao.chat)',
                'Accept':     'text/html,application/xhtml+xml',
                'Accept-Language': 'es-AR,es;q=0.9,en;q=0.8',
            },
        };

        const req = lib.request(opts, (res) => {
            // Follow one redirect
            if ([301,302,303,307,308].includes(res.statusCode) && res.headers.location) {
                return fetchHTML(res.headers.location).then(resolve).catch(reject);
            }
            const ct = res.headers['content-type'] || '';
            if (!ct.includes('text/html') && !ct.includes('application/xhtml')) {
                return resolve('');
            }
            const chunks = [];
            let total = 0;
            res.on('data', chunk => {
                total += chunk.length;
                if (total > 300 * 1024) { req.destroy(); return; } // cap at 300KB
                chunks.push(chunk);
            });
            res.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
        });

        req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
        req.on('error',   reject);
        req.end();
    });
}

function extractOG(html, rawUrl) {
    const tag = (prop) => {
        const m = html.match(new RegExp(
            `<meta[^>]+(?:property|name)=['"](${prop})['"][^>]+content=['"]([^'"]{0,500})['"]`, 'i'
        )) || html.match(new RegExp(
            `<meta[^>]+content=['"]([^'"]{0,500})['"][^>]+(?:property|name)=['"](${prop})['"]`, 'i'
        ));
        if (!m) return '';
        // handle both capture orderings
        return (m[2] || m[1] || '').trim();
    };

    const title = tag('og:title') || tag('twitter:title') ||
        (html.match(/<title[^>]*>([^<]{0,200})<\/title>/i)?.[1]?.trim() || '');
    const description = tag('og:description') || tag('twitter:description') ||
        tag('description') || '';
    const image = tag('og:image') || tag('twitter:image') || '';
    const siteName = tag('og:site_name') || '';

    // Resolve relative image URLs
    let imageAbs = image;
    if (image && !image.startsWith('http')) {
        try {
            imageAbs = new URL(image, rawUrl).href;
        } catch { imageAbs = ''; }
    }

    return {
        url:      rawUrl,
        title:    title.slice(0, 120),
        description: description.slice(0, 280),
        image:    imageAbs.slice(0, 500),
        site:     siteName.slice(0, 80),
    };
}

// GET /api/link-preview?url=https://...
router.get('/', requireAuth, async (req, res) => {
    const raw = (req.query.url || '').trim();
    if (!raw) return res.status(400).json({ error: 'url requerida' });

    // Check cache
    const cached = CACHE.get(raw);
    if (cached && Date.now() - cached.ts < CACHE_TTL) {
        return res.json(cached.data);
    }

    try {
        const html = await fetchHTML(raw);
        const data = extractOG(html, raw);
        CACHE.set(raw, { ts: Date.now(), data });
        // Evict old entries if cache grows large
        if (CACHE.size > 500) {
            const oldest = [...CACHE.entries()].sort((a,b) => a[1].ts - b[1].ts)[0];
            if (oldest) CACHE.delete(oldest[0]);
        }
        res.json(data);
    } catch (e) {
        res.status(502).json({ error: e.message });
    }
});

module.exports = router;
