'use strict';
const https    = require('https');
const router   = require('express').Router();
const { pool } = require('../config/db');
const { requireAuth, requireAdmin } = require('../middleware/auth');

// Keys de sólo lectura (no se pueden modificar via API)
const READONLY_KEYS = new Set(['server_port']);

// ── GET /api/settings/public ── sin auth ─────────────────────────────────────
router.get('/public', async (req, res) => {
    try {
        const { rows } = await pool.query(
            `SELECT key, value FROM settings
             WHERE key IN ('server_name','server_domain','bg_image_url','chat_bg_image_url','chat_bg_opacity','registration_open','announcement','announcement_updated','login_side','login_gap')`);
        const s = {};
        rows.forEach(r => { s[r.key] = r.value; });
        res.json(s);
    } catch {
        res.json({ server_name:'AO Chat', server_domain:'', bg_image_url:'', chat_bg_image_url:'', chat_bg_opacity:'0.72', registration_open:'true', announcement:'', announcement_updated:'', login_side:'left', login_gap:'3rem' });
    }
});

// ── GET /api/settings ── admin/mod ───────────────────────────────────────────
router.get('/', requireAuth, requireAdmin, async (req, res) => {
    try {
        const { rows } = await pool.query('SELECT key, value, updated_at FROM settings ORDER BY key');
        const s = {};
        rows.forEach(r => {
            const val = r.key === 'cloudflare_api_token' && r.value
                ? r.value.slice(0,6) + '••••••'
                : r.value;
            s[r.key] = { value: val, updated_at: r.updated_at };
        });
        res.json(s);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── PUT /api/settings/:key ────────────────────────────────────────────────────
// Acepta cualquier key siempre que:
// - No esté en READONLY_KEYS
// - Solo contenga letras, números y guión bajo (sin inyección)
router.put('/:key', requireAuth, requireAdmin, async (req, res) => {
    const { key } = req.params;
    const { value } = req.body;

    if (READONLY_KEYS.has(key))
        return res.status(400).json({ error: 'Clave de solo lectura' });
    if (!/^[a-zA-Z0-9_]+$/.test(key))
        return res.status(400).json({ error: 'Nombre de clave inválido' });

    try {
        await pool.query(
            `INSERT INTO settings (key, value, updated_at) VALUES ($1, $2, NOW())
             ON CONFLICT (key) DO UPDATE SET value = $2, updated_at = NOW()`,
            [key, value ?? null]);
        res.json({ ok: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── GET /api/settings/public-ip ──────────────────────────────────────────────
router.get('/public-ip', requireAuth, requireAdmin, (req, res) => {
    const r = https.get('https://api.ipify.org?format=json', { timeout: 5000 }, (resp) => {
        let d = '';
        resp.on('data', c => { d += c; });
        resp.on('end', () => {
            try { res.json(JSON.parse(d)); }
            catch { res.json({ ip: 'No disponible' }); }
        });
    });
    r.on('error', () => res.json({ ip: 'No disponible' }));
    r.on('timeout', () => { r.destroy(); res.json({ ip: 'Timeout' }); });
});

// ── POST /api/settings/ddns-update ───────────────────────────────────────────
router.post('/ddns-update', requireAuth, requireAdmin, async (req, res) => {
    try {
        const result = await require('../services/ddnsService').updateNow();
        res.json(result);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
