'use strict';
const router   = require('express').Router();
const { pool } = require('../config/db');
const { requireAuth } = require('../middleware/auth');

router.get('/:roomId', requireAuth, async (req, res) => {
    const limit  = Math.min(parseInt(req.query.limit  || '60', 10), 100);
    const before = req.query.before;
    try {
        const room = await pool.query(
            'SELECT id, type FROM rooms WHERE id = $1 AND is_active = true',
            [req.params.roomId]);
        if (!room.rows[0])
            return res.status(404).json({ error: 'Sala no encontrada' });
        if (room.rows[0].type === 'admin' &&
            !['admin', 'moderator'].includes(req.user.role))
            return res.status(403).json({ error: 'Sin acceso' });

        // BUG FIX: userId MUST be a fixed positional param, not affected by cursor
        // params: [roomId, limit, userId, ?before]
        const params = [req.params.roomId, limit, req.user.id];
        let cursor = '';
        if (before) { params.push(before); cursor = `AND m.created_at < $${params.length}`; }

        const { rows } = await pool.query(`
            SELECT
                m.id, m.room_id, m.user_id, m.content, m.type,
                m.file_id, m.reply_to_id, m.created_at, m.edited_at,
                u.username, u.role,
                COALESCE(u.level, 1)        AS level,
                u.custom_title,
                c.race,
                c.class                     AS char_class,
                COALESCE(c.face_id, 1)      AS face_id,
                f.original_name             AS file_name,
                f.size_bytes                AS file_size,
                f.mime_type                 AS file_mime,
                -- Reactions aggregated in a single join (faster than 3 subqueries)
                COALESCE(rx.likes, 0)        AS likes,
                COALESCE(rx.dislikes, 0)     AS dislikes,
                rx.my_vote,
                -- Datos del mensaje citado
                rm.content   AS reply_content,
                ru.username  AS reply_username
            FROM messages m
            JOIN  users      u  ON u.id  = m.user_id
            LEFT JOIN characters c  ON c.user_id = m.user_id
            LEFT JOIN files      f  ON f.id = m.file_id
            LEFT JOIN messages   rm ON rm.id = m.reply_to_id
            LEFT JOIN users      ru ON ru.id = rm.user_id
            LEFT JOIN LATERAL (
                SELECT
                    COUNT(*) FILTER (WHERE type='like')               AS likes,
                    COUNT(*) FILTER (WHERE type='dislike')            AS dislikes,
                    MAX(type)  FILTER (WHERE user_id = $3)            AS my_vote
                FROM message_reactions
                WHERE message_id = m.id
            ) rx ON true
            WHERE m.room_id = $1 AND m.deleted_at IS NULL ${cursor}
            ORDER BY m.created_at DESC
            LIMIT $2`,
            params);

        // Transformar reply en objeto anidado igual que el socket
        const msgs = rows.map(r => ({
            ...r,
            likes:    parseInt(r.likes, 10),
            dislikes: parseInt(r.dislikes, 10),
            reply_data: r.reply_to_id && r.reply_username
                ? { username: r.reply_username, content: (r.reply_content||'').slice(0, 80) }
                : null,
        }));

        res.json(msgs);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
