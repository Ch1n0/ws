'use strict';
const router   = require('express').Router();
const { pool } = require('../config/db');
const { requireAuth } = require('../middleware/auth');
const xpSvc    = require('../services/xpService');

// GET /api/polls/by-message/:messageId  — PRIMERO, antes de /:pollId
router.get('/by-message/:messageId', requireAuth, async (req, res) => {
    try {
        const { rows:[poll] } = await pool.query(
            'SELECT * FROM polls WHERE message_id=$1', [req.params.messageId]);
        if (!poll) return res.status(404).json({ error: 'No encontrada' });
        const { rows:opts } = await pool.query(
            'SELECT id,text,votes FROM poll_options WHERE poll_id=$1 ORDER BY id', [poll.id]);
        const { rows:voted } = await pool.query(
            'SELECT option_id FROM poll_votes WHERE poll_id=$1 AND user_id=$2',
            [poll.id, req.user.id]);
        res.json({ ...poll, options: opts, my_vote: voted[0]?.option_id || null });
    } catch(e) { res.status(500).json({ error: e.message }); }
});

// POST /api/polls  — crear encuesta (inserta mensaje + poll en una transacción)
router.post('/', requireAuth, async (req, res) => {
    const { room_id, question, options } = req.body;
    if (!question?.trim() || !Array.isArray(options) || options.length < 2 || options.length > 6)
        return res.status(400).json({ error: 'Se requiere pregunta y entre 2-6 opciones' });
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const { rows:[msg] } = await client.query(
            `INSERT INTO messages(room_id,user_id,content,type) VALUES($1,$2,$3,'poll') RETURNING id,created_at`,
            [room_id, req.user.id, question.trim()]);
        const { rows:[poll] } = await client.query(
            `INSERT INTO polls(message_id,question,created_by) VALUES($1,$2,$3) RETURNING id`,
            [msg.id, question.trim(), req.user.id]);
        for (const opt of options) {
            await client.query('INSERT INTO poll_options(poll_id,text) VALUES($1,$2)',
                [poll.id, opt.toString().trim().slice(0,100)]);
        }
        await client.query('COMMIT');
        const { rows:opts } = await pool.query(
            'SELECT id,text,votes FROM poll_options WHERE poll_id=$1 ORDER BY id', [poll.id]);
        xpSvc.grant(req.user.id, 'poll', null).catch(()=>{});
        res.json({ message_id: msg.id, poll_id: poll.id, question, options: opts, created_at: msg.created_at });
    } catch(e) {
        await client.query('ROLLBACK');
        res.status(500).json({ error: e.message });
    } finally { client.release(); }
});

// POST /api/polls/:pollId/vote
router.post('/:pollId/vote', requireAuth, async (req, res) => {
    const { option_id } = req.body;
    if (!option_id) return res.status(400).json({ error: 'option_id requerido' });
    try {
        const already = await pool.query(
            'SELECT poll_id FROM poll_votes WHERE poll_id=$1 AND user_id=$2',
            [req.params.pollId, req.user.id]);
        if (already.rows.length)
            return res.status(409).json({ error: 'Ya votaste en esta encuesta' });
        const opt = await pool.query(
            'SELECT id FROM poll_options WHERE id=$1 AND poll_id=$2',
            [option_id, req.params.pollId]);
        if (!opt.rows.length)
            return res.status(404).json({ error: 'Opción no encontrada' });
        await pool.query(
            'INSERT INTO poll_votes(poll_id,option_id,user_id) VALUES($1,$2,$3)',
            [req.params.pollId, option_id, req.user.id]);
        await pool.query('UPDATE poll_options SET votes=votes+1 WHERE id=$1', [option_id]);
        const { rows:opts } = await pool.query(
            'SELECT id,text,votes FROM poll_options WHERE poll_id=$1 ORDER BY id',
            [req.params.pollId]);
        xpSvc.grant(req.user.id, 'vote', null).catch(()=>{});
        res.json({ voted: true, options: opts });
    } catch(e) { res.status(500).json({ error: e.message }); }
});

// GET /api/polls/:pollId
router.get('/:pollId', requireAuth, async (req, res) => {
    try {
        const { rows:[poll] } = await pool.query(
            'SELECT * FROM polls WHERE id=$1', [req.params.pollId]);
        if (!poll) return res.status(404).json({ error: 'No encontrada' });
        const { rows:opts } = await pool.query(
            'SELECT id,text,votes FROM poll_options WHERE poll_id=$1 ORDER BY id', [req.params.pollId]);
        const { rows:voted } = await pool.query(
            'SELECT option_id FROM poll_votes WHERE poll_id=$1 AND user_id=$2',
            [req.params.pollId, req.user.id]);
        res.json({ ...poll, options: opts, my_vote: voted[0]?.option_id || null });
    } catch(e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
