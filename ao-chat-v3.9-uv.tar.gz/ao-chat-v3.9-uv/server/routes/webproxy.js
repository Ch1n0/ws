'use strict';
/**
 * Web Room Proxy — GET /api/web-proxy?url=<encoded>&token=<jwt>
 *
 * Único proxy del sistema (proxy.js fue eliminado).
 * Fetchea cualquier URL server-side con UA Firefox real,
 * elimina cabeceras anti-frame, descomprime gzip/br/deflate,
 * e inyecta un script que:
 *   1. Intercepta fetch/XHR para mantener todo dentro del proxy.
 *   2. Hace creer al sitio que NO está en un iframe.
 *   3. Sincroniza título y navegación con la pestaña padre.
 *
 * Auth: Bearer header o ?token= (iframes no pueden enviar headers).
 */

const router   = require('express').Router();
const https    = require('https');
const zlib     = require('zlib');
const jwt      = require('jsonwebtoken');
const { URL }  = require('url');
const { pool } = require('../config/db');
const { requireAuth } = require('../middleware/auth');
const logger   = require('../config/logger');

const FF_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0';
const BLOCKED = new Set(['file:','ftp:','javascript:','data:','about:']);
const MAX_BODY = 12 * 1024 * 1024;
const MAX_REDIR = 6;
const STRIP_RES = new Set([
    'x-frame-options','content-security-policy','content-security-policy-report-only',
    'x-content-type-options','strict-transport-security','cross-origin-opener-policy',
    'cross-origin-embedder-policy','cross-origin-resource-policy',
    'permissions-policy','feature-policy','report-to','nel',
    'expect-ct','public-key-pins','public-key-pins-report-only',
]);

// Auth: Bearer o ?token=
async function inlineAuth(req, res, next) {
    const h = req.headers.authorization || '';
    if (h.startsWith('Bearer ')) return requireAuth(req, res, next);
    const token = (req.query.token || '').trim();
    if (!token) return res.status(401).json({ error: 'Token requerido' });
    try {
        const payload = jwt.verify(token, process.env.JWT_SECRET);
        const { rows } = await pool.query(
            'SELECT id,username,status,role FROM users WHERE id=$1', [payload.sub]);
        if (!rows[0] || rows[0].status !== 'active')
            return res.status(401).json({ error: 'Sesión inválida' });
        req.user = rows[0]; next();
    } catch { return res.status(401).json({ error: 'Token inválido' }); }
}

// Rate limit local (segunda barrera por IP)
const _hits = new Map();
function localRateLimit(req, res, next) {
    const key = req.ip || 'x', now = Date.now(), WIN = 15 * 60_000;
    const r = _hits.get(key) || { n:0, reset:now+WIN };
    if (now > r.reset) { r.n=0; r.reset=now+WIN; }
    if (++r.n > 120) { _hits.set(key,r); return res.status(429).send('Demasiadas peticiones'); }
    _hits.set(key,r); next();
}

// Script inyectado en cada página HTML proxeada
function buildInjection(origin) {
    const px = '/api/web-proxy?url=';
    const base = (() => { try { const u=new URL(origin); return `${u.protocol}//${u.host}/`; } catch { return origin+'/'; } })();
    return `<base href="${base}"/>
<script>
(function(){
  var O=${JSON.stringify(origin)},P=${JSON.stringify(px)},H=location.hostname;
  // 1. Ocultar que está en iframe
  try{['top','parent','frameElement'].forEach(function(k){try{Object.defineProperty(window,k,{get:function(){return k==='frameElement'?null:window;},configurable:true});}catch(e){}});}catch(e){}
  // 2. Enrutar URLs al proxy
  function px(u){try{var s=String(u||'');if(!s||s.startsWith('blob:')||s.startsWith('data:'))return s;if(/^\\/(?!\\/)/.test(s))return P+encodeURIComponent(O+s);if(s.startsWith('//'))return P+encodeURIComponent('https:'+s);try{var r=new URL(s);if(r.hostname===H){if(r.pathname.indexOf('/api/web-proxy')===0)return s;return P+encodeURIComponent(O+r.pathname+r.search+r.hash);}if(r.protocol==='http:'||r.protocol==='https:')return P+encodeURIComponent(s);}catch(e){}}catch(e){}return u;}
  // 3. Interceptar fetch
  var _f=window.fetch;window.fetch=function(i,o){try{if(i instanceof Request){var p=px(i.url);if(p!==i.url)i=new Request(p,i);}else i=px(i);}catch(e){}return _f.call(window,i,o);};
  // 4. Interceptar XHR
  var _x=XMLHttpRequest.prototype.open;XMLHttpRequest.prototype.open=function(m,u,a,n,p){try{u=px(u);}catch(e){}return _x.call(this,m,u,a===undefined?true:a,n,p);};
  // 5. Sincronizar título y navegación con el padre
  try{
    Object.defineProperty(document,'title',{get:function(){var t=document.head&&document.head.querySelector('title');return t?t.textContent:'';},set:function(v){var t=document.querySelector('title');if(!t){t=document.createElement('title');document.head.appendChild(t);}t.textContent=v;try{parent.postMessage({type:'wb-title',title:v},'*');}catch(e){}},configurable:true});
    ['pushState','replaceState'].forEach(function(m){var o=history[m];history[m]=function(s,t,u){o.call(history,s,t,u);try{parent.postMessage({type:'wb-navigate',url:location.href},'*');}catch(e){}};});
    window.addEventListener('hashchange',function(){try{parent.postMessage({type:'wb-navigate',url:location.href},'*');}catch(e){}});
  }catch(e){}
})();
<\/script>`;
}

// Descompresión gzip/deflate/brotli
function decompress(upstream, cb) {
    const enc=(upstream.headers['content-encoding']||'').toLowerCase();
    const chunks=[]; let total=0;
    let s=upstream;
    if(enc==='gzip')    s=upstream.pipe(zlib.createGunzip());
    else if(enc==='deflate') s=upstream.pipe(zlib.createInflate());
    else if(enc==='br') s=upstream.pipe(zlib.createBrotliDecompress());
    s.on('data',c=>{total+=c.length;if(total<=MAX_BODY)chunks.push(c);});
    s.on('end',()=>cb(null,Buffer.concat(chunks)));
    s.on('error',cb);
}

// Fetch con Firefox UA + seguimiento de redirects
function fetchUrl(rawUrl, hops=0) {
    return new Promise((resolve,reject)=>{
        let parsed;
        try{parsed=new URL(rawUrl);}catch{return reject(new Error(`URL inválida: ${rawUrl}`));}
        if(BLOCKED.has(parsed.protocol)) return reject(new Error('Protocolo no permitido'));
        if(parsed.protocol==='http:') parsed.protocol='https:';
        const req=https.request({
            hostname:parsed.hostname, port:parsed.port||443,
            path:parsed.pathname+parsed.search, method:'GET', timeout:14_000,
            headers:{
                'User-Agent':FF_UA,
                'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                'Accept-Language':'es-AR,es;q=0.8,en-US;q=0.5,en;q=0.3',
                'Accept-Encoding':'gzip, deflate, br',
                'Connection':'keep-alive','Upgrade-Insecure-Requests':'1',
                'Sec-Fetch-Dest':'document','Sec-Fetch-Mode':'navigate',
                'Sec-Fetch-Site':'none','Sec-Fetch-User':'?1','DNT':'1',
            },
        }, res=>{
            if([301,302,303,307,308].includes(res.statusCode)&&res.headers.location){
                if(hops>=MAX_REDIR) return reject(new Error('Demasiadas redirecciones'));
                let loc=res.headers.location;
                if(loc.startsWith('//')) loc='https:'+loc;
                else if(loc.startsWith('/')) loc=`https://${parsed.hostname}${loc}`;
                else if(!loc.startsWith('http')) loc=`https://${parsed.hostname}/${loc}`;
                return fetchUrl(loc,hops+1).then(resolve).catch(reject);
            }
            resolve({statusCode:res.statusCode,headers:res.headers,res});
        });
        req.on('timeout',()=>{req.destroy();reject(new Error('El sitio tardó demasiado en responder'));});
        req.on('error',reject);
        req.end();
    });
}

function cleanHeaders(raw) {
    const out={};
    for(const[k,v]of Object.entries(raw)) if(!STRIP_RES.has(k.toLowerCase())) out[k]=v;
    out['x-frame-options']='ALLOWALL';
    out['access-control-allow-origin']='*';
    return out;
}

// Handler principal
router.get('/', inlineAuth, localRateLimit, async (req,res)=>{
    const rawUrl=(req.query.url||'').trim();
    if(!rawUrl) return res.status(400).send('Parámetro url requerido');
    let parsed;
    try{parsed=new URL(rawUrl);}catch{return res.status(400).send('URL inválida');}
    if(BLOCKED.has(parsed.protocol)) return res.status(403).send('Protocolo no permitido');
    const origin=`https://${parsed.host}`;
    try{
        const{statusCode,headers,res:upstream}=await fetchUrl(rawUrl);
        const ct=(headers['content-type']||'').toLowerCase();
        const isHtml=ct.includes('text/html')||ct.includes('xhtml');
        const safe=cleanHeaders(headers);
        if(isHtml){
            delete safe['content-encoding']; delete safe['content-length'];
            res.status(statusCode);
            for(const[k,v]of Object.entries(safe)){try{res.setHeader(k,v);}catch(_){}}
            res.setHeader('content-type','text/html; charset=utf-8');
            decompress(upstream,(err,buf)=>{
                if(err){logger.warn(`webproxy decompress: ${err.message}`);return res.end('<html><body>Error descomprimiendo</body></html>');}
                let html=buf.toString('utf8');
                const inj=buildInjection(origin);
                if(/<head[\s>]/i.test(html)) html=html.replace(/(<head[^>]*>)/i,`$1\n${inj}`);
                else if(/<html[\s>]/i.test(html)) html=html.replace(/(<html[^>]*>)/i,`$1\n${inj}`);
                else html=inj+html;
                res.end(html);
            });
        }else{
            res.status(statusCode);
            for(const[k,v]of Object.entries(safe)){try{res.setHeader(k,v);}catch(_){}}
            upstream.pipe(res);
            upstream.on('error',()=>{if(!res.writableEnded)res.end();});
        }
    }catch(e){
        logger.warn(`webproxy [${rawUrl}]: ${e.message}`);
        const errHtml=`<!DOCTYPE html><html lang="es"><head><meta charset="utf-8">
<style>*{box-sizing:border-box;margin:0;padding:0}body{font-family:system-ui,sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#12141a;color:#ccc;padding:2rem}.box{text-align:center;max-width:400px}h2{color:#e05a5a;font-size:1.3rem;margin-bottom:.8rem}p{color:#888;font-size:.88rem;line-height:1.6;margin-bottom:1.2rem}a{display:inline-block;padding:.5rem 1.2rem;background:#c9a84c;color:#111;border-radius:8px;text-decoration:none;font-weight:600;font-size:.9rem}.url{font-size:.72rem;color:#555;margin-top:1rem;word-break:break-all}</style>
</head><body><div class="box"><h2>🚫 No se pudo cargar</h2><p>${e.message}</p><a href="${rawUrl}" target="_top">Abrir en el navegador directamente</a><div class="url">${rawUrl}</div></div></body></html>`;
        if(!res.headersSent) res.status(502).send(errHtml);
    }
});

module.exports = router;
