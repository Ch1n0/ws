'use strict';
// ── Helpers de validación ─────────────────────────────────────────────────────
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const CIDR_RE = /^(\d{1,3}\.){3}\d{1,3}(\/\d{1,2})?$/;

function validUUID(id) { return UUID_RE.test(id); }
function sanitizeLimit(val, max=100) {
    const n = parseInt(val, 10);
    return isNaN(n) || n < 1 ? 50 : Math.min(n, max);
}
function sanitizePage(val) {
    const n = parseInt(val, 10);
    return isNaN(n) || n < 1 ? 1 : n;
}
function validRole(r) { return ['user','moderator','admin'].includes(r); }
function validStatus(s) { return ['active','pending','suspended','banned'].includes(s); }
function validRoomType(t)  { return ['public','private','admin'].includes(t); }
function validRoomKind(k)  { return ['chat','docs','web'].includes(k); }

const router   = require('express').Router();
const { pool } = require('../config/db');
const redis    = require('../config/redis');
const { requireAuth, requireAdmin } = require('../middleware/auth');
const geoSvc   = require('../services/geoService');

router.use(requireAuth, requireAdmin);

const audit = async (userId, action, targetType, targetId, ip, meta={}) => {
    await pool.query(
        `INSERT INTO audit_logs(user_id,action,target_type,target_id,ip_address,metadata)
         VALUES($1,$2,$3,$4,$5::inet,$6)`,
        [userId,action,targetType,targetId,ip||'127.0.0.1',JSON.stringify(meta)]
    ).catch(()=>{});
};

// ── Dashboard ────────────────────────────────────────────────────────────────
router.get('/dashboard', async (req,res) => {
    try {
        const [users,online,pending,msgs] = await Promise.all([
            pool.query(`SELECT COUNT(*) total,
                COUNT(*) FILTER(WHERE status='active')  active,
                COUNT(*) FILTER(WHERE status='pending') pending,
                COUNT(*) FILTER(WHERE status='banned')  banned,
                COUNT(*) FILTER(WHERE created_at>NOW()-'24h'::interval) new_today FROM users`),
            pool.query('SELECT COUNT(*) online FROM active_connections'),
            pool.query(`SELECT u.id,u.username,u.created_at,c.race,c.class,c.profession,c.face_id
                FROM users u LEFT JOIN characters c ON c.user_id=u.id
                WHERE u.status='pending' ORDER BY u.created_at ASC LIMIT 20`),
            pool.query(`SELECT COUNT(*) total,
                COUNT(*) FILTER(WHERE created_at>NOW()-'24h'::interval) today
                FROM messages WHERE deleted_at IS NULL`),
        ]);
        res.json({ stats:{ users:users.rows[0], online:parseInt(online.rows[0].online,10), messages:msgs.rows[0] }, pendingUsers:pending.rows });
    } catch(e){ res.status(500).json({error:e.message}); }
});

// ── Usuarios ─────────────────────────────────────────────────────────────────
router.get('/users', async (req,res) => {
    const page  = sanitizePage(req.query.page);
    const limit = sanitizeLimit(req.query.limit, 200);
    const { status, search } = req.query;
    const params=[]; let where='WHERE 1=1';
    if (status){ params.push(status); where+=` AND u.status=$${params.length}`; }
    if (search){ params.push(`%${search}%`); where+=` AND u.username ILIKE $${params.length}`; }
    try {
        const { rows } = await pool.query(
            `SELECT u.id,u.username,u.status,u.role,u.created_at,u.last_login,
                    u.ban_reason,u.muted_until,u.mute_reason,
                    c.race,c.gender,c.class,c.profession,c.face_id,
                    (SELECT COUNT(*) FROM messages m WHERE m.user_id=u.id) msg_count,
                    (SELECT ip_address FROM audit_logs a WHERE a.user_id=u.id
                     AND a.action='login_success' ORDER BY a.created_at DESC LIMIT 1) last_ip
             FROM users u LEFT JOIN characters c ON c.user_id=u.id
             ${where} ORDER BY u.created_at DESC
             LIMIT $${params.length+1} OFFSET $${params.length+2}`,
            [...params, limit, (page-1)*limit]);
        const ct = await pool.query(`SELECT COUNT(*) FROM users u ${where}`, params);
        res.json({ users:rows, total:parseInt(ct.rows[0].count,10) });
    } catch(e){ res.status(500).json({error:e.message}); }
});

router.get('/users/:id', async (req,res) => {
    try {
        const [u,logs,conns] = await Promise.all([
            pool.query(`SELECT u.*,c.race,c.gender,c.class,c.profession,c.face_id
                FROM users u LEFT JOIN characters c ON c.user_id=u.id WHERE u.id=$1`,[req.params.id]),
            pool.query(`SELECT * FROM audit_logs WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100`,[req.params.id]),
            pool.query('SELECT * FROM active_connections WHERE user_id=$1',[req.params.id]),
        ]);
        if (!u.rows[0]) return res.status(404).json({error:'No encontrado'});
        res.json({ user:u.rows[0], auditLog:logs.rows, connections:conns.rows });
    } catch(e){ res.status(500).json({error:e.message}); }
});

router.post('/users/:id/approve', async (req,res) => {
    if (!validUUID(req.params.id)) return res.status(400).json({error:'ID inválido'});
    try {
        const { rows } = await pool.query(
            `UPDATE users SET status='active',approved_at=NOW(),approved_by=$2
             WHERE id=$1 AND status='pending' RETURNING username`,[req.params.id,req.user.id]);
        if (!rows[0]) return res.status(404).json({error:'No encontrado o ya activo'});
        await audit(req.user.id,'user_approved','user',req.params.id,req.ip);
        res.json({ ok:true, message:`${rows[0].username} aprobado` });
    } catch(e){ res.status(500).json({error:e.message}); }
});

router.post('/users/:id/ban', async (req,res) => {
    if (req.params.id === req.user.id)
        return res.status(400).json({ error: 'No podés banearte a vos mismo.' });
    const { reason, banIp } = req.body;
    try {
        const { rows } = await pool.query(
            `UPDATE users SET status='banned',ban_reason=$2 WHERE id=$1 RETURNING username`,[req.params.id,reason||null]);
        if (banIp) {
            const ip = await pool.query(
                `SELECT ip_address FROM audit_logs WHERE user_id=$1 AND action='login_success'
                 ORDER BY created_at DESC LIMIT 1`,[req.params.id]);
            if (ip.rows[0]) await pool.query(
                `INSERT INTO ip_bans(ip_address,reason,banned_by) VALUES($1::inet,$2,$3) ON CONFLICT DO NOTHING`,
                [ip.rows[0].ip_address,reason,req.user.id]);
        }
        await audit(req.user.id,'user_banned','user',req.params.id,req.ip,{reason,banIp});
        res.json({ ok:true, username:rows[0]?.username });
    } catch(e){ res.status(500).json({error:e.message}); }
});

router.post('/users/:id/unban', async (req,res) => {
    try {
        await pool.query(`UPDATE users SET status='active',ban_reason=NULL,banned_until=NULL WHERE id=$1`,[req.params.id]);
        await audit(req.user.id,'user_unbanned','user',req.params.id,req.ip);
        res.json({ ok:true });
    } catch(e){ res.status(500).json({error:e.message}); }
});

router.post('/users/:id/suspend', async (req,res) => {
    if (req.params.id === req.user.id)
        return res.status(400).json({ error: 'No podés suspenderte a vos mismo.' });
    const { reason, until } = req.body;
    try {
        await pool.query(`UPDATE users SET status='suspended',ban_reason=$2,banned_until=$3 WHERE id=$1`,[req.params.id,reason||null,until||null]);
        await audit(req.user.id,'user_suspended','user',req.params.id,req.ip,{reason});
        res.json({ ok:true });
    } catch(e){ res.status(500).json({error:e.message}); }
});

// SILENCIAR usuario (no puede enviar mensajes por X tiempo)
router.post('/users/:id/mute', async (req,res) => {
    if (req.params.id === req.user.id)
        return res.status(400).json({ error: 'No podés silenciarte a vos mismo.' });
    const { reason, minutes=30 } = req.body;
    try {
        const until = new Date(Date.now() + parseInt(minutes,10)*60*1000);
        await pool.query(`UPDATE users SET muted_until=$2,mute_reason=$3 WHERE id=$1`,[req.params.id,until,reason||null]);
        await audit(req.user.id,'user_muted','user',req.params.id,req.ip,{reason,minutes});
        res.json({ ok:true, muted_until:until });
    } catch(e){ res.status(500).json({error:e.message}); }
});

router.post('/users/:id/unmute', async (req,res) => {
    try {
        await pool.query(`UPDATE users SET muted_until=NULL,mute_reason=NULL WHERE id=$1`,[req.params.id]);
        await audit(req.user.id,'user_unmuted','user',req.params.id,req.ip);
        res.json({ ok:true });
    } catch(e){ res.status(500).json({error:e.message}); }
});

router.put('/users/:id', async (req,res) => {
    const { role, status, character, custom_title } = req.body;
    try {
        if (role && !validRole(role)) return res.status(400).json({error:'Rol inválido'});
    if (status && !validStatus(status)) return res.status(400).json({error:'Estado inválido'});
    if (role||status) await pool.query(
            `UPDATE users SET role=COALESCE($2,role),status=COALESCE($3,status) WHERE id=$1`,
            [req.params.id,role||null,status||null]);
        if (custom_title !== undefined) await pool.query(
            `UPDATE users SET custom_title=$2 WHERE id=$1`,
            [req.params.id, custom_title||null]);
        if (character) await pool.query(
            `UPDATE characters SET race=COALESCE($2,race),gender=COALESCE($3,gender),
             class=COALESCE($4,class),profession=COALESCE($5,profession),face_id=COALESCE($6,face_id)
             WHERE user_id=$1`,
            [req.params.id,character.race,character.gender,character.class,character.profession,character.face_id]);
        await audit(req.user.id,'user_edited','user',req.params.id,req.ip);
        res.json({ ok:true });
    } catch(e){ res.status(500).json({error:e.message}); }
});

// ── Salas ────────────────────────────────────────────────────────────────────
router.get('/rooms', async (req,res) => {
    try {
        const { rows } = await pool.query(
            `SELECT r.id,r.name,r.slug,r.description,r.type,
                COALESCE(r.kind,'chat') AS kind,
                r.icon,r.topic,r.max_users,r.is_active,r.image_url,
                COALESCE(r.embed_url,'') AS embed_url,
                COALESCE(r.upload_permission,'all') AS upload_permission,
                COALESCE(r.admin_only,false) AS admin_only,
                COALESCE(r.slow_mode_sec,0) AS slow_mode_sec,
                r.created_at,
                (SELECT COUNT(*) FROM room_members rm WHERE rm.room_id=r.id) member_count,
                (SELECT COUNT(*) FROM active_connections ac WHERE ac.room_id=r.id) online_count,
                (SELECT COUNT(*) FROM messages m WHERE m.room_id=r.id AND m.deleted_at IS NULL) msg_count
             FROM rooms r ORDER BY r.created_at ASC`);
        res.json(rows);
    } catch(e){ res.status(500).json({error:e.message}); }
});

router.post('/rooms', async (req,res) => {
    const { name, description, type, kind, icon, max_users, topic,
            image_url, embed_url, upload_permission } = req.body;
    if (!name?.trim()) return res.status(400).json({ error: 'Nombre requerido' });
    if (type && !validRoomType(type)) return res.status(400).json({ error: 'Tipo de acceso inválido' });
    if (kind && !validRoomKind(kind)) return res.status(400).json({ error: 'Tipo de sala inválido' });
    const slug = name.toLowerCase().replace(/\s+/g,'-').replace(/[^a-z0-9-]/g,'');
    try {
        const { rows } = await pool.query(
            `INSERT INTO rooms(name,slug,description,type,kind,icon,max_users,topic,
                               image_url,embed_url,upload_permission,created_by)
             VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
            [name.trim(), slug, description||null, type||'public', kind||'chat',
             icon||'💬', max_users||100, topic||null,
             image_url||null, embed_url||null, upload_permission||'all', req.user.id]);
        await audit(req.user.id,'room_created','room',rows[0].id,req.ip);
        res.json(rows[0]);
    } catch(e){ res.status(500).json({error:e.message}); }
});

router.put('/rooms/:id', async (req,res) => {
    const { name,description,type,kind,icon,max_users,is_active,topic,
            image_url,embed_url,upload_permission,admin_only,slow_mode_sec } = req.body;
    if (kind && !validRoomKind(kind)) return res.status(400).json({ error: 'Tipo de sala inválido' });
    if (type && !validRoomType(type)) return res.status(400).json({ error: 'Tipo de acceso inválido' });
    try {
        const { rows } = await pool.query(
            `UPDATE rooms SET
                name=COALESCE($2,name),
                description=COALESCE($3,description),
                type=COALESCE($4,type),
                kind=COALESCE($5,kind),
                icon=COALESCE($6,icon),
                max_users=COALESCE($7,max_users),
                is_active=COALESCE($8,is_active),
                topic=COALESCE($9,topic),
                image_url=$10,
                embed_url=$11,
                upload_permission=COALESCE($12,upload_permission),
                admin_only=COALESCE($13,admin_only),
                slow_mode_sec=COALESCE($14,slow_mode_sec)
             WHERE id=$1 RETURNING *`,
            [req.params.id, name, description, type, kind, icon, max_users, is_active, topic,
             image_url||null, embed_url||null, upload_permission, admin_only, slow_mode_sec]);
        await audit(req.user.id,'room_edited','room',req.params.id,req.ip,{kind});
        res.json(rows[0]);
    } catch(e){ res.status(500).json({error:e.message}); }
});

router.delete('/rooms/:id', async (req,res) => {
    try {
        // Nullify FK refs that lack CASCADE (files, active_connections) before deleting
        await pool.query('UPDATE files SET room_id=NULL WHERE room_id=$1',[req.params.id]);
        await pool.query('UPDATE active_connections SET room_id=NULL WHERE room_id=$1',[req.params.id]);
        await pool.query('DELETE FROM rooms WHERE id=$1',[req.params.id]);
        await audit(req.user.id,'room_deleted','room',req.params.id,req.ip);
        res.json({ ok:true });
    } catch(e){
        logger.error('room delete: '+e.message);
        res.status(500).json({error:e.message});
    }
});

// PURGAR todos los mensajes de una sala
router.delete('/rooms/:id/messages', async (req,res) => {
    try {
        const { rowCount } = await pool.query(
            `UPDATE messages SET deleted_at=NOW() WHERE room_id=$1 AND deleted_at IS NULL`,[req.params.id]);
        await audit(req.user.id,'room_purged','room',req.params.id,req.ip,{count:rowCount});
        res.json({ ok:true, purged:rowCount });
    } catch(e){ res.status(500).json({error:e.message}); }
});

// Expulsar usuario de sala
router.delete('/rooms/:roomId/members/:userId', async (req,res) => {
    try {
        await pool.query('DELETE FROM room_members WHERE room_id=$1 AND user_id=$2',[req.params.roomId,req.params.userId]);
        await audit(req.user.id,'room_kick','room',req.params.roomId,req.ip,{target:req.params.userId});
        res.json({ ok:true });
    } catch(e){ res.status(500).json({error:e.message}); }
});

// ── Auditoría ─────────────────────────────────────────────────────────────────
router.get('/audit', async (req,res) => {
    const { action,user_id,ip,from,to } = req.query;
    const page  = sanitizePage(req.query.page);
    const limit = sanitizeLimit(req.query.limit, 500);
    const params=[]; let where='WHERE 1=1';
    if (action)  { params.push(action);    where+=` AND a.action=$${params.length}`; }
    if (user_id) { params.push(user_id);   where+=` AND a.user_id=$${params.length}`; }
    if (ip)      { params.push(`%${ip}%`); where+=` AND a.ip_address::text ILIKE $${params.length}`; }
    if (from)    { params.push(from);      where+=` AND a.created_at>=$${params.length}`; }
    if (to)      { params.push(to);        where+=` AND a.created_at<=$${params.length}`; }
    try {
        const { rows } = await pool.query(
            `SELECT a.*,u.username FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id
             ${where} ORDER BY a.created_at DESC
             LIMIT $${params.length+1} OFFSET $${params.length+2}`,
            [...params,limit,(page-1)*limit]);
        res.json(rows);
    } catch(e){ res.status(500).json({error:e.message}); }
});

// ── GeoIP ─────────────────────────────────────────────────────────────────────
router.get('/geoip/:ip', async (req,res) => {
    try {
        const [geo,hist] = await Promise.all([
            geoSvc.lookup(req.params.ip),
            pool.query(
                `SELECT a.action,a.created_at,u.username FROM audit_logs a
                 LEFT JOIN users u ON u.id=a.user_id
                 WHERE a.ip_address=$1::inet ORDER BY a.created_at DESC LIMIT 50`,
                [req.params.ip]),
        ]);
        res.json({ geo, history:hist.rows });
    } catch(e){ res.status(500).json({error:e.message}); }
});

// ── Conexiones activas ────────────────────────────────────────────────────────
router.get('/connections', async (req,res) => {
    try {
        const { rows } = await pool.query(
            `SELECT ac.*,u.username,u.status user_status,c.race,c.class,c.face_id,r.name room_name
             FROM active_connections ac
             JOIN users u ON u.id=ac.user_id
             LEFT JOIN characters c ON c.user_id=ac.user_id
             LEFT JOIN rooms r ON r.id=ac.room_id
             ORDER BY ac.connected_at DESC`);
        res.json(rows);
    } catch(e){ res.status(500).json({error:e.message}); }
});

router.post('/connections/:socketId/kick', async (req,res) => {
    // Verificar que no se está pateando a sí mismo
    const ownSockets = await pool.query(
        'SELECT socket_id FROM active_connections WHERE user_id=$1', [req.user.id]).catch(()=>({rows:[]}));
    if (ownSockets.rows.some(r => r.socket_id === req.params.socketId))
        return res.status(400).json({ error: 'No podés expulsarte a vos mismo.' });
    try {
        await redis.publish('admin:kick', JSON.stringify({
            socketId:req.params.socketId,
            reason:req.body.reason||'Desconectado por el administrador'
        }));
        res.json({ ok:true });
    } catch(e){ res.status(500).json({error:e.message}); }
});

// ── IP Bans ───────────────────────────────────────────────────────────────────
router.get('/ip-bans', async (req,res) => {
    try {
        const { rows } = await pool.query(
            `SELECT b.*,u.username banned_by_username FROM ip_bans b
             LEFT JOIN users u ON u.id=b.banned_by ORDER BY b.created_at DESC`);
        res.json(rows);
    } catch(e){ res.status(500).json({error:e.message}); }
});

router.post('/ip-bans', async (req,res) => {
    const { ip_address,reason,expires_at } = req.body;
    try {
        const { rows } = await pool.query(
            `INSERT INTO ip_bans(ip_address,reason,banned_by,expires_at)
             VALUES($1::inet,$2,$3,$4) RETURNING *`,
            [ip_address,reason,req.user.id,expires_at||null]);
        res.json(rows[0]);
    } catch(e){ res.status(500).json({error:e.message}); }
});

router.delete('/ip-bans/:id', async (req,res) => {
    try {
        await pool.query('DELETE FROM ip_bans WHERE id=$1',[req.params.id]);
        res.json({ ok:true });
    } catch(e){ res.status(500).json({error:e.message}); }
});

// ── Mensajes ──────────────────────────────────────────────────────────────────
router.delete('/messages/:id', async (req,res) => {
    try {
        const { rows } = await pool.query(
            `UPDATE messages SET deleted_at=NOW() WHERE id=$1 RETURNING room_id`,[req.params.id]);
        await audit(req.user.id,'message_deleted','message',req.params.id,req.ip);
        res.json({ ok:true, room_id:rows[0]?.room_id });
    } catch(e){ res.status(500).json({error:e.message}); }
});

// ── Logs del servidor ─────────────────────────────────────────────────────────
router.get('/server-logs', (req,res) => {
    const { execSync } = require('child_process');
    try {
        const log = execSync('tail -n 300 /opt/ao-chat/logs/pm2.log 2>/dev/null || echo "Log no disponible"').toString();
        res.json({ log });
    } catch { res.json({ log:'No disponible' }); }
});


// ── Asignar rango ─────────────────────────────────────────────────────────────
router.post('/users/:id/role', async (req, res) => {
    const { role } = req.body;
    if (!['user','moderator','admin'].includes(role))
        return res.status(400).json({ error: 'Rango inválido: user | moderator | admin' });
    if (req.params.id === req.user.id && role !== 'admin')
        return res.status(400).json({ error: 'No podés quitarte el rango de admin a vos mismo' });
    try {
        const { rows } = await pool.query(
            'UPDATE users SET role=$1 WHERE id=$2 RETURNING username, role',
            [role, req.params.id]);
        if (!rows[0]) return res.status(404).json({ error: 'Usuario no encontrado' });
        await audit(req.user.id, 'role_changed', 'user', req.params.id, req.ip, { new_role: role });
        res.json({ ok: true, username: rows[0].username, role: rows[0].role });
    } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── Asignar título custom ────────────────────────────────────────────────────
router.post('/users/:id/title', async (req, res) => {
    const { title } = req.body;
    try {
        await pool.query(
            'UPDATE users SET custom_title=$1 WHERE id=$2',
            [title||null, req.params.id]);
        await audit(req.user.id, 'title_assigned', 'user', req.params.id, req.ip, { title });
        res.json({ ok: true });
    } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── Palabras prohibidas ──────────────────────────────────────────────────────
router.get('/banned-words', async (req,res) => {
    try {
        const { rows } = await pool.query('SELECT * FROM banned_words ORDER BY created_at DESC');
        res.json(rows);
    } catch(e){ res.status(500).json({error:e.message}); }
});

router.post('/banned-words', async (req,res) => {
    const { word, action } = req.body;
    if (!word?.trim()) return res.status(400).json({error:'Palabra requerida'});
    try {
        const { rows } = await pool.query(
            `INSERT INTO banned_words(word,action,added_by) VALUES($1,$2,$3) RETURNING *`,
            [word.trim().toLowerCase(), action||'censor', req.user.id]);
        res.json(rows[0]);
    } catch(e){ res.status(500).json({error:e.message}); }
});

router.delete('/banned-words/:id', async (req,res) => {
    try {
        await pool.query('DELETE FROM banned_words WHERE id=$1',[req.params.id]);
        res.json({ok:true});
    } catch(e){ res.status(500).json({error:e.message}); }
});

module.exports = router;


// ══════════════════════════════════════════════════════════════════════════════
//  BACKUP & IMPORT — AO Chat v3.9
// ══════════════════════════════════════════════════════════════════════════════
const { execFile, exec } = require('child_process');
const fsSync  = require('fs');
const pathLib = require('path');
const multer  = require('multer');

const _backupDir = () => {
    const d = process.env.BACKUP_DIR || pathLib.join(__dirname, '..', 'backups');
    fsSync.mkdirSync(d, { recursive: true, mode: 0o750 });
    return d;
};

// Multer para recibir el archivo .sql de importación (máx 200 MB)
const _sqlUpload = multer({
    dest: '/tmp/',
    limits: { fileSize: 200 * 1024 * 1024 },
    fileFilter: (_req, file, cb) =>
        (/\.(sql|gz)$/i.test(file.originalname) ? cb(null, true) : cb(new Error('Solo archivos .sql o .gz'))),
});

// GET /api/admin/backups — lista de backups
router.get('/backups', async (req, res) => {
    try {
        const dir = _backupDir();
        const files = fsSync.readdirSync(dir)
            .filter(f => f.endsWith('.sql') || f.endsWith('.sql.gz'))
            .map(f => {
                const fp = pathLib.join(dir, f);
                const st = fsSync.statSync(fp);
                return { filename: f, size_bytes: st.size, created_at: st.mtime };
            })
            .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

        // Also fetch db_backups log
        const { rows } = await pool.query(
            'SELECT * FROM db_backups ORDER BY created_at DESC LIMIT 50'
        ).catch(() => ({ rows: [] }));

        res.json({ files, log: rows });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /api/admin/backups — crear backup manual
router.post('/backups', async (req, res) => {
    try {
        const note = (req.body.note || '').slice(0, 200);
        const dir  = _backupDir();
        const ts   = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
        const filename = `ao_chat_backup_${ts}.sql`;
        const filepath = pathLib.join(dir, filename);

        const dbName = process.env.DB_NAME || 'ao_chat';
        const dbUser = process.env.DB_USER || 'ao_admin';
        const dbHost = process.env.DB_HOST || 'localhost';

        await new Promise((resolve, reject) => {
            const env = { ...process.env, PGPASSWORD: process.env.DB_PASS || '' };
            execFile('pg_dump',
                ['-h', dbHost, '-U', dbUser, '-d', dbName, '-f', filepath, '--no-password'],
                { env, timeout: 120_000 },
                (err) => err ? reject(err) : resolve()
            );
        });

        const size = fsSync.statSync(filepath).size;

        // Log to db_backups table (best effort)
        await pool.query(
            `INSERT INTO db_backups(filename, size_bytes, created_by, note)
             VALUES($1,$2,$3,$4)`,
            [filename, size, req.user.id, note]
        ).catch(() => {});

        await audit(req.user.id, 'backup_created', 'backup', null, req.ip, { filename, size });
        res.json({ ok: true, filename, size_bytes: size });
    } catch (e) {
        logger.error('backup create: ' + e.message);
        res.status(500).json({ error: 'Error al crear backup: ' + e.message });
    }
});

// GET /api/admin/backups/:filename/download — descargar un backup
router.get('/backups/:filename/download', (req, res) => {
    try {
        const filename = req.params.filename.replace(/[^a-zA-Z0-9._-]/g, '');
        const filepath = pathLib.join(_backupDir(), filename);
        if (!fsSync.existsSync(filepath)) return res.status(404).json({ error: 'Archivo no encontrado' });
        res.download(filepath, filename);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// DELETE /api/admin/backups/:filename — eliminar un backup
router.delete('/backups/:filename', async (req, res) => {
    try {
        const filename = req.params.filename.replace(/[^a-zA-Z0-9._-]/g, '');
        const filepath = pathLib.join(_backupDir(), filename);
        if (!fsSync.existsSync(filepath)) return res.status(404).json({ error: 'Archivo no encontrado' });
        fsSync.unlinkSync(filepath);
        await pool.query('DELETE FROM db_backups WHERE filename=$1', [filename]).catch(() => {});
        await audit(req.user.id, 'backup_deleted', 'backup', null, req.ip, { filename });
        res.json({ ok: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /api/admin/backups/import — importar/restaurar un .sql
router.post('/backups/import', _sqlUpload.single('backup_file'), async (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'Archivo requerido' });
    try {
        const dbName = process.env.DB_NAME || 'ao_chat';
        const dbUser = process.env.DB_USER || 'ao_admin';
        const dbHost = process.env.DB_HOST || 'localhost';
        const env    = { ...process.env, PGPASSWORD: process.env.DB_PASS || '' };

        await new Promise((resolve, reject) => {
            const args = ['-h', dbHost, '-U', dbUser, '-d', dbName, '--no-password', '-f', req.file.path];
            execFile('psql', args, { env, timeout: 300_000 },
                (err, _stdout, stderr) => {
                    if (err) return reject(new Error(stderr || err.message));
                    resolve();
                }
            );
        });

        fsSync.unlinkSync(req.file.path);
        await audit(req.user.id, 'db_imported', 'backup', null, req.ip,
            { original: req.file.originalname, size: req.file.size });
        res.json({ ok: true, message: 'Base de datos importada correctamente' });
    } catch (e) {
        try { fsSync.unlinkSync(req.file.path); } catch(_) {}
        logger.error('db import: ' + e.message);
        res.status(500).json({ error: 'Error al importar: ' + e.message });
    }
});

// ── Mensajes programados ──────────────────────────────────────────────────────

// GET /api/admin/scheduled-messages
router.get('/scheduled-messages', async (req, res) => {
    try {
        const { rows } = await pool.query(`
            SELECT sm.*, r.name AS room_name, u.username AS created_by_name
            FROM scheduled_messages sm
            LEFT JOIN rooms r ON r.id = sm.room_id
            LEFT JOIN users u ON u.id = sm.created_by
            ORDER BY sm.created_at DESC
        `);
        res.json(rows);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /api/admin/scheduled-messages
router.post('/scheduled-messages', async (req, res) => {
    const { room_id, content, cron_expr, is_active } = req.body;
    if (!room_id || !content?.trim() || !cron_expr?.trim())
        return res.status(400).json({ error: 'room_id, content y cron_expr son requeridos' });
    try {
        const { rows } = await pool.query(
            `INSERT INTO scheduled_messages(room_id, content, cron_expr, is_active, created_by)
             VALUES($1,$2,$3,$4,$5) RETURNING *`,
            [room_id, content.trim(), cron_expr.trim(), is_active !== false, req.user.id]
        );
        // Notify the scheduler service to reload
        if (global._schedulerReload) global._schedulerReload();
        res.json(rows[0]);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// PUT /api/admin/scheduled-messages/:id
router.put('/scheduled-messages/:id', async (req, res) => {
    const { content, cron_expr, is_active } = req.body;
    try {
        const { rows } = await pool.query(
            `UPDATE scheduled_messages
             SET content=COALESCE($2,content),
                 cron_expr=COALESCE($3,cron_expr),
                 is_active=COALESCE($4,is_active)
             WHERE id=$1 RETURNING *`,
            [req.params.id, content, cron_expr, is_active]
        );
        if (!rows[0]) return res.status(404).json({ error: 'No encontrado' });
        if (global._schedulerReload) global._schedulerReload();
        res.json(rows[0]);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// DELETE /api/admin/scheduled-messages/:id
router.delete('/scheduled-messages/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM scheduled_messages WHERE id=$1', [req.params.id]);
        if (global._schedulerReload) global._schedulerReload();
        res.json({ ok: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Dashboard mejorado ────────────────────────────────────────────────────────
router.get('/dashboard-full', async (req, res) => {
    try {
        const [users, online, msgs, rooms, activity] = await Promise.all([
            pool.query(`SELECT
                COUNT(*) total, COUNT(*) FILTER(WHERE status='active')  active,
                COUNT(*) FILTER(WHERE status='pending') pending,
                COUNT(*) FILTER(WHERE status='banned')  banned,
                COUNT(*) FILTER(WHERE created_at>NOW()-'24h'::interval) new_today FROM users`),
            pool.query('SELECT COUNT(*) online FROM active_connections'),
            pool.query(`SELECT
                COUNT(*) total,
                COUNT(*) FILTER(WHERE created_at>NOW()-'24h'::interval) today,
                COUNT(*) FILTER(WHERE created_at>NOW()-'1h'::interval)  last_hour
                FROM messages WHERE deleted_at IS NULL`),
            pool.query(`SELECT r.name, r.icon, r.kind,
                (SELECT COUNT(*) FROM active_connections ac WHERE ac.room_id=r.id) online,
                (SELECT COUNT(*) FROM messages m WHERE m.room_id=r.id
                 AND m.created_at>NOW()-'24h'::interval AND m.deleted_at IS NULL) msgs_today
                FROM rooms r WHERE r.is_active=true ORDER BY msgs_today DESC LIMIT 8`),
            pool.query(`SELECT DATE_TRUNC('hour', created_at) AS hour, COUNT(*) AS count
                FROM messages WHERE created_at > NOW()-'24h'::interval AND deleted_at IS NULL
                GROUP BY 1 ORDER BY 1`),
        ]);

        const pending = await pool.query(`
            SELECT u.id,u.username,u.created_at,c.race,c.class,c.profession,c.face_id
            FROM users u LEFT JOIN characters c ON c.user_id=u.id
            WHERE u.status='pending' ORDER BY u.created_at ASC LIMIT 20`);

        res.json({
            stats: {
                users:   users.rows[0],
                online:  parseInt(online.rows[0].online, 10),
                messages: msgs.rows[0],
            },
            rooms:        rooms.rows,
            activity:     activity.rows,
            pendingUsers: pending.rows,
        });
    } catch (e) { res.status(500).json({ error: e.message }); }
});
