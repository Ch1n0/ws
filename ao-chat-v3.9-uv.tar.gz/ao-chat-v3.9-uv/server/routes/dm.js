'use strict';
const router   = require('express').Router();
const { pool } = require('../config/db');
const { requireAuth } = require('../middleware/auth');

// Listar conversaciones DM del usuario
router.get('/', requireAuth, async (req, res) => {
    try {
        const { rows } = await pool.query(`
            SELECT DISTINCT ON (partner_id)
                partner_id, partner_username, partner_face_id, partner_class,
                last_content, last_at, unread_count
            FROM (
                SELECT
                    CASE WHEN dm.sender_id=$1 THEN dm.receiver_id ELSE dm.sender_id END AS partner_id,
                    u.username AS partner_username,
                    c.face_id  AS partner_face_id,
                    c.class    AS partner_class,
                    dm.content AS last_content,
                    dm.created_at AS last_at,
                    (SELECT COUNT(*) FROM direct_messages d2
                     WHERE d2.sender_id = CASE WHEN dm.sender_id=$1 THEN dm.receiver_id ELSE dm.sender_id END
                       AND d2.receiver_id=$1 AND d2.read_at IS NULL AND d2.deleted_at IS NULL
                    ) AS unread_count
                FROM direct_messages dm
                JOIN users u ON u.id = CASE WHEN dm.sender_id=$1 THEN dm.receiver_id ELSE dm.sender_id END
                LEFT JOIN characters c ON c.user_id = u.id
                WHERE (dm.sender_id=$1 OR dm.receiver_id=$1) AND dm.deleted_at IS NULL
                ORDER BY dm.created_at DESC
            ) sub
            ORDER BY partner_id, last_at DESC`,
            [req.user.id]);
        res.json(rows);
    } catch(e) { res.status(500).json({error:e.message}); }
});

// Historial de DMs con un usuario
router.get('/:userId', requireAuth, async (req, res) => {
    const limit  = Math.min(parseInt(req.query.limit||'60'), 100);
    const before = req.query.before;
    try {
        const params = [req.user.id, req.params.userId, limit];
        let cursor = '';
        if (before) { params.push(before); cursor = `AND dm.created_at < $${params.length}`; }
        const { rows } = await pool.query(`
            SELECT dm.*, u.username sender_username,
                   c.face_id sender_face_id, c.class sender_class
            FROM direct_messages dm
            JOIN users u ON u.id = dm.sender_id
            LEFT JOIN characters c ON c.user_id = dm.sender_id
            WHERE ((dm.sender_id=$1 AND dm.receiver_id=$2)
               OR  (dm.sender_id=$2 AND dm.receiver_id=$1))
              AND dm.deleted_at IS NULL ${cursor}
            ORDER BY dm.created_at DESC LIMIT $3`,
            params);
        // Marcar como leídos
        await pool.query(
            `UPDATE direct_messages SET read_at=NOW()
             WHERE sender_id=$1 AND receiver_id=$2 AND read_at IS NULL`,
            [req.params.userId, req.user.id]);
        res.json(rows.reverse());
    } catch(e) { res.status(500).json({error:e.message}); }
});

// Enviar DM
router.post('/:userId', requireAuth, async (req, res) => {
    const { content } = req.body;
    if (!content?.trim()) return res.status(400).json({error:'Mensaje vacío'});
    try {
        const target = await pool.query(
            'SELECT id,username FROM users WHERE id=$1 AND status=$2',
            [req.params.userId,'active']);
        if (!target.rows[0]) return res.status(404).json({error:'Usuario no encontrado'});
        const { rows } = await pool.query(
            `INSERT INTO direct_messages(sender_id,receiver_id,content)
             VALUES($1,$2,$3) RETURNING *`,
            [req.user.id, req.params.userId, content.trim().slice(0,2000)]);
        // XP por primer DM (logro)
        grantXP(req.user.id, 'first_dm').catch(()=>{});
        res.json(rows[0]);
    } catch(e) { res.status(500).json({error:e.message}); }
});

// Conteo de no leídos
router.get('/unread/count', requireAuth, async (req, res) => {
    try {
        const { rows } = await pool.query(
            `SELECT COUNT(*) unread FROM direct_messages
             WHERE receiver_id=$1 AND read_at IS NULL AND deleted_at IS NULL`,
            [req.user.id]);
        res.json({ unread: parseInt(rows[0].unread, 10) });
    } catch(e) { res.status(500).json({error:e.message}); }
});

async function grantXP(userId, achievementKey) {
    const { rows: [ach] } = await pool.query(
        'SELECT id,xp_reward FROM achievements WHERE key=$1',[achievementKey]);
    if (!ach) return;
    const inserted = await pool.query(
        `INSERT INTO user_achievements(user_id,achievement_id)
         VALUES($1,$2) ON CONFLICT DO NOTHING RETURNING user_id`,
        [userId, ach.id]);
    if (inserted.rows.length && ach.xp_reward > 0) {
        await pool.query(
            `UPDATE users SET xp=xp+$1, level=GREATEST(1,FLOOR(SQRT((xp+$1)/50))::int)
             WHERE id=$2`,[ach.xp_reward, userId]);
    }
}

module.exports = router;
