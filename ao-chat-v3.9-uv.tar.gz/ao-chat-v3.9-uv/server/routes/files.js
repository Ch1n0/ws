'use strict';
const router   = require('express').Router();
const multer   = require('multer');
const path     = require('path');
const fs       = require('fs');
const crypto   = require('crypto');
const jwt      = require('jsonwebtoken');
const { pool } = require('../config/db');
const { requireAuth } = require('../middleware/auth');
const logger   = require('../config/logger');

// Middleware for PDF inline view: accepts ?token= query param (iframes can't set headers)
async function inlineAuth(req, res, next) {
    const h = req.headers.authorization || '';
    if (h.startsWith('Bearer ')) return requireAuth(req, res, next);
    const token = (req.query.token || '').trim();
    if (!token) return res.status(401).json({ error: 'Token requerido' });
    try {
        const payload = jwt.verify(token, process.env.JWT_SECRET);
        const { rows } = await pool.query(
            'SELECT u.id, u.username, u.status, u.role FROM users u WHERE u.id=$1',
            [payload.sub]);
        if (!rows[0] || rows[0].status !== 'active')
            return res.status(401).json({ error: 'Sesión inválida' });
        req.user = rows[0]; req.token = token;
        next();
    } catch { return res.status(401).json({ error: 'Token inválido' }); }
}

const UPLOAD_DIR = process.env.UPLOAD_DIR ||
    path.join(__dirname, '..', 'uploads');

if (!fs.existsSync(UPLOAD_DIR))
    fs.mkdirSync(UPLOAD_DIR, { recursive: true, mode: 0o750 });

const MAX_MB = parseInt(process.env.MAX_FILE_MB || '50', 10);

// Clave AES-256 desde .env (32 bytes)
const ENC_KEY = (() => {
    const raw = process.env.ENCRYPTION_KEY || '';
    const buf = Buffer.from(raw.padEnd(32, '0').slice(0, 32), 'utf8');
    return buf;
})();

const BLOCKED_EXT = new Set([
    '.exe','.bat','.cmd','.sh','.ps1','.msi','.dll','.vbs','.scr','.jar'
]);

const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, UPLOAD_DIR),
    filename:    (req, file, cb) => cb(null, `tmp_${crypto.randomUUID()}`),
});
const upload = multer({
    storage,
    limits: { fileSize: MAX_MB * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
        const ext = path.extname(file.originalname).toLowerCase();
        if (BLOCKED_EXT.has(ext))
            return cb(new Error(`Tipo de archivo no permitido: ${ext}`));
        cb(null, true);
    },
});

function encryptFile(src, dest) {
    const iv     = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv('aes-256-cbc', ENC_KEY, iv);
    const rs     = fs.createReadStream(src);
    const ws     = fs.createWriteStream(dest);
    ws.write(iv);
    return new Promise((resolve, reject) => {
        rs.pipe(cipher).pipe(ws);
        ws.on('finish', resolve);
        ws.on('error', reject);
        rs.on('error', reject);
    });
}

function decryptToStream(srcPath, destStream) {
    return new Promise((resolve, reject) => {
        const src = fs.createReadStream(srcPath);
        let ivBuf = Buffer.alloc(0);
        let ivDone = false;
        let decipher;
        src.on('data', chunk => {
            if (!ivDone) {
                ivBuf = Buffer.concat([ivBuf, chunk]);
                if (ivBuf.length >= 16) {
                    decipher = crypto.createDecipheriv('aes-256-cbc', ENC_KEY, ivBuf.slice(0, 16));
                    decipher.pipe(destStream);
                    const rest = ivBuf.slice(16);
                    if (rest.length > 0) decipher.write(rest);
                    ivDone = true;
                }
            } else {
                decipher.write(chunk);
            }
        });
        src.on('end',   () => { if (decipher) decipher.end(); resolve(); });
        src.on('error', reject);
        destStream.on('error', reject);
    });
}

// ── POST /api/files/upload ───────────────────────────────────────────────────
router.post('/upload', requireAuth, upload.single('file'), async (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'No se recibió archivo' });
    const { roomId } = req.body;
    const tmpPath = req.file.path;
    try {
        // Enforce upload_permission for docs rooms
        if (roomId) {
            const { rows:[room] } = await pool.query(
                `SELECT kind, upload_permission FROM rooms WHERE id=$1 AND is_active=true`,
                [roomId]);
            if (room?.kind === 'docs' && room.upload_permission === 'staff') {
                if (!['admin','moderator'].includes(req.user.role)) {
                    try { require('fs').unlinkSync(tmpPath); } catch(_) {}
                    return res.status(403).json({ error: 'Solo el staff puede subir documentos en esta sala.' });
                }
            }
        }

        const storedName = `${crypto.randomUUID()}.enc`;
        const destPath   = path.join(UPLOAD_DIR, storedName);

        await encryptFile(tmpPath, destPath);
        fs.unlinkSync(tmpPath);

        const { rows } = await pool.query(
            `INSERT INTO files (uploaded_by, room_id, original_name, stored_name,
                                mime_type, size_bytes, is_encrypted)
             VALUES ($1, $2, $3, $4, $5, $6, true)
             RETURNING id`,
            [req.user.id, roomId || null, req.file.originalname,
             storedName, req.file.mimetype, req.file.size]);

        res.json({ id: rows[0].id, name: req.file.originalname, size: req.file.size });
    } catch (e) {
        if (fs.existsSync(tmpPath)) try { fs.unlinkSync(tmpPath); } catch (_) {}
        logger.error('Upload error: ' + e.message);
        res.status(500).json({ error: e.message });
    }
});

// ── GET /api/files/:id/download ──────────────────────────────────────────────
router.get('/:id/download', requireAuth, async (req, res) => {
    try {
        const { rows } = await pool.query(
            'SELECT * FROM files WHERE id = $1', [req.params.id]);
        if (!rows[0]) return res.status(404).json({ error: 'Archivo no encontrado' });

        const f       = rows[0];
        // Defensa contra path traversal: stored_name debe ser solo UUID.enc
        if (!/^[0-9a-f\-]{36}\.enc$/i.test(f.stored_name))
            return res.status(400).json({error:'Archivo inválido'});
        const fPath = path.join(UPLOAD_DIR, path.basename(f.stored_name));
        if (!fs.existsSync(fPath))
            return res.status(404).json({ error: 'Archivo no disponible en disco' });

        await pool.query(
            'UPDATE files SET download_count = download_count + 1 WHERE id = $1',
            [f.id]);

        // Sanitizar nombre: solo ASCII imprimible, max 200 chars
        const safeFilename = encodeURIComponent(
            f.original_name.replace(/[\x00-\x1f\x7f]/g,'_').slice(0,200));
        res.setHeader('Content-Disposition', `attachment; filename="${safeFilename}"`);
        res.setHeader('Content-Type', f.mime_type || 'application/octet-stream');
        // Prevenir XSS si el browser decide renderizar el archivo
        res.setHeader('X-Content-Type-Options', 'nosniff');

        await decryptToStream(fPath, res);
    } catch (e) {
        logger.error('Download error: ' + e.message);
        if (!res.headersSent) res.status(500).json({ error: e.message });
    }
});

// ── GET /api/files/:id/view — serve PDF inline (for docs rooms viewer) ────────
router.get('/:id/view', inlineAuth, async (req, res) => {
    try {
        const { rows } = await pool.query(
            'SELECT * FROM files WHERE id = $1 AND deleted_at IS NULL', [req.params.id]);
        if (!rows[0]) return res.status(404).json({ error: 'Archivo no encontrado' });

        const f = rows[0];
        if (!/^[0-9a-f\-]{36}\.enc$/i.test(f.stored_name))
            return res.status(400).json({ error: 'Archivo inválido' });
        const fPath = path.join(UPLOAD_DIR, path.basename(f.stored_name));
        if (!fs.existsSync(fPath))
            return res.status(404).json({ error: 'Archivo no disponible en disco' });

        // Only allow PDF inline viewing
        if (f.mime_type !== 'application/pdf')
            return res.status(415).json({ error: 'Solo se puede visualizar PDFs inline' });

        const safeFilename = encodeURIComponent(
            f.original_name.replace(/[\x00-\x1f\x7f]/g,'_').slice(0,200));
        res.setHeader('Content-Disposition', `inline; filename="${safeFilename}"`);
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('X-Content-Type-Options', 'nosniff');
        // Allow iframe embedding from same origin
        res.setHeader('Content-Security-Policy', "default-src 'self'");

        await decryptToStream(fPath, res);
    } catch (e) {
        logger.error('View error: ' + e.message);
        if (!res.headersSent) res.status(500).json({ error: e.message });
    }
});

// ── DELETE /api/files/bulk — eliminar varios PDFs a la vez ──────────────────
router.delete('/bulk', requireAuth, async (req, res) => {
    const { ids } = req.body;
    if (!Array.isArray(ids) || !ids.length)
        return res.status(400).json({ error: 'ids requerido' });
    if (!['admin','moderator'].includes(req.user.role))
        return res.status(403).json({ error: 'Solo staff puede eliminar en lote' });
    try {
        const { rowCount } = await pool.query(
            `UPDATE files SET deleted_at=NOW()
             WHERE id=ANY($1::uuid[]) AND deleted_at IS NULL`,
            [ids]);
        res.json({ ok: true, deleted: rowCount });
    } catch(e) {
        logger.error('Bulk delete: ' + e.message);
        res.status(500).json({ error: e.message });
    }
});

// ── DELETE /api/files/:id — eliminar un archivo ──────────────────────────────
router.delete('/:id', requireAuth, async (req, res) => {
    try {
        const { rows } = await pool.query(
            'SELECT * FROM files WHERE id=$1 AND deleted_at IS NULL', [req.params.id]);
        if (!rows[0]) return res.status(404).json({ error: 'Archivo no encontrado' });
        const f = rows[0];
        if (f.uploaded_by !== req.user.id && !['admin','moderator'].includes(req.user.role))
            return res.status(403).json({ error: 'Sin permisos' });
        await pool.query('UPDATE files SET deleted_at=NOW() WHERE id=$1', [f.id]);
        res.json({ ok: true });
    } catch(e) {
        logger.error('File delete: ' + e.message);
        res.status(500).json({ error: e.message });
    }
});

// ── GET /api/files/:id/url ───────────────────────────────────────────────────
router.get('/:id/url', requireAuth, async (req, res) => {
    const { rows } = await pool.query(
        'SELECT id FROM files WHERE id = $1', [req.params.id]).catch(() => ({ rows: [] }));
    if (!rows[0]) return res.status(404).json({ error: 'No encontrado' });
    res.json({ url: `/api/files/${req.params.id}/download` });
});

module.exports = router;
