'use strict';
const router   = require('express').Router();
const { pool } = require('../config/db');
const { requireAuth } = require('../middleware/auth');

// GET /api/rooms  — lista de salas visibles para el usuario
router.get('/', requireAuth, async (req, res) => {
    try {
        const { rows } = await pool.query(`
            SELECT
                r.id, r.name, r.slug, r.description,
                r.type, COALESCE(r.kind,'chat') AS kind, r.icon, r.topic,
                r.max_users, r.is_active,
                COALESCE(r.image_url, '')        AS image_url,
                COALESCE(r.admin_only, false)    AS admin_only,
                COALESCE(r.slow_mode_sec, 0)     AS slow_mode_sec,
                COALESCE(r.embed_url, '')        AS embed_url,
                COALESCE(r.upload_permission,'all') AS upload_permission,
                (SELECT COUNT(*) FROM active_connections ac WHERE ac.room_id=r.id) AS online_count
            FROM rooms r
            WHERE r.is_active = true
              AND (
                r.type = 'public'
                OR r.type = 'private'
                OR (r.type = 'admin' AND $1 IN ('admin','moderator'))
              )
            ORDER BY r.created_at ASC`,
            [req.user.role]);
        res.json(rows);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// GET /api/rooms/:id/documents — lista de PDFs subidos a una sala de tipo docs
router.get('/:id/documents', requireAuth, async (req, res) => {
    try {
        const { rows:[room] } = await pool.query(
            `SELECT id, type, kind FROM rooms WHERE id=$1 AND is_active=true`,
            [req.params.id]);
        if (!room) return res.status(404).json({ error: 'Sala no encontrada' });
        if (room.kind !== 'docs') return res.status(400).json({ error: 'No es una sala de documentos' });
        if (room.type === 'admin' && !['admin','moderator'].includes(req.user.role))
            return res.status(403).json({ error: 'Sin acceso' });

        const { rows } = await pool.query(`
            SELECT
                f.id, f.original_name, f.size_bytes, f.mime_type,
                f.created_at, f.download_count,
                f.uploaded_by,
                u.username AS uploader
            FROM files f
            JOIN users u ON u.id = f.uploaded_by
            WHERE f.room_id = $1
              AND f.deleted_at IS NULL
              AND f.mime_type = 'application/pdf'
            ORDER BY f.created_at DESC`,
            [req.params.id]);
        res.json(rows);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

module.exports = router;
