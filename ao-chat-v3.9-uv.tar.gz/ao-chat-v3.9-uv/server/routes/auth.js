'use strict';
const router   = require('express').Router();
const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const { pool } = require('../config/db');
const redis    = require('../config/redis');
const logger   = require('../config/logger');
const geoSvc   = require('../services/geoService');

const sign = (id) =>
    jwt.sign({ sub: id }, process.env.JWT_SECRET,
             { expiresIn: process.env.JWT_EXPIRES || '24h' });

const audit = async (userId, action, ip, ua, meta = {}) => {
    try {
        await pool.query(
            `INSERT INTO audit_logs (user_id, action, ip_address, user_agent, metadata)
             VALUES ($1,$2,$3::inet,$4,$5)`,
            [userId, action, ip||'127.0.0.1', ua, JSON.stringify(meta)]);
    } catch (_) {}
};

// POST /api/auth/register  — sin email
router.post('/register', [
    body('username').trim().isLength({ min:3, max:32 }).matches(/^[a-zA-Z0-9_\-]+$/),
    body('password').isLength({ min:8 }),
    body('race').notEmpty(),
    body('gender').notEmpty(),
    body('class').notEmpty(),
    body('profession').notEmpty(),
    body('face_id').isInt({ min:1, max:130 }),
], async (req, res) => {
    const errs = validationResult(req);
    if (!errs.isEmpty()) return res.status(400).json({ error: errs.array()[0].msg });

    const { username, password, race, gender, profession, face_id } = req.body;
    const charClass = req.body.class;

    try {
        const cfg = await pool.query("SELECT value FROM settings WHERE key='registration_open'");
        if (cfg.rows[0]?.value === 'false')
            return res.status(403).json({ error: 'El registro está cerrado temporalmente.' });

        const exists = await pool.query(
            'SELECT id FROM users WHERE username=$1', [username]);
        if (exists.rows.length)
            return res.status(409).json({ error: 'El nombre de usuario ya está en uso.' });

        const hash = await bcrypt.hash(password, 12);
        const { rows } = await pool.query(
            `INSERT INTO users (username, password_hash, status, role)
             VALUES ($1,$2,'pending','user') RETURNING id`,
            [username, hash]);

        await pool.query(
            `INSERT INTO characters (user_id,race,gender,class,profession,face_id)
             VALUES ($1,$2,$3,$4,$5,$6)`,
            [rows[0].id, race, gender, charClass, profession, face_id]);

        await audit(rows[0].id, 'register', req.ip, req.get('user-agent'));
        logger.info(`Nuevo registro: ${username}`);
        res.status(201).json({ message: 'Personaje creado. Aguardá la aprobación del administrador.' });
    } catch (e) {
        logger.error('Register: ' + e.message);
        res.status(500).json({ error: 'Error interno.' });
    }
});

// POST /api/auth/login
router.post('/login', [
    body('username').trim().notEmpty(),
    body('password').notEmpty(),
], async (req, res) => {
    const errs = validationResult(req);
    if (!errs.isEmpty()) return res.status(400).json({ error: 'Datos inválidos.' });

    const { username, password } = req.body;
    const ip = req.ip || '127.0.0.1';
    const ua = req.get('user-agent') || '';

    try {
        const { rows } = await pool.query(
            `SELECT u.id,u.username,u.password_hash,u.status,u.role,
                    u.muted_until,u.mute_reason,
                    c.race,c.gender,c.class,c.profession,c.face_id
             FROM users u LEFT JOIN characters c ON c.user_id=u.id
             WHERE u.username=$1`, [username]);

        const user  = rows[0];
        const valid = user
            ? await bcrypt.compare(password, user.password_hash)
            : await bcrypt.compare(password, '$2b$12$invalidhashfortimingprotectionXX');

        if (!user || !valid) {
            await audit(user?.id||null, 'login_fail', ip, ua, { username });
            return res.status(401).json({ error: 'Usuario o contraseña incorrectos.' });
        }
        if (user.status === 'pending')
            return res.status(403).json({ error: 'Tu cuenta está pendiente de aprobación.', status: 'pending' });
        if (user.status === 'banned')
            return res.status(403).json({ error: 'Tu cuenta ha sido baneada.' });
        if (user.status === 'suspended')
            return res.status(403).json({ error: 'Tu cuenta está suspendida.' });

        const token = sign(user.id);
        await pool.query('UPDATE users SET last_login=NOW() WHERE id=$1', [user.id]);
        await audit(user.id, 'login_success', ip, ua);

        geoSvc.lookup(ip).then(async (geo) => {
            if (!geo) return;
            await pool.query(
                `UPDATE audit_logs SET geo_country=$1,geo_city=$2,geo_lat=$3,geo_lon=$4
                 WHERE user_id=$5 AND action='login_success' ORDER BY created_at DESC LIMIT 1`,
                [geo.country_name, geo.city, geo.latitude, geo.longitude, user.id]
            ).catch(() => {});
        }).catch(() => {});

        const { password_hash: _, ...safe } = user;
        res.json({ token, user: safe });
    } catch (e) {
        logger.error('Login: ' + e.message);
        res.status(500).json({ error: 'Error interno.' });
    }
});

// POST /api/auth/logout
router.post('/logout', async (req, res) => {
    const h = req.headers.authorization || '';
    const token = h.startsWith('Bearer ') ? h.slice(7) : null;
    if (token) {
        try {
            const p = jwt.decode(token);
            const ttl = p?.exp ? p.exp - Math.floor(Date.now()/1000) : 86400;
            if (ttl > 0) await redis.setex(`revoked:${token}`, ttl, '1');
        } catch (_) {}
    }
    res.json({ ok: true });
});

module.exports = router;
