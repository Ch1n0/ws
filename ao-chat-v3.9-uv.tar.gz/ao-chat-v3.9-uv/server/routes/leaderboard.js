'use strict';
const router   = require('express').Router();
const { pool } = require('../config/db');
const { requireAuth } = require('../middleware/auth');

router.get('/', requireAuth, async (req, res) => {
    try {
        const { rows } = await pool.query(`
            SELECT u.id, u.username, u.xp, u.level, u.custom_title,
                   c.race, c.class, c.face_id,
                   (SELECT COUNT(*) FROM messages m WHERE m.user_id=u.id AND m.deleted_at IS NULL) msg_count,
                   (SELECT COUNT(*) FROM user_achievements ua WHERE ua.user_id=u.id) achievement_count,
                   RANK() OVER (ORDER BY u.xp DESC) AS rank
            FROM users u
            LEFT JOIN characters c ON c.user_id=u.id
            WHERE u.status='active' AND u.role!='admin'
            ORDER BY u.xp DESC LIMIT 50`);
        res.json(rows);
    } catch(e) { res.status(500).json({error:e.message}); }
});

router.get('/achievements', requireAuth, async (req, res) => {
    try {
        const { rows } = await pool.query(
            `SELECT a.*, COUNT(ua.user_id) earned_by
             FROM achievements a LEFT JOIN user_achievements ua ON ua.achievement_id=a.id
             GROUP BY a.id ORDER BY earned_by DESC`);
        res.json(rows);
    } catch(e) { res.status(500).json({error:e.message}); }
});

router.get('/my-achievements', requireAuth, async (req, res) => {
    try {
        const { rows } = await pool.query(
            `SELECT a.*, ua.earned_at
             FROM user_achievements ua JOIN achievements a ON a.id=ua.achievement_id
             WHERE ua.user_id=$1 ORDER BY ua.earned_at DESC`,
            [req.user.id]);
        res.json(rows);
    } catch(e) { res.status(500).json({error:e.message}); }
});

module.exports = router;
