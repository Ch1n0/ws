'use strict';
const router   = require('express').Router();
const { pool } = require('../config/db');
const { requireAuth, requireAdmin } = require('../middleware/auth');

// Advertencias de un usuario
router.get('/:userId', requireAuth, requireAdmin, async (req, res) => {
    try {
        const { rows } = await pool.query(
            `SELECT w.*,u.username issued_by_username
             FROM warnings w JOIN users u ON u.id=w.issued_by
             WHERE w.user_id=$1 ORDER BY w.created_at DESC`,
            [req.params.userId]);
        res.json(rows);
    } catch(e) { res.status(500).json({error:e.message}); }
});

// Emitir advertencia
router.post('/:userId', requireAuth, requireAdmin, async (req, res) => {
    if (req.params.userId === req.user.id)
        return res.status(400).json({error:'No podés advertirte a vos mismo'});
    const { reason, message_id } = req.body;
    if (!reason?.trim()) return res.status(400).json({error:'Razón requerida'});
    try {
        const { rows:[w] } = await pool.query(
            `INSERT INTO warnings(user_id,issued_by,reason,message_id)
             VALUES($1,$2,$3,$4) RETURNING *`,
            [req.params.userId, req.user.id, reason.trim(), message_id||null]);
        // Incrementar contador
        const { rows:[u] } = await pool.query(
            `UPDATE users SET warn_count=warn_count+1 WHERE id=$1
             RETURNING warn_count, username`,
            [req.params.userId]);
        // Auto-ban si llegó al límite
        const { rows:[cfg] } = await pool.query(
            "SELECT value FROM settings WHERE key='auto_ban_warnings'");
        const limit = parseInt(cfg?.value||'3');
        let auto_banned = false;
        if (u.warn_count >= limit) {
            await pool.query(
                `UPDATE users SET status='banned',ban_reason=$1 WHERE id=$2`,
                [`Ban automático: ${u.warn_count} advertencias`, req.params.userId]);
            auto_banned = true;
        }
        res.json({ warning:w, warn_count:u.warn_count, auto_banned });
    } catch(e) { res.status(500).json({error:e.message}); }
});

// Borrar advertencia
router.delete('/:warnId', requireAuth, requireAdmin, async (req, res) => {
    try {
        const { rows:[w] } = await pool.query(
            'DELETE FROM warnings WHERE id=$1 RETURNING user_id',[req.params.warnId]);
        if (w) await pool.query(
            'UPDATE users SET warn_count=GREATEST(0,warn_count-1) WHERE id=$1',[w.user_id]);
        res.json({ok:true});
    } catch(e) { res.status(500).json({error:e.message}); }
});

module.exports = router;
