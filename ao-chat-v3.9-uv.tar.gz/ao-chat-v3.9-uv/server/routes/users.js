'use strict';
const router   = require('express').Router();
const { pool } = require('../config/db');
const { requireAuth } = require('../middleware/auth');

// GET /api/users/me — datos completos del usuario autenticado
router.get('/me', requireAuth, async (req, res) => {
    try {
        const { rows } = await pool.query(`
            SELECT u.id, u.username, u.status, u.role, u.created_at, u.last_login,
                   u.muted_until, u.mute_reason, u.warn_count,
                   COALESCE(u.xp, 0)          AS xp,
                   COALESCE(u.level, 1)        AS level,
                   u.custom_title, u.theme,
                   COALESCE(u.user_status,'online') AS user_status,
                   u.status_text,
                   c.race, c.gender, c.class, c.profession,
                   COALESCE(c.face_id, 1) AS face_id, c.description
            FROM users u LEFT JOIN characters c ON c.user_id=u.id
            WHERE u.id=$1`, [req.user.id]);
        res.json(rows[0] || {});
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/users/:id/public — perfil público con logros y estadísticas
router.get('/:id/public', requireAuth, async (req, res) => {
    try {
        const { rows } = await pool.query(`
            SELECT u.id, u.username, u.role, u.created_at,
                   COALESCE(u.xp, 0)    AS xp,
                   COALESCE(u.level, 1) AS level,
                   u.custom_title,
                   c.race, c.gender, c.class, c.profession,
                   COALESCE(c.face_id, 1) AS face_id, c.description,
                   (SELECT COUNT(*) FROM messages m
                    WHERE m.user_id=u.id AND m.deleted_at IS NULL) AS msg_count
            FROM users u LEFT JOIN characters c ON c.user_id=u.id
            WHERE u.id=$1 AND u.status='active'`, [req.params.id]);
        if (!rows[0]) return res.status(404).json({ error: 'No encontrado' });

        // Logros del usuario
        const { rows: achs } = await pool.query(`
            SELECT a.key, a.name, a.description, a.icon, a.xp_reward, ua.earned_at
            FROM user_achievements ua
            JOIN achievements a ON a.id=ua.achievement_id
            WHERE ua.user_id=$1
            ORDER BY ua.earned_at DESC`, [req.params.id]);

        res.json({ ...rows[0], achievements: achs });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// PUT /api/users/me — actualizar perfil propio
router.put('/me', requireAuth, async (req, res) => {
    const { description, face_id, theme } = req.body;
    try {
        if (face_id !== undefined) {
            const fid = parseInt(face_id, 10);
            if (isNaN(fid) || fid < 1 || fid > 130)
                return res.status(400).json({ error: 'face_id inválido (1-130)' });
            await pool.query('UPDATE characters SET face_id=$1 WHERE user_id=$2',
                [fid, req.user.id]);
        }
        if (description !== undefined) {
            await pool.query('UPDATE characters SET description=$1 WHERE user_id=$2',
                [description.slice(0, 500), req.user.id]);
        }
        if (theme !== undefined) {
            const validThemes = ['dark-gold','blood-red','forest-green','deep-blue','light'];
            if (!validThemes.includes(theme))
                return res.status(400).json({ error: 'Tema inválido' });
            await pool.query('UPDATE users SET theme=$1 WHERE id=$2',
                [theme, req.user.id]);
        }
        res.json({ ok: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
