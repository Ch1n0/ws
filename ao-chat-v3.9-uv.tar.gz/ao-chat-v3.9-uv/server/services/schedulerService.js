'use strict';
/**
 * Scheduler Service — mensajes de sistema programados
 * Carga los mensajes activos de scheduled_messages y los ejecuta
 * según su expresión cron. Se puede recargar en caliente via global._schedulerReload().
 */
const cron   = require('node-cron');
const { pool } = require('../config/db');
const logger   = require('../config/logger');

let _jobs = []; // jobs activos en memoria

async function loadAndSchedule(io) {
    // Cancelar todos los jobs anteriores
    _jobs.forEach(j => j.destroy());
    _jobs = [];

    let rows;
    try {
        const result = await pool.query(
            `SELECT sm.id, sm.room_id, sm.content, sm.cron_expr
             FROM scheduled_messages sm
             WHERE sm.is_active = true`
        );
        rows = result.rows;
    } catch (e) {
        logger.warn('schedulerService: error al cargar mensajes — ' + e.message);
        return;
    }

    for (const row of rows) {
        if (!cron.validate(row.cron_expr)) {
            logger.warn(`schedulerService: cron inválido para mensaje ${row.id}: ${row.cron_expr}`);
            continue;
        }
        const job = cron.schedule(row.cron_expr, async () => {
            try {
                // Insertar el mensaje como tipo 'system'
                const { rows: [msg] } = await pool.query(
                    `INSERT INTO messages(room_id, user_id, content, type)
                     SELECT $1, id, $2, 'system'
                     FROM users WHERE role='admin' LIMIT 1
                     RETURNING id, room_id, content, type, created_at`,
                    [row.room_id, row.content]
                );
                if (msg) {
                    io.to(row.room_id).emit('message:new', {
                        id:         msg.id,
                        room_id:    msg.room_id,
                        content:    msg.content,
                        type:       'system',
                        created_at: msg.created_at,
                        username:   'Sistema',
                        face_id:    null,
                        level:      0,
                    });
                }
                // Actualizar last_run
                await pool.query(
                    'UPDATE scheduled_messages SET last_run=NOW() WHERE id=$1',
                    [row.id]
                );
                logger.info(`schedulerService: mensaje ${row.id} enviado a sala ${row.room_id}`);
            } catch (e) {
                logger.error(`schedulerService: error enviando mensaje ${row.id}: ${e.message}`);
            }
        }, { timezone: 'America/Argentina/Buenos_Aires' });

        _jobs.push(job);
    }

    logger.info(`schedulerService: ${_jobs.length} mensaje(s) programado(s)`);
}

function start(io) {
    // Función de recarga global — llamada desde admin routes cuando cambian los mensajes
    global._schedulerReload = () => {
        logger.info('schedulerService: recargando...');
        loadAndSchedule(io).catch(e => logger.error('schedulerService reload: ' + e.message));
    };
    return loadAndSchedule(io);
}

module.exports = { start };
