'use strict';
const https  = require('https');
const redis  = require('../config/redis');
const logger = require('../config/logger');

const LOCAL_IPS = new Set(['127.0.0.1', '::1', 'localhost', '']);

function isLocal(ip) {
    if (!ip || LOCAL_IPS.has(ip)) return true;
    return ip.startsWith('192.168.') ||
           ip.startsWith('10.')       ||
           ip.startsWith('172.');
}

function countryFlag(cc) {
    if (!cc || cc.length !== 2) return '🌍';
    const offset = 0x1F1E6 - 65;
    return String.fromCodePoint(cc.toUpperCase().charCodeAt(0) + offset) +
           String.fromCodePoint(cc.toUpperCase().charCodeAt(1) + offset);
}

async function lookup(ip) {
    if (isLocal(ip)) {
        return { country_name: 'Local', city: 'LAN', latitude: 0, longitude: 0,
                 emoji: '🏠', org: 'Red local' };
    }
    try {
        const cached = await redis.get(`geo:${ip}`);
        if (cached) return JSON.parse(cached);
    } catch (_) {}

    return new Promise((resolve) => {
        const req = https.get(
            `https://ipapi.co/${ip}/json/`,
            { headers: { 'User-Agent': 'AOChat/3.0' }, timeout: 4000 },
            (res) => {
                let data = '';
                res.on('data', c => { data += c; });
                res.on('end', async () => {
                    try {
                        const geo = JSON.parse(data);
                        if (geo.error) { resolve(null); return; }
                        if (geo.country_code) geo.emoji = countryFlag(geo.country_code);
                        redis.setex(`geo:${ip}`, 86400, JSON.stringify(geo)).catch(() => {});
                        resolve(geo);
                    } catch { resolve(null); }
                });
            });
        req.on('error',   ()  => resolve(null));
        req.on('timeout', ()  => { req.destroy(); resolve(null); });
    });
}

module.exports = { lookup };
