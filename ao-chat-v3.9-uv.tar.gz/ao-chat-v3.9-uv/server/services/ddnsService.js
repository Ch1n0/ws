'use strict';
const https    = require('https');
const cron     = require('node-cron');
const { pool } = require('../config/db');
const logger   = require('../config/logger');

let cronJob = null;

function getPublicIp() {
    return new Promise((resolve, reject) => {
        const req = https.get(
            'https://api.ipify.org?format=json',
            { timeout: 5000 },
            (res) => {
                let d = '';
                res.on('data', c => { d += c; });
                res.on('end', () => {
                    try { resolve(JSON.parse(d).ip); }
                    catch { reject(new Error('Respuesta inválida de ipify')); }
                });
            });
        req.on('error',   reject);
        req.on('timeout', () => { req.destroy(); reject(new Error('Timeout obteniendo IP')); });
    });
}

function updateCloudflare(zoneId, token, recordId, subdomain, ip) {
    return new Promise((resolve, reject) => {
        const body = JSON.stringify({
            type: 'A', name: subdomain, content: ip, ttl: 60, proxied: false
        });
        const opts = {
            hostname: 'api.cloudflare.com',
            path:     `/client/v4/zones/${zoneId}/dns_records/${recordId}`,
            method:   'PUT',
            headers:  {
                'Content-Type':   'application/json',
                'Authorization':  `Bearer ${token}`,
                'Content-Length': Buffer.byteLength(body),
            },
            timeout: 8000,
        };
        const req = https.request(opts, (res) => {
            let d = '';
            res.on('data', c => { d += c; });
            res.on('end', () => {
                try {
                    const r = JSON.parse(d);
                    if (r.success) resolve({ success: true, ip, record: r.result?.name });
                    else reject(new Error(r.errors?.[0]?.message || 'Error de Cloudflare API'));
                } catch { reject(new Error('Respuesta inválida de Cloudflare')); }
            });
        });
        req.on('error',   reject);
        req.on('timeout', () => { req.destroy(); reject(new Error('Timeout Cloudflare')); });
        req.write(body);
        req.end();
    });
}

async function updateNow() {
    const { rows } = await pool.query(
        `SELECT key, value FROM settings
         WHERE key IN (
           'ddns_enabled','cloudflare_zone_id','cloudflare_api_token',
           'cloudflare_record_id','cloudflare_subdomain'
         )`);
    const s = {};
    rows.forEach(r => { s[r.key] = r.value; });

    if (s.ddns_enabled !== 'true')
        return { skipped: true, reason: 'DDNS deshabilitado' };

    const { cloudflare_zone_id: zone, cloudflare_api_token: token,
            cloudflare_record_id: record, cloudflare_subdomain: sub } = s;

    if (!zone || !token || !record || !sub)
        return { skipped: true, reason: 'Configuración de Cloudflare incompleta' };

    const ip     = await getPublicIp();
    const result = await updateCloudflare(zone, token, record, sub, ip);

    await pool.query(
        `UPDATE settings SET value=$1, updated_at=NOW() WHERE key='server_domain'`,
        [sub]).catch(() => {});

    logger.info(`DDNS actualizado: ${sub} → ${ip}`);
    return { ...result, updated_at: new Date().toISOString() };
}

async function startCron() {
    const { rows } = await pool.query(
        `SELECT value FROM settings WHERE key='ddns_interval_min'`);
    const interval = Math.max(1, Math.min(60, parseInt(rows[0]?.value || '5', 10)));
    const expr     = `*/${interval} * * * *`;

    if (cronJob) { cronJob.stop(); cronJob = null; }

    cronJob = cron.schedule(expr, async () => {
        try { await updateNow(); }
        catch (e) { logger.warn('DDNS cron error: ' + e.message); }
    });

    logger.info(`DDNS cron activo — cada ${interval} minuto(s)`);
}

module.exports = { updateNow, startCron };
