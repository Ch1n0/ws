'use strict';
const { pool } = require('../config/db');

const XP_EVENTS = {
    message:  2,
    file:     5,
    poll:     10,
    vote:     3,
    like:     1,
    dm:       2,
    dice:     1,
};

const ACHIEVEMENT_TRIGGERS = {
    first_message:  { event:'message',  count:1   },
    messages_10:    { event:'message',  count:10  },
    messages_100:   { event:'message',  count:100 },
    messages_500:   { event:'message',  count:500 },
    first_poll:     { event:'poll',     count:1   },
    first_vote:     { event:'vote',     count:1   },
    first_like:     { event:'like',     count:1   },
    first_file:     { event:'file',     count:1   },
    dice_roll:      { event:'dice',     count:1   },
    first_dm:       { event:'dm',       count:1   },
};

async function grant(userId, event, io) {
    try {
        const xp = XP_EVENTS[event] || 0;
        if (xp === 0) return;

        // BUG FIX: capture level BEFORE update via CTE, otherwise old_level = new level
        const { rows:[u] } = await pool.query(
            `WITH prev AS (SELECT level FROM users WHERE id=$2)
             UPDATE users
             SET xp=xp+$1,
                 level=LEAST(50, GREATEST(1, FLOOR(SQRT((xp+$1)/50.0))::int))
             WHERE id=$2
             RETURNING xp, level, (SELECT level FROM prev) AS old_level`,
            [xp, userId]);
        
        if (!u) return;

        // ¿Subió de nivel?
        if (u.level > (u.old_level || 0)) {
            io?.to(`user:${userId}`).emit('level_up', { level: u.level, xp: u.xp });
            checkLevelAchievement(userId, u.level, io).catch(()=>{});
        }

        // Verificar logros por conteo
        const eventCount = await getEventCount(userId, event);
        for (const [key, trigger] of Object.entries(ACHIEVEMENT_TRIGGERS)) {
            if (trigger.event === event && eventCount >= trigger.count) {
                await grantAchievement(userId, key, io);
            }
        }

    } catch (_) {}
}

async function getEventCount(userId, event) {
    try {
        if (event === 'message') {
            const { rows:[r] } = await pool.query(
                `SELECT COUNT(*) c FROM messages WHERE user_id=$1 AND deleted_at IS NULL`,[userId]);
            return parseInt(r.c);
        }
        if (event === 'poll') {
            const { rows:[r] } = await pool.query(
                `SELECT COUNT(*) c FROM polls WHERE created_by=$1`,[userId]);
            return parseInt(r.c);
        }
        if (event === 'vote') {
            const { rows:[r] } = await pool.query(
                `SELECT COUNT(*) c FROM poll_votes WHERE user_id=$1`,[userId]);
            return parseInt(r.c);
        }
        if (event === 'like') {
            const { rows:[r] } = await pool.query(
                `SELECT COUNT(*) c FROM message_reactions WHERE user_id=$1`,[userId]);
            return parseInt(r.c);
        }
        if (event === 'file') {
            const { rows:[r] } = await pool.query(
                `SELECT COUNT(*) c FROM files WHERE uploaded_by=$1`,[userId]);
            return parseInt(r.c);
        }
        if (event === 'dm') {
            const { rows:[r] } = await pool.query(
                `SELECT COUNT(*) c FROM direct_messages WHERE sender_id=$1`,[userId]);
            return parseInt(r.c);
        }
        if (event === 'dice') {
            const { rows:[r] } = await pool.query(
                `SELECT COUNT(*) c FROM messages WHERE user_id=$1 AND type='dice'`,[userId]);
            return parseInt(r.c);
        }
    } catch(_) { return 0; }
    return 0;
}

async function checkLevelAchievement(userId, level, io) {
    const levelKeys = { 5:'level_5', 10:'level_10', 20:'level_20' };
    const key = levelKeys[level];
    if (key) await grantAchievement(userId, key, io);
}

async function grantAchievement(userId, key, io) {
    try {
        const { rows:[ach] } = await pool.query(
            'SELECT * FROM achievements WHERE key=$1',[key]);
        if (!ach) return;
        const { rows } = await pool.query(
            `INSERT INTO user_achievements(user_id,achievement_id)
             VALUES($1,$2) ON CONFLICT DO NOTHING RETURNING user_id`,
            [userId, ach.id]);
        if (rows.length > 0) {
            // Notificar al usuario
            io?.to(`user:${userId}`).emit('achievement', {
                key:         ach.key,
                name:        ach.name,
                description: ach.description,
                icon:        ach.icon,
                xp_reward:   ach.xp_reward,
            });
            // XP del logro
            if (ach.xp_reward > 0) {
                await pool.query(
                    `UPDATE users SET xp=xp+$1 WHERE id=$2`,
                    [ach.xp_reward, userId]);
            }
        }
    } catch(_) {}
}

module.exports = { grant, grantAchievement };
