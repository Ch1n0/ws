'use strict';
const redis  = require('../config/redis');
const logger = require('../config/logger');

module.exports = function adminHandler(io) {

    // Suscripción Redis para kicks desde el panel admin (pub/sub)
    const sub = redis.duplicate();
    sub.subscribe('admin:kick').catch(e =>
        logger.error('Redis sub error: ' + e.message));

    sub.on('message', (channel, message) => {
        if (channel !== 'admin:kick') return;
        try {
            const { socketId, reason } = JSON.parse(message);
            const target = io.sockets.sockets.get(socketId);
            if (target) {
                target.emit('admin:kick', { reason });
                setTimeout(() => target.disconnect(true), 500);
                logger.info(`[WS] Admin kick: ${socketId} — ${reason}`);
            }
        } catch (e) {
            logger.error('admin:kick handler: ' + e.message);
        }
    });

    // Admins y mods se unen a sala especial para eventos en tiempo real
    io.on('connection', (socket) => {
        if (['admin', 'moderator'].includes(socket.user?.role)) {
            socket.join('admin-room');
        }
    });
};
