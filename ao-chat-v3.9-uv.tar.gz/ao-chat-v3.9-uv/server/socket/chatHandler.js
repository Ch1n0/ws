'use strict';
const { pool } = require('../config/db');
const redis    = require('../config/redis');
const logger   = require('../config/logger');
const geoSvc   = require('../services/geoService');
const xpSvc    = require('../services/xpService');

const EMOTES = {
    // ── Combate ──────────────────────────────────────────────────────────
    '/espada'  :'⚔️',  '/escudo'  :'🛡️',  '/flecha'   :'🏹',  '/hacha'    :'🪓',
    '/daga'    :'🗡️',  '/arco'    :'🏹',  '/lanza'    :'🪃',  '/martillo' :'🔨',
    '/bomba'   :'💣',  '/explosion':'💥',  '/sangre'   :'🩸',  '/veneno'   :'☠️',
    '/calavera':'💀',  '/golpe'   :'👊',  '/knockout' :'🥊',  '/escapa'   :'🏃',
    // ── Magia ────────────────────────────────────────────────────────────
    '/magia'   :'✨',  '/fuego'   :'🔥',  '/hielo'    :'❄️',  '/rayo'     :'⚡',
    '/viento'  :'🌪️', '/agua'    :'🌊',  '/tierra'   :'🪨',  '/oscuridad':'🌑',
    '/luz'     :'☀️', '/dragon'  :'🐉',  '/fenix'    :'🦅',  '/cristal'  :'💎',
    '/pocion'  :'🧪',  '/grimorio':'📜',  '/varita'   :'🪄',  '/portal'   :'🌀',
    '/luna'    :'🌙',  '/estrella':'⭐',  '/meteoro'  :'☄️',  '/cosmos'   :'🌌',
    // ── Objetos ──────────────────────────────────────────────────────────
    '/cofre'   :'📦',  '/llave'   :'🗝️', '/corona'   :'👑',  '/mapa'     :'🗺️',
    '/libro'   :'📚',  '/carta'   :'✉️', '/bolsa'    :'💰',  '/moneda'   :'🪙',
    '/reliquia':'🏺',  '/gema'    :'💍',  '/trofeo'   :'🏆',  '/escroll'  :'📃',
    '/antorcha':'🔦',  '/vela'    :'🕯️', '/campana'  :'🔔',  '/pocion2'  :'🍶',
    // ── Naturaleza ───────────────────────────────────────────────────────
    '/arbol'   :'🌲',  '/flor'    :'🌺',  '/hongo'    :'🍄',  '/hoja'     :'🍀',
    '/lobo'    :'🐺',  '/aguila'  :'🦅',  '/serpiente':'🐍',  '/dragon2'  :'🦎',
    '/lluvia'  :'🌧️', '/nieve'   :'❄️',  '/tormenta' :'⛈️', '/noche'    :'🌃',
    '/desierto':'🏜️', '/bosque'  :'🌳',  '/volcan'   :'🌋',  '/isla'     :'🏝️',
    // ── Social ───────────────────────────────────────────────────────────
    '/corazon' :'❤️', '/risa'    :'😄',  '/lloro'    :'😢',  '/enojo'    :'😡',
    '/asombro' :'😲',  '/miedo'   :'😱',  '/guino'    :'😉',  '/cool'     :'😎',
    '/hola'    :'👋',  '/aplausos':'👏',  '/saludo'   :'🫡',  '/brindis'  :'🍺',
    '/silencio':'🤫',  '/pensar'  :'🤔',  '/ok'       :'👍',  '/no'       :'👎',
    '/amor'    :'💕',  '/fuerte'  :'💪',  '/dormir'   :'😴',  '/fiesta'   :'🎉',
};

function parseCommand(content) {
    const t = content.trim();
    if (t.startsWith('/me ')) return { type:'me', content:t.slice(4).trim() };
    // /dado  → d20  |  /dado6 o /dado 6 → d6  (espacio opcional, rango 2-100)
    const dice = t.match(/^\/(?:dado|d)\s*(\d{1,3})?$/i);
    if (dice) {
        const sides = dice[1] ? Math.min(Math.max(parseInt(dice[1]),2),100) : 20;
        const result = Math.floor(Math.random()*sides)+1;
        return { type:'dice', sides, result,
                 content:`🎲 tiró un dado de ${sides} caras y obtuvo **${result}**` };
    }
    for (const [cmd, emoji] of Object.entries(EMOTES)) {
        if (t === cmd || t.startsWith(cmd+' ')) {
            const rest = t.slice(cmd.length).trim();
            return { type:'emote', content: rest ? `${emoji} ${rest}` : emoji };
        }
    }
    return null;
}

// PERF FIX: cache banned words in Redis for 5 min, invalidated on admin change
async function getBannedWords() {
    try {
        const cached = await redis.get('cache:banned_words');
        if (cached) return JSON.parse(cached);
        const { rows } = await pool.query('SELECT word,action FROM banned_words');
        await redis.setex('cache:banned_words', 300, JSON.stringify(rows));
        return rows;
    } catch { return []; }
}

function filterContent(content, bannedWords) {
    let filtered = content;
    let blocked  = false;
    for (const bw of bannedWords) {
        const re = new RegExp(bw.word.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'), 'gi');
        if (re.test(filtered)) {
            if (bw.action === 'block') { blocked = true; break; }
            if (bw.action === 'censor') filtered = filtered.replace(re, '****');
        }
    }
    return { filtered, blocked };
}

module.exports = function chatHandler(io) {

    io.on('connection', async (socket) => {
        const user = socket.user;
        const ip   = (socket.handshake.headers['x-real-ip'] ||
                      socket.handshake.headers['x-forwarded-for']?.split(',')[0] ||
                      socket.handshake.address || '127.0.0.1').trim().replace('::ffff:','');

        logger.info(`[WS] + ${user.username} (${socket.id})`);

        socket.join(`user:${user.id}`);

        try {
            await pool.query(
                `INSERT INTO active_connections(user_id,socket_id,ip_address,user_agent)
                 VALUES($1,$2,$3::inet,$4) ON CONFLICT(socket_id) DO UPDATE SET user_id=$1`,
                [user.id, socket.id, ip, socket.handshake.headers['user-agent']||'']);

            geoSvc.lookup(ip).then(geo => {
                if (!geo) return;
                pool.query(`UPDATE active_connections SET geo_country=$1,geo_city=$2
                            WHERE socket_id=$3`, [geo.country_name, geo.city, socket.id]).catch(()=>{});
            }).catch(()=>{});
        } catch(e) { logger.error('active_conn: '+e.message); }

        await pool.query(`UPDATE users SET last_seen=NOW(),user_status=CASE
            WHEN user_status='invisible' THEN 'invisible' ELSE 'online' END
            WHERE id=$1`, [user.id]).catch(()=>{});

        // PERF FIX: use Redis atomic counter instead of DB COUNT on every connect
        redis.incr('stats:online').catch(()=>{});
        emitStats(io);

        // ── UNIRSE A SALA ────────────────────────────────────────────────────
        socket.on('room:join', async ({ roomId }) => {
            try {
                const { rows:[room] } = await pool.query(
                    `SELECT id,name,type,kind,COALESCE(admin_only,false) admin_only
                     FROM rooms WHERE id=$1 AND is_active=true`,[roomId]);
                if (!room) return;
                if (room.type==='admin' && !['admin','moderator'].includes(user.role)) return;
                if (room.admin_only && !['admin','moderator'].includes(user.role)) {
                    socket.emit('error',{message:'Esta sala está en modo solo-admin temporalmente.'});
                    return;
                }
                // Salir de sala anterior
                for (const r of [...socket.rooms]) {
                    if (r===socket.id || r.startsWith('user:') || r.startsWith('dm:')) continue;
                    socket.leave(r);
                    socket.to(r).emit('room:user_left',{user:{username:user.username},roomId:r});
                }
                socket.join(roomId);
                await pool.query('UPDATE active_connections SET room_id=$1 WHERE socket_id=$2',[roomId,socket.id]).catch(()=>{});
                await pool.query(`INSERT INTO room_members(room_id,user_id) VALUES($1,$2) ON CONFLICT DO NOTHING`,[roomId,user.id]).catch(()=>{});
                socket.to(roomId).emit('room:user_joined',{
                    user:{username:user.username,face_id:user.face_id,role:user.role,level:user.level}, roomId
                });
                const members = await getRoomMembers(roomId);
                io.to(roomId).emit('room:members',{roomId,members,count:members.length});
            } catch(e) { logger.error('room:join: '+e.message); }
        });

        // ── ENVIAR MENSAJE ────────────────────────────────────────────────────
        socket.on('message:send', async ({ roomId, content, type='text',
                                           file_id, file_name, file_size, reply_to_id }) => {
            try {
                if (!roomId || !socket.rooms.has(roomId)) return;

                // PERF FIX: single query for mute + room settings instead of two
                const { rows:[ctx] } = await pool.query(`
                    SELECT u.muted_until, u.mute_reason,
                           COALESCE(r.slow_mode_sec,0) slow_mode_sec,
                           COALESCE(r.admin_only,false) admin_only,
                           r.kind
                    FROM users u, rooms r
                    WHERE u.id=$1 AND r.id=$2`,
                    [user.id, roomId]);

                if (!ctx) return;

                // Docs/web rooms: no messages
                if (ctx.kind === 'web') return;

                if (ctx.muted_until && new Date(ctx.muted_until)>new Date()) {
                    socket.emit('error',{message:`Silenciado hasta ${new Date(ctx.muted_until).toLocaleTimeString()}. Razón: ${ctx.mute_reason||'—'}`});
                    return;
                }
                if (ctx.admin_only && !['admin','moderator'].includes(user.role)) {
                    socket.emit('error',{message:'La sala está en modo solo-admin.'});
                    return;
                }
                if (ctx.slow_mode_sec > 0 && !['admin','moderator'].includes(user.role)) {
                    const smKey = `slowmode:${user.id}:${roomId}`;
                    const exists = await redis.exists(smKey);
                    if (exists) {
                        socket.emit('error',{message:`Modo lento activo. Esperá ${ctx.slow_mode_sec}s entre mensajes.`});
                        return;
                    }
                    await redis.setex(smKey, ctx.slow_mode_sec, '1');
                }

                // Anti-flood
                const fk = `flood:${user.id}:${roomId}`;
                const cnt = await redis.incr(fk);
                if (cnt===1) await redis.expire(fk,2);
                if (cnt>5) { socket.emit('error',{message:'Enviás mensajes muy rápido.'}); return; }

                let finalContent = (content||'').trim().slice(0,2000);
                let finalType    = type;
                let diceData     = null;

                if (type === 'text') {
                    const cmd = parseCommand(finalContent);
                    if (cmd) {
                        finalType    = cmd.type;
                        finalContent = cmd.content;
                        if (cmd.type === 'dice') diceData = { sides: cmd.sides, result: cmd.result };
                    }
                }

                if (!finalContent && type!=='file') return;

                if (type==='text' || finalType==='me' || finalType==='emote') {
                    const words = await getBannedWords();
                    const { filtered, blocked } = filterContent(finalContent, words);
                    if (blocked) {
                        socket.emit('error',{message:'Tu mensaje contiene contenido no permitido.'});
                        return;
                    }
                    finalContent = filtered;
                }

                const { rows:[msg] } = await pool.query(
                    `INSERT INTO messages(room_id,user_id,content,type,file_id,reply_to_id)
                     VALUES($1,$2,$3,$4,$5,$6) RETURNING id,created_at`,
                    [roomId,user.id,finalContent,finalType,file_id||null,reply_to_id||null]);

                let replyData = null;
                if (reply_to_id) {
                    const { rows:[rm] } = await pool.query(
                        `SELECT m.content,u.username FROM messages m JOIN users u ON u.id=m.user_id WHERE m.id=$1`,
                        [reply_to_id]);
                    if (rm) replyData = { username:rm.username, content:rm.content.slice(0,80) };
                }

                const payload = {
                    id:          msg.id,
                    room_id:     roomId,
                    user_id:     user.id,
                    username:    user.username,
                    role:        user.role,
                    race:        user.race,
                    char_class:  user.class,
                    face_id:     user.face_id,
                    level:       user.level,
                    custom_title:user.custom_title,
                    content:     finalContent,
                    type:        finalType,
                    file_id:     file_id   || null,
                    file_name:   file_name || null,
                    file_size:   file_size || null,
                    file_mime:   (file_id ? (await pool.query('SELECT mime_type FROM files WHERE id=$1',[file_id]).then(r=>r.rows[0]?.mime_type||'').catch(()=>'')) : null),
                    reply_to_id: reply_to_id || null,
                    reply_data:  replyData,
                    dice_data:   diceData,
                    created_at:  msg.created_at,
                    likes: 0, dislikes: 0,
                };

                io.to(roomId).emit('message:new', payload);
                const xpEvent = finalType==='dice'?'dice':finalType==='file'?'file':'message';
                xpSvc.grant(user.id, xpEvent, io).catch(()=>{});

            } catch(e) { logger.error('message:send: '+e.message); }
        });

        socket.on('message:broadcast', ({ roomId, message }) => {
            if (!roomId || !socket.rooms.has(roomId)) return;
            if (!message || !message.id) return;
            io.to(roomId).emit('message:new', message);
        });

        socket.on('dm:send', async ({ to_user_id, content }) => {
            try {
                if (!content?.trim() || !to_user_id) return;
                const { rows:[target] } = await pool.query(
                    'SELECT id,username FROM users WHERE id=$1 AND status=$2',[to_user_id,'active']);
                if (!target) return;

                const { rows:[dm] } = await pool.query(
                    `INSERT INTO direct_messages(sender_id,receiver_id,content)
                     VALUES($1,$2,$3) RETURNING *`,
                    [user.id,to_user_id,content.trim().slice(0,2000)]);

                const payload = {
                    ...dm,
                    sender_username:  user.username,
                    sender_face_id:   user.face_id,
                    sender_class:     user.class,
                };

                io.to(`user:${to_user_id}`).emit('dm:new', payload);
                socket.emit('dm:new', payload);
                xpSvc.grant(user.id,'dm',io).catch(()=>{});
            } catch(e) { logger.error('dm:send: '+e.message); }
        });

        socket.on('user:status', async ({ status, status_text }) => {
            const valid = ['online','busy','afk','invisible'];
            if (!valid.includes(status)) return;
            try {
                await pool.query(
                    'UPDATE users SET user_status=$1,status_text=$2 WHERE id=$3',
                    [status, (status_text||'').slice(0,64), user.id]);
                const currentRoom = [...socket.rooms].find(r => !r.startsWith('user:') && !r.startsWith('dm:') && r!==socket.id);
                if (currentRoom) {
                    io.to(currentRoom).emit('user:status_update', {
                        user_id:user.id, status, status_text: status_text||''
                    });
                }
            } catch(_) {}
        });

        socket.on('typing:start', ({ roomId }) => {
            if (!roomId || !socket.rooms.has(roomId)) return;
            socket.to(roomId).emit('typing:update', {
                user_id:user.id, username:user.username, typing:true
            });
        });
        socket.on('typing:stop', ({ roomId }) => {
            if (!roomId) return;
            socket.to(roomId).emit('typing:update', {
                user_id:user.id, username:user.username, typing:false
            });
        });

        socket.on('reaction:update', ({ roomId, messageId, likes, dislikes }) => {
            if (!roomId) return;
            socket.to(roomId).emit('reaction:update',{ messageId, likes, dislikes });
        });

        socket.on('disconnect', async () => {
            logger.info(`[WS] - ${user.username} (${socket.id})`);
            try {
                await pool.query('DELETE FROM active_connections WHERE socket_id=$1',[socket.id]);
                await pool.query(`UPDATE users SET last_seen=NOW() WHERE id=$1`,[user.id]);
                // PERF FIX: Redis decrement instead of DB COUNT
                redis.decr('stats:online').catch(()=>{});
                for (const roomId of [...socket.rooms]) {
                    if (roomId===socket.id || roomId.startsWith('user:') || roomId.startsWith('dm:')) continue;
                    io.to(roomId).emit('room:user_left',{user:{username:user.username},roomId});
                    const members = await getRoomMembers(roomId);
                    io.to(roomId).emit('room:members',{roomId,members,count:members.length});
                }
                emitStats(io);
            } catch(e) { logger.error('disconnect: '+e.message); }
        });
    });

    async function getRoomMembers(roomId) {
        const { rows } = await pool.query(
            `SELECT u.id, u.username, u.role, u.level, u.user_status, u.custom_title,
                    c.race, c.class, c.face_id
             FROM active_connections ac
             JOIN users u ON u.id=ac.user_id
             LEFT JOIN characters c ON c.user_id=ac.user_id
             WHERE ac.room_id=$1`,[roomId]);
        return rows;
    }

    // PERF FIX: use Redis atomic counter for online count
    async function emitStats(io) {
        try {
            const online = parseInt(await redis.get('stats:online') || '0', 10);
            io.to('admin-room').emit('admin:stats_update',{online: isNaN(online) ? 0 : online});
        } catch(_){}
    }
};
