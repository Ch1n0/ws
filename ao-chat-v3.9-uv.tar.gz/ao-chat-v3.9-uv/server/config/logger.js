'use strict';
const winston = require('winston');
require('winston-daily-rotate-file');
const path = require('path');

// Ruta absoluta al directorio de logs
const LOGS_DIR = process.env.LOGS_DIR || path.join(__dirname, '..', 'logs');

const fmt = winston.format.combine(
    winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    winston.format.printf(({ timestamp, level, message }) =>
        `${timestamp} [${level.toUpperCase().padEnd(5)}] ${message}`)
);

const logger = winston.createLogger({
    level: process.env.LOG_LEVEL || 'info',
    format: fmt,
    transports: [
        new winston.transports.Console({
            format: winston.format.combine(winston.format.colorize(), fmt),
        }),
        new winston.transports.DailyRotateFile({
            filename:      path.join(LOGS_DIR, 'app-%DATE%.log'),
            datePattern:   'YYYY-MM-DD',
            maxFiles:      '14d',
            maxSize:       '20m',
            zippedArchive: true,
        }),
        new winston.transports.DailyRotateFile({
            filename:      path.join(LOGS_DIR, 'error-%DATE%.log'),
            datePattern:   'YYYY-MM-DD',
            level:         'error',
            maxFiles:      '30d',
            maxSize:       '10m',
            zippedArchive: true,
        }),
    ],
});

module.exports = logger;
