'use strict';
const { Pool } = require('pg');
const logger   = require('./logger');

const pool = new Pool({
    host:                    process.env.DB_HOST || 'localhost',
    port:                    parseInt(process.env.DB_PORT || '5432', 10),
    database:                process.env.DB_NAME || 'ao_chat',
    user:                    process.env.DB_USER || 'ao_admin',
    password:                process.env.DB_PASS || '',
    max:                     20,
    idleTimeoutMillis:       30000,
    connectionTimeoutMillis: 5000,
});

pool.on('error', (err) => {
    logger.error('PostgreSQL pool error: ' + err.message);
});

// Test de conexión — NO hace process.exit si falla
// El servidor arranca igual y loguea el problema
pool.query('SELECT 1')
    .then(() => logger.info('PostgreSQL conectado correctamente'))
    .catch(e  => logger.warn('PostgreSQL no disponible al inicio: ' + e.message +
                             ' — el servidor continúa y reintentará en cada request'));

module.exports = { pool };
