'use strict';
const Redis  = require('ioredis');
const logger = require('./logger');

const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379', {
    maxRetriesPerRequest: 3,
    retryStrategy: (times) => Math.min(times * 150, 3000),
    lazyConnect: false,
});

redis.on('connect', () => logger.info('Redis conectado correctamente'));
redis.on('error',   (e) => logger.warn('Redis: ' + e.message));

module.exports = redis;
