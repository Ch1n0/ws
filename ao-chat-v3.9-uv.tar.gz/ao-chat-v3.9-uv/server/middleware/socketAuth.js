'use strict';
const jwt      = require('jsonwebtoken');
const { pool } = require('../config/db');
const redis    = require('../config/redis');

async function socketAuth(socket, next) {
    try {
        const token = socket.handshake.auth?.token;
        if (!token) return next(new Error('unauthorized'));

        if (await redis.get(`revoked:${token}`))
            return next(new Error('unauthorized'));

        const payload = jwt.verify(token, process.env.JWT_SECRET);
        const { rows } = await pool.query(
            `SELECT u.id, u.username, u.status, u.role,
                    u.xp, u.level, u.custom_title, u.user_status,
                    u.muted_until, u.mute_reason,
                    c.race, c.class, c.face_id
             FROM users u
             LEFT JOIN characters c ON c.user_id = u.id
             WHERE u.id = $1`, [payload.sub]);

        if (!rows[0] || rows[0].status !== 'active')
            return next(new Error('unauthorized'));

        socket.user = rows[0];
        next();
    } catch {
        next(new Error('unauthorized'));
    }
}

module.exports = { socketAuth };
