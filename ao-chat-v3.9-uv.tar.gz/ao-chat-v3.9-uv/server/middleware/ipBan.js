'use strict';
const { pool } = require('../config/db');

async function ipBanCheck(req, res, next) {
    if (req.path === '/api/health') return next();
    const ip = req.ip || '';
    try {
        const { rows } = await pool.query(
            `SELECT id FROM ip_bans
             WHERE (ip_address = $1::inet OR $1::inet <<= cidr_block)
               AND (expires_at IS NULL OR expires_at > NOW())
             LIMIT 1`,
            [ip || '127.0.0.1']);
        if (rows.length > 0)
            return res.status(403).json({ error: 'Acceso denegado.' });
        next();
    } catch {
        next(); // si falla la consulta, no bloquear
    }
}

module.exports = { ipBanCheck };
