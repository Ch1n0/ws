'use strict';
const jwt      = require('jsonwebtoken');
const { pool } = require('../config/db');
const redis    = require('../config/redis');

async function requireAuth(req, res, next) {
    try {
        const h     = req.headers.authorization || '';
        const token = h.startsWith('Bearer ') ? h.slice(7) : null;
        if (!token) return res.status(401).json({ error: 'Token requerido' });

        if (await redis.get(`revoked:${token}`))
            return res.status(401).json({ error: 'Sesión expirada' });

        const payload = jwt.verify(token, process.env.JWT_SECRET);

        // COALESCE en todas las columnas nuevas para compatibilidad con
        // instalaciones que todavía no corrieron la migración completa
        const { rows } = await pool.query(`
            SELECT
                u.id, u.username, u.status, u.role,
                COALESCE(u.xp, 0)            AS xp,
                COALESCE(u.level, 1)         AS level,
                u.custom_title,
                u.theme,
                COALESCE(u.user_status,'online') AS user_status,
                u.status_text,
                u.muted_until,
                u.mute_reason,
                COALESCE(u.warn_count, 0)    AS warn_count,
                c.race, c.gender,
                c.class, c.profession,
                COALESCE(c.face_id, 1)       AS face_id,
                c.description
            FROM users u
            LEFT JOIN characters c ON c.user_id = u.id
            WHERE u.id = $1`, [payload.sub]);

        if (!rows[0])
            return res.status(401).json({ error: 'Usuario no encontrado' });
        if (['banned','suspended'].includes(rows[0].status))
            return res.status(403).json({
                error: 'Cuenta suspendida o baneada.',
                status: rows[0].status
            });

        req.user  = rows[0];
        req.token = token;
        next();
    } catch (e) {
        if (e.name === 'JsonWebTokenError' || e.name === 'TokenExpiredError')
            return res.status(401).json({ error: 'Token inválido o expirado' });
        next(e);
    }
}

function requireAdmin(req, res, next) {
    if (req.user?.role !== 'admin')
        return res.status(403).json({ error: 'Requiere privilegios de administrador' });
    next();
}

function requireMod(req, res, next) {
    if (!['admin','moderator'].includes(req.user?.role))
        return res.status(403).json({ error: 'Requiere privilegios de moderador' });
    next();
}

module.exports = { requireAuth, requireAdmin, requireMod };
