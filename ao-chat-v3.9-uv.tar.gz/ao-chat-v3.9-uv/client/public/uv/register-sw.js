/**
 * register-sw.js — Registra el Service Worker de Ultraviolet.
 * Cargado en index.html ANTES de app.js.
 * Expone window.__uvSWReady (Promise<boolean>).
 */
(function () {
    'use strict';
    var _resolve;
    window.__uvSWReady = new Promise(function(res){ _resolve = res; });

    if (!('serviceWorker' in navigator)) { _resolve(false); return; }

    function loadScript(src) {
        return new Promise(function(resolve, reject) {
            if (document.querySelector('script[src="'+src+'"]')) { resolve(); return; }
            var s = document.createElement('script');
            s.src = src;
            s.onload = resolve;
            s.onerror = function(){ reject(new Error('Error cargando: '+src)); };
            document.head.appendChild(s);
        });
    }

    async function init() {
        try {
            await loadScript('/uv/uv.bundle.js');
            await loadScript('/uv/uv.config.js');
            var scope = (window.__uv$config && window.__uv$config.prefix) || '/uv/service/';
            var reg = await navigator.serviceWorker.register('/uv/uv.sw.js', { scope: scope });
            await navigator.serviceWorker.ready;
            window.__uvRegistration = reg;
            _resolve(true);
        } catch(e) {
            console.warn('[UV] SW no disponible:', e.message);
            _resolve(false);
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
