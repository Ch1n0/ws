/*
 * Ultraviolet — Configuración del cliente / Service Worker
 * Cargado por uv.sw.js (dentro del SW) y por register-sw.js (en la página).
 */
/*global Ultraviolet*/
self.__uv$config = {
    prefix:    '/uv/service/',
    encodeUrl: Ultraviolet.codec.xor.encode,
    decodeUrl: Ultraviolet.codec.xor.decode,
    handler:   '/uv/uv.handler.js',
    client:    '/uv/uv.client.js',
    bundle:    '/uv/uv.bundle.js',
    config:    '/uv/uv.config.js',
    sw:        '/uv/uv.sw.js',
};
