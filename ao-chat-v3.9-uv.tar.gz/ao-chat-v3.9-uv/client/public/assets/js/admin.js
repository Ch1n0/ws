'use strict';
/* admin.js — Panel de administración integrado en el chat */

const AP = { current: null };

/* ── Abrir / cerrar panel ─────────────────────────────────────────────────── */
/* openAdminPanel/closeAdminPanel — ya no se usan en diseño unificado
   Se mantienen como no-ops por compatibilidad */
function openAdminPanel(section) { goToSection('admin-' + section); }
function closeAdminPanel()       { goToSection('chat'); }

/* loadApSection — ya no usa ap-title, solo llama la función directamente */
function loadApSection(s) {
    const fns = {
        dashboard:apDash, pending:apPending, users:apUsers, conns:apConns,
        rooms:apRooms, audit:apAudit, ipbans:apIpBans, logs:apLogs,
        settings:apSettings, words:apWords, backup:apBackup, scheduled:apScheduled,
    };
    if (fns[s]) fns[s]();
}

const AP_SECTIONS = {
    dashboard: { container:'ap-content-dash',     title:'📊 Dashboard'           },
    pending:   { container:'ap-content-pending',  title:'⏳ Pendientes'           },
    users:     { container:'ap-content-users',    title:'👥 Usuarios'             },
    conns:     { container:'ap-content-conns',    title:'🔌 Conexiones activas'   },
    rooms:     { container:'ap-content-rooms',    title:'🏛️ Salas'               },
    audit:     { container:'ap-content-audit',    title:'📋 Auditoría'            },
    ipbans:    { container:'ap-content-ipbans',   title:'🛡️ IP Bans'             },
    logs:      { container:'ap-content-logs',     title:'📟 Logs del servidor'    },
    settings:  { container:'ap-content-settings', title:'⚙️ Configuración'       },
    words:     { container:'ap-content-words',    title:'🚫 Palabras bloqueadas'  },
    roles:     { container:'ap-content-roles',    title:'⚡ Permisos de roles'      },
    backup:    { container:'ap-content-backup',   title:'💾 Backups & BD'        },
    scheduled: { container:'ap-content-scheduled',title:'⏰ Msgs. Programados'   },
};

/* Setea AP.current, actualiza título de sección y devuelve el contenedor */
function apGo(section) {
    AP.current = section;
    const info = AP_SECTIONS[section];
    if (!info) return null;
    // Título de sección dentro del main-content
    const hdr = document.getElementById('ap-section-title-' + info.container);
    if (hdr) hdr.textContent = info.title;
    return document.getElementById(info.container);
}

function apContainer() {
    const info = AP_SECTIONS[AP.current];
    if (!info) return null;
    return document.getElementById(info.container);
}

function apLoading() {
    const c = apContainer();
    if (c) c.innerHTML =
        '<div style="text-align:center;padding:3rem;color:var(--txm)">Cargando...</div>';
}

/* ── Helpers ──────────────────────────────────────────────────────────────── */
function esc(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function fd(d)  { return d ? new Date(d).toLocaleDateString('es-AR') : '—'; }
function fdt(d) { return d ? new Date(d).toLocaleString('es-AR',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'}) : '—'; }

async function apApi(m, p, b) {
    const h = {'Content-Type':'application/json', 'Authorization':'Bearer '+(S?.token||localStorage.getItem('ao_token')||'')};
    const r = await fetch(p, {method:m, headers:h, body:b?JSON.stringify(b):undefined});
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || 'HTTP '+r.status);
    return d;
}

function apModal(title, html, btns=[]) {
    document.getElementById('modal-title').textContent = title;
    document.getElementById('modal-body').innerHTML   = html;
    const mf = document.getElementById('modal-foot');
    if (btns.length) {
        mf.innerHTML = btns.map((b,i) => `<button class="ap-btn ${b.cls}" id="apb-${i}">${b.lbl}</button>`).join('');
        btns.forEach((b,i) => document.getElementById(`apb-${i}`)
            .addEventListener('click', async () => {
                try { await b.fn(); } catch(e) { toast(e.message,'error'); }
            }));
        mf.classList.remove('hidden');
    } else mf.classList.add('hidden');
    document.getElementById('modal').classList.remove('hidden');
}

/* ── DASHBOARD ────────────────────────────────────────────────────────────── */
async function apDash() {
    AP.current="dashboard"; apLoading();
    try {
        const [dash, conns] = await Promise.all([
            apApi('GET','/api/admin/dashboard-full'),
            apApi('GET','/api/admin/connections'),
        ]);
        const s = dash.stats;
        document.getElementById('nb-pending').textContent = s.users.pending;
        apContainer().innerHTML = `
            <div class="ap-grid">
              <div class="ap-stat"><div class="ap-stat-lbl">Usuarios totales</div><div class="ap-stat-val" style="color:var(--go)">${s.users.total}</div></div>
              <div class="ap-stat"><div class="ap-stat-lbl">Activos</div><div class="ap-stat-val" style="color:var(--onl)">${s.users.active}</div></div>
              <div class="ap-stat"><div class="ap-stat-lbl">Pendientes</div><div class="ap-stat-val" style="color:var(--yw,#e67e22)">${s.users.pending}</div></div>
              <div class="ap-stat"><div class="ap-stat-lbl">En línea ahora</div><div class="ap-stat-val" style="color:var(--bl,#2980b9)" id="ap-online">${s.online}</div></div>
              <div class="ap-stat"><div class="ap-stat-lbl">Mensajes hoy</div><div class="ap-stat-val" style="color:var(--go)">${(s.messages||{}).today||0}</div></div>
              <div class="ap-stat"><div class="ap-stat-lbl">Última hora</div><div class="ap-stat-val">${(s.messages||{}).last_hour||0}</div></div>
              <div class="ap-stat"><div class="ap-stat-lbl">Msgs totales</div><div class="ap-stat-val">${(s.messages||{}).total||0}</div></div>
              <div class="ap-stat"><div class="ap-stat-lbl">Nuevos hoy</div><div class="ap-stat-val" style="color:var(--onl)">${s.users.new_today||0}</div></div>
            </div>
            <div id="ap-rooms-activity"></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
              <div class="ap-card">
                <div class="ap-card-hdr">⏳ Pendientes de aprobación
                  <button class="ap-btn b-go" onclick="openAdminPanel('pending')">Ver todos</button></div>
                <table class="ap-table"><thead><tr><th>Usuario</th><th>Personaje</th><th>Fecha</th><th></th></tr></thead>
                <tbody>${dash.pendingUsers.slice(0,6).map(u=>`
                  <tr onclick="apUserDetail('${u.id}')">
                    <td><strong>${esc(u.username)}</strong></td>
                    <td style="font-size:.8rem;color:var(--txm)">${esc(u.race||'')} ${esc(u.class||'')}</td>
                    <td style="font-size:.78rem;color:var(--txm)">${fd(u.created_at)}</td>
                    <td><button class="ap-btn b-ok" onclick="event.stopPropagation();apApprove('${u.id}')">✓</button></td>
                  </tr>`).join('')||'<tr><td colspan="4" style="text-align:center;padding:1.5rem;color:var(--txm)">Sin pendientes ✓</td></tr>'}
                </tbody></table>
              </div>
              <div class="ap-card">
                <div class="ap-card-hdr">🔌 En línea (${conns.length})</div>
                <table class="ap-table"><thead><tr><th>Usuario</th><th>Sala</th><th>IP</th><th></th></tr></thead>
                <tbody>${conns.slice(0,8).map(c=>`
                  <tr onclick="apUserDetail('${c.user_id}')">
                    <td><strong>${esc(c.username)}</strong></td>
                    <td style="font-size:.8rem">${esc(c.room_name||'—')}</td>
                    <td><code style="font-size:.74rem">${c.ip_address||'—'}</code></td>
                    <td><button class="ap-btn b-dn" onclick="event.stopPropagation();apKick('${c.socket_id}','${esc(c.username)}')">⚡</button></td>
                  </tr>`).join('')||'<tr><td colspan="4" style="text-align:center;padding:1.5rem;color:var(--txm)">Nadie conectado</td></tr>'}
                </tbody></table>
              </div>
            </div>`;
    // Rooms activity table (populated separately to avoid nested template literals)
    if (dash.rooms && dash.rooms.length) {
        var _rt = document.getElementById('ap-rooms-activity');
        if (_rt) {
            _rt.innerHTML = '<div class="ap-card" style="margin:.5rem 0 1rem">'
                + '<div class="ap-card-hdr">🏠 Actividad por sala — 24h</div>'
                + '<table class="ap-table"><thead><tr><th>Sala</th><th>En línea</th><th>Msgs hoy</th></tr></thead><tbody>'
                + dash.rooms.map(function(r){
                    return '<tr><td>'+(r.icon||'💬')+' '+esc(r.name)+'</td>'
                        +'<td style="text-align:center">'+r.online+'</td>'
                        +'<td style="text-align:center">'+r.msgs_today+'</td></tr>';
                  }).join('')
                + '</tbody></table></div>';
        }
    }
    } catch(e) {
        apContainer().innerHTML = `<div style="color:var(--red);padding:1rem">Error: ${esc(e.message)}</div>`;
    }
}

/* ── PENDIENTES ───────────────────────────────────────────────────────────── */
async function apPending() {
    AP.current="pending"; apLoading();
    const {users} = await apApi('GET','/api/admin/users?status=pending&limit=100');
    apContainer().innerHTML = `
        <div class="ap-card">
          <table class="ap-table"><thead><tr><th>Usuario</th><th>Raza</th><th>Clase</th><th>Profesión</th><th>Fecha</th><th>Acciones</th></tr></thead>
          <tbody>${users.map(u=>`<tr onclick="apUserDetail('${u.id}')">
            <td><strong>${esc(u.username)}</strong></td>
            <td>${esc(u.race||'—')}</td><td>${esc(u.class||'—')}</td><td>${esc(u.profession||'—')}</td>
            <td style="font-size:.78rem;color:var(--txm)">${fd(u.created_at)}</td>
            <td onclick="event.stopPropagation()"><div style="display:flex;gap:.35rem">
              <button class="ap-btn b-ok" onclick="apApprove('${u.id}')">✓ Aprobar</button>
              <button class="ap-btn b-dn" onclick="apBan('${u.id}','${esc(u.username)}')">✕ Rechazar</button>
            </div></td>
          </tr>`).join('')||'<tr><td colspan="6" style="text-align:center;padding:2rem;color:var(--txm)">Sin pendientes ✓</td></tr>'}
          </tbody></table>
        </div>`;
}

/* ── USUARIOS ─────────────────────────────────────────────────────────────── */
async function apUsers() {
    AP.current="users"; apLoading();
    const search = '', status = '';
    const {users} = await apApi('GET','/api/admin/users?limit=100');
    apContainer().innerHTML = `
        <div class="ap-filters">
          <input class="ap-fi" id="au-search" placeholder="🔍 Buscar usuario..." oninput="apUsersFilter()" style="flex:1;min-width:140px"/>
          <select class="ap-fi" id="au-status" onchange="apUsersFilter()">
            <option value="">Todos</option><option value="active">Activos</option>
            <option value="pending">Pendientes</option><option value="suspended">Suspendidos</option>
            <option value="banned">Baneados</option>
          </select>
          <button class="ap-btn b-gh" onclick="apUsers()">↺</button>
        </div>
        <div class="ap-card">
          <table class="ap-table"><thead><tr><th>Usuario</th><th>Personaje</th><th>Estado</th><th>Rol</th><th>Nv.</th><th>Msgs</th><th>Últ. IP</th><th>Acciones</th></tr></thead>
          <tbody id="ap-users-tbody">${renderUsersRows(users)}</tbody></table>
        </div>`;
    window._apAllUsers = users;
}

function renderUsersRows(users) {
    return users.map(u => {
        const isMod   = u.role === 'moderator';
        const isAdmin = u.role === 'admin';
        const muted   = u.muted_until && new Date(u.muted_until) > new Date();
        const isSelf  = u.id === S?.user?.id;
        return `<tr onclick="apUserDetail('${u.id}')">
          <td><strong>${esc(u.username)}</strong>${muted?'<span class="bx bx-mut" style="margin-left:4px">🔇</span>':''}</td>
          <td style="font-size:.8rem;color:var(--txm)">${esc(u.race||'')} ${esc(u.class||'')}</td>
          <td><span class="bx bx-${u.status}">${u.status}</span></td>
          <td><span class="bx bx-${isAdmin?'adm':isMod?'mod':'usr'}">${u.role}</span></td>
          <td>${u.level||1}</td>
          <td>${u.msg_count||0}</td>
          <td><code style="font-size:.74rem">${u.last_ip||'—'}</code>
            ${u.last_ip?`<button class="ap-btn b-gh" style="padding:1px 4px;font-size:.75rem;margin-left:2px" onclick="event.stopPropagation();apGeoIp('${u.last_ip}')">🌍</button>`:''}
          </td>
          <td onclick="event.stopPropagation()"><div style="display:flex;gap:.3rem;flex-wrap:wrap">
            ${u.status==='pending'?`<button class="ap-btn b-ok" onclick="apApprove('${u.id}')">✓</button>`:''}
            ${u.status==='active'&&!isSelf?`<button class="ap-btn b-yw" onclick="apMute('${u.id}','${esc(u.username)}')">🔇</button>`:''}
            ${!isSelf&&u.status!=='banned'?`<button class="ap-btn b-dn" onclick="apBan('${u.id}','${esc(u.username)}')">🚫</button>`:''}
            ${u.status==='banned'?`<button class="ap-btn b-ok" onclick="apUnban('${u.id}')">↩</button>`:''}
            <button class="ap-btn b-gh" onclick="apUserDetail('${u.id}')">👁</button>
          </div></td>
        </tr>`;
    }).join('') || '<tr><td colspan="8" style="text-align:center;padding:2rem;color:var(--txm)">Sin usuarios</td></tr>';
}

function apUsersFilter() {
    const q = document.getElementById('au-search')?.value?.toLowerCase()||'';
    const st = document.getElementById('au-status')?.value||'';
    const filtered = (window._apAllUsers||[]).filter(u =>
        (!q || u.username.toLowerCase().includes(q)) &&
        (!st || u.status === st));
    document.getElementById('ap-users-tbody').innerHTML = renderUsersRows(filtered);
}

/* ── DETALLE DE USUARIO ───────────────────────────────────────────────────── */
async function apUserDetail(id) {
    try {
        const d = await apApi('GET',`/api/admin/users/${id}`);
        const u = d.user;
        const isSelf  = u.id === S?.user?.id;
        const isMuted = u.muted_until && new Date(u.muted_until) > new Date();
        const face = window.FACES?.[(u.face_id||1)-1] || '👤';
        const clr  = window.CLS_COLOR?.[u.class] || '#c9a84c';
        const xpNext = Math.pow((u.level||1)+1,2)*50;
        const xpCurr = Math.pow(u.level||1,2)*50;
        const bar = Math.max(0,Math.min(100,Math.round(((u.xp-xpCurr)/(xpNext-xpCurr))*100)))||0;

        apModal(`👤 ${u.username}`, `
            <div style="display:flex;align-items:center;gap:.85rem;margin-bottom:1rem">
              <div style="font-size:2.5rem">${face}</div>
              <div>
                <div style="font-family:'Cinzel',serif;color:${clr};font-size:1rem">${esc(u.username)}</div>
                <div style="font-size:.82rem;color:var(--txm)">${esc(u.race||'')} · ${esc(u.class||'')} / ${esc(u.profession||'')}</div>
                <div style="margin-top:.3rem;display:flex;gap:.35rem;flex-wrap:wrap">
                  <span class="bx bx-${u.status}">${u.status}</span>
                  <span class="bx bx-${u.role==='admin'?'adm':u.role==='moderator'?'mod':'usr'}">${u.role}</span>
                  ${isMuted?'<span class="bx bx-mut">🔇 Silenciado</span>':''}
                </div>
              </div>
            </div>

            <!-- Cambiar rol -->
            ${!isSelf?`<div style="margin-bottom:1rem;padding:.65rem;background:var(--b2);border:1px solid var(--bd);border-radius:8px">
              <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:.07em;color:var(--txm);margin-bottom:.4rem">Cambiar rol</div>
              <div style="display:flex;gap:.5rem;flex-wrap:wrap">
                <button class="ap-btn b-gh" onclick="apChangeRole('${u.id}','user')" style="${u.role==='user'?'border-color:var(--go);color:var(--go)':''}">👤 Usuario</button>
                <button class="ap-btn b-mod" onclick="apChangeRole('${u.id}','moderator')" style="${u.role==='moderator'?'border-color:var(--go);color:var(--go)':''}">🛡️ Moderador</button>
                <button class="ap-btn b-adm" onclick="apChangeRole('${u.id}','admin')" style="${u.role==='admin'?'border-color:var(--go);color:var(--go)':''}">⚔ Admin</button>
              </div>
            </div>`:''}

            <!-- Asignar título personalizado -->
            <div style="margin-bottom:1rem;padding:.65rem;background:var(--b2);border:1px solid var(--bd);border-radius:8px">
              <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:.07em;color:var(--txm);margin-bottom:.4rem">Título personalizado</div>
              <div style="display:flex;gap:.5rem">
                <input class="ap-fi" id="ud-title" value="${esc(u.custom_title||'')}" placeholder="Dejar vacío para quitar" style="flex:1"/>
                <button class="ap-btn b-go" onclick="apSetTitle('${u.id}')">Guardar</button>
              </div>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:.5rem;margin-bottom:1rem">
              <div style="background:var(--b1);border:1px solid var(--bd);border-radius:6px;padding:.5rem .7rem">
                <div style="font-size:.66rem;text-transform:uppercase;color:var(--txm)">XP / Nivel</div>
                <div style="font-size:.88rem;color:var(--go)">${u.xp||0} XP · Nv.${u.level||1}</div>
                <div style="background:var(--bd);border-radius:4px;height:5px;margin-top:.3rem">
                  <div style="width:${bar}%;height:100%;background:var(--go);border-radius:4px"></div></div>
              </div>
              <div style="background:var(--b1);border:1px solid var(--bd);border-radius:6px;padding:.5rem .7rem">
                <div style="font-size:.66rem;text-transform:uppercase;color:var(--txm)">Mensajes</div>
                <div style="font-size:.88rem">${u.msg_count||0}</div>
              </div>
              <div style="background:var(--b1);border:1px solid var(--bd);border-radius:6px;padding:.5rem .7rem">
                <div style="font-size:.66rem;text-transform:uppercase;color:var(--txm)">Advertencias</div>
                <div style="font-size:.88rem;color:${(u.warn_count||0)>0?'var(--yw,#e67e22)':'var(--tx)'}">${u.warn_count||0}</div>
              </div>
            </div>
            ${u.ban_reason?`<div style="background:rgba(192,57,43,.1);border:1px solid rgba(192,57,43,.3);border-radius:6px;padding:.5rem .75rem;font-size:.82rem;margin-bottom:1rem">
              <span style="color:var(--red)">Razón ban:</span> ${esc(u.ban_reason)}</div>`:''}
            ${isMuted?`<div style="background:rgba(142,68,173,.1);border:1px solid rgba(142,68,173,.3);border-radius:6px;padding:.5rem .75rem;font-size:.82rem;margin-bottom:1rem">
              <span style="color:#b975e8">Silenciado hasta:</span> ${fdt(u.muted_until)}<br/>
              <span style="color:#b975e8">Razón:</span> ${esc(u.mute_reason||'—')}</div>`:''}
            <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:.07em;color:var(--txm);margin-bottom:.4rem">Últimos 10 eventos</div>
            <div style="max-height:180px;overflow-y:auto">
              ${d.auditLog.slice(0,10).map(l=>`<div class="audit-row">
                <span class="audit-t">${fdt(l.created_at)}</span>
                <span class="audit-a">${l.action}</span>
                <span class="audit-m">${l.ip_address||''} ${l.geo_city||''} ${l.geo_country||''}</span>
              </div>`).join('')||'<div style="color:var(--txm);padding:.5rem">Sin actividad</div>'}
            </div>`,
            [
                !isSelf && u.status==='pending'     ? {lbl:'✓ Aprobar',   cls:'b-ok', fn:()=>apApprove(u.id).then(closeModal)} : null,
                !isSelf && u.status==='active'      ? {lbl:'🔇 Silenciar', cls:'b-yw', fn:()=>{closeModal();apMute(u.id,u.username);}} : null,
                !isSelf && isMuted                  ? {lbl:'🔊 Quitar silencio', cls:'b-gh', fn:()=>apUnmute(u.id).then(()=>{closeModal();toast('Silencio removido','success');})} : null,
                !isSelf && u.status!=='banned'      ? {lbl:'🚫 Banear',    cls:'b-dn', fn:()=>{closeModal();apBan(u.id,u.username);}} : null,
                !isSelf && u.status==='banned'      ? {lbl:'↩ Desbanear',  cls:'b-ok', fn:()=>apUnban(u.id).then(()=>{closeModal();toast('Desbaneado','success');})} : null,
            ].filter(Boolean));
    } catch(e) { toast('Error: '+e.message,'error'); }
}

/* ── ACCIONES DE USUARIO ──────────────────────────────────────────────────── */
async function apApprove(id) {
    const {message} = await apApi('POST',`/api/admin/users/${id}/approve`);
    toast(message||'Aprobado','success');
    if(AP.current==='pending') apPending();
    else if(AP.current==='users') apUsers();
    else if(AP.current==='dashboard') apDash();
    const nb = document.getElementById('nb-pending');
    if(nb) nb.textContent = Math.max(0,(parseInt(nb.textContent)||1)-1);
}

async function apChangeRole(userId, role) {
    if(userId===S?.user?.id){toast('No podés cambiar tu propio rol','warn');return;}
    try {
        await apApi('PUT',`/api/admin/users/${userId}`,{role});
        toast(`Rol cambiado a ${role}`,'success');
        closeModal();
        if(AP.current==='users') apUsers();
    } catch(e) { toast(e.message,'error'); }
}

async function apSetTitle(userId) {
    // Leer el valor del input AHORA (antes de que el modal se cierre)
    const inp   = document.getElementById('ud-title');
    const title = inp ? (inp.value.trim() || null) : null;
    if (!inp) { toast('Error: campo no encontrado','error'); return; }
    try {
        await apApi('PUT',`/api/admin/users/${userId}`, { custom_title: title });
        toast(title ? `Título: "${title}" guardado` : 'Título removido','success');
        // Recargar el detalle del usuario para ver el cambio
        closeModal();
        apUserDetail(userId);
    } catch(e) { toast(e.message,'error'); }
}

function apMute(id, username) {
    if(id===S?.user?.id){toast('No podés silenciarte a vos mismo','warn');return;}
    apModal(`🔇 Silenciar: ${username}`,`
        <div class="ap-fg"><label class="ap-fl">Duración (minutos)</label>
          <input class="ap-fc" id="mute-min" type="number" value="30" min="1" max="10080"/></div>
        <div class="ap-fg"><label class="ap-fl">Razón</label>
          <input class="ap-fc" id="mute-r" placeholder="Comportamiento inapropiado..."/></div>`,
        [{lbl:'🔇 Silenciar',cls:'b-yw',async fn(){
            await apApi('POST',`/api/admin/users/${id}/mute`,{
                minutes:document.getElementById('mute-min').value,
                reason: document.getElementById('mute-r').value,
            });
            toast(`${username} silenciado`,'success'); closeModal();
            if(AP.current==='users') apUsers();
        }}]);
}

async function apUnmute(id) {
    await apApi('POST',`/api/admin/users/${id}/unmute`);
    toast('Silencio removido','success');
    if(AP.current==='users') apUsers();
}

function apBan(id, username) {
    if(id===S?.user?.id){toast('No podés banearte a vos mismo','warn');return;}
    apModal(`🚫 Banear: ${username}`,`
        <div class="ap-fg"><label class="ap-fl">Razón del ban</label>
          <textarea class="ap-fc" id="ban-r" placeholder="Motivo..." rows="3"></textarea></div>
        <div style="display:flex;align-items:center;gap:.5rem;margin-top:.25rem">
          <input type="checkbox" id="ban-ip"/><label style="font-size:.85rem;cursor:pointer" for="ban-ip">También banear IP del usuario</label>
        </div>`,
        [{lbl:'🚫 Confirmar ban',cls:'b-dn',async fn(){
            await apApi('POST',`/api/admin/users/${id}/ban`,{
                reason:document.getElementById('ban-r').value,
                banIp: document.getElementById('ban-ip').checked,
            });
            toast(`${username} baneado`,'success'); closeModal();
            if(AP.current==='users'||AP.current==='pending') apUsers();
            if(AP.current==='dashboard') apDash();
        }}]);
}

async function apUnban(id) {
    await apApi('POST',`/api/admin/users/${id}/unban`);
    toast('Ban removido','success');
    if(AP.current==='users') apUsers();
}

async function apKick(socketId, username) {
    if(!confirm(`¿Expulsar a ${username}?`)) return;
    await apApi('POST',`/api/admin/connections/${socketId}/kick`,{reason:'Expulsado por el administrador'});
    toast(`${username} expulsado`,'success');
    if(AP.current==='conns') apConns();
    if(AP.current==='dashboard') apDash();
}

/* ── CONEXIONES ───────────────────────────────────────────────────────────── */
async function apConns() {
    AP.current="conns"; apLoading();
    const conns = await apApi('GET','/api/admin/connections');
    apContainer().innerHTML = `
        <div class="ap-filters">
          <span style="font-size:.82rem;color:var(--txm)">${conns.length} conexiones activas</span>
          <button class="ap-btn b-gh" onclick="apConns()">↺ Actualizar</button>
        </div>
        <div class="ap-card">
          <table class="ap-table"><thead><tr><th>Usuario</th><th>Personaje</th><th>Sala</th><th>IP</th><th>País</th><th>Conectado hace</th><th></th></tr></thead>
          <tbody>${conns.map(c=>{
              const mins=Math.round((Date.now()-new Date(c.connected_at).getTime())/60000);
              return `<tr onclick="apUserDetail('${c.user_id}')">
                <td><strong>${esc(c.username)}</strong></td>
                <td style="font-size:.8rem">${esc(c.race||'')} ${esc(c.class||'')}</td>
                <td style="font-size:.82rem">${esc(c.room_name||'—')}</td>
                <td><code style="font-size:.74rem">${c.ip_address||'—'}</code>
                  ${c.ip_address?`<button class="ap-btn b-gh" style="padding:1px 4px;font-size:.74rem" onclick="event.stopPropagation();apGeoIp('${c.ip_address}')">🌍</button>`:''}
                </td>
                <td style="font-size:.8rem">${c.geo_country||'—'}${c.geo_city?' / '+c.geo_city:''}</td>
                <td style="font-size:.8rem;color:var(--txm)">${mins<1?'Recién':mins+' min'}</td>
                <td onclick="event.stopPropagation()">
                  <button class="ap-btn b-dn" onclick="apKick('${c.socket_id}','${esc(c.username)}')">⚡ Expulsar</button>
                </td>
              </tr>`;
          }).join('')||'<tr><td colspan="7" style="text-align:center;padding:2rem;color:var(--txm)">Sin conexiones</td></tr>'}
          </tbody></table>
        </div>`;
}

/* ── SALAS ────────────────────────────────────────────────────────────────── */
async function apRooms() {
    AP.current="rooms"; apLoading();
    const rooms = await apApi('GET','/api/admin/rooms');
    const KIND_LABEL = { chat:'💬 Chat', docs:'📄 Docs', web:'🌐 Web' };
    apContainer().innerHTML = `
        <div class="ap-filters">
          <button class="ap-btn b-go" onclick="apRoomForm(null)">＋ Nueva sala</button>
          <button class="ap-btn b-gh" onclick="apRooms()">↺</button>
        </div>
        <div class="ap-card">
          <table class="ap-table"><thead><tr>
            <th>Sala</th><th>Modalidad</th><th>Acceso</th><th>Online</th><th>Msgs</th><th>Estado</th><th>Acciones</th>
          </tr></thead>
          <tbody>${rooms.map(r=>`<tr>
            <td>
              <span style="font-size:1.05rem">${r.icon}</span> <strong>${esc(r.name)}</strong>
              ${r.topic?`<div style="font-size:.76rem;color:var(--txm)">${esc(r.topic)}</div>`:''}
              ${r.kind==='web' && r.embed_url?`<div style="font-size:.72rem;color:var(--txm);overflow:hidden;text-overflow:ellipsis;max-width:200px;white-space:nowrap">${esc(r.embed_url)}</div>`:''}
            </td>
            <td><span class="bx" style="background:${r.kind==='docs'?'var(--yw,#e67e22)22':r.kind==='web'?'var(--b5)':'var(--b4)'};color:${r.kind==='docs'?'var(--yw,#e67e22)':r.kind==='web'?'var(--go)':'var(--txm)'};border-radius:5px;padding:.15rem .45rem;font-size:.75rem">${KIND_LABEL[r.kind]||'💬 Chat'}</span></td>
            <td><span class="bx bx-${r.type==='public'?'act':r.type==='admin'?'adm':'sus'}">${r.type}</span></td>
            <td style="color:var(--onl)">${r.kind==='web'?'—':r.online_count||0}</td>
            <td>${r.msg_count||0}</td>
            <td><span class="bx bx-${r.is_active?'act':'sus'}">${r.is_active?'activa':'inactiva'}</span></td>
            <td><div style="display:flex;gap:.3rem">
              <button class="ap-btn b-gh" onclick='apRoomForm(${JSON.stringify(r).replace(/'/g,"&#39;")})'>✏️</button>
              <button class="ap-btn b-yw" onclick="apPurgeRoom('${r.id}','${esc(r.name)}')">🧹</button>
              <button class="ap-btn b-dn" onclick="apDeleteRoom('${r.id}','${esc(r.name)}')">🗑️</button>
            </div></td>
          </tr>`).join('')}
          </tbody></table>
        </div>`;
}

// ── Icon picker helpers ──────────────────────────────────────────────────────
const ROOM_ICONS = [
  '💬','🗨️','📢','📣','🔔','📡','🗣️','✉️','📩','💌',
  '📱','💻','🖥️','⌨️','📞','📟','🔊','🎙️','📻','🖨️',
  '⚔️','🛡️','🏹','🧙','🧝','🧟','🧛','🦸','🐉','💀',
  '👑','🔮','✨','🌟','⭐','🌙','☀️','🔥','❄️','⚡',
  '🧪','📜','🗺️','🏴‍☠️','⚓','🏰','🗝️','🔑','⚙️','🛠️',
  '🪄','🧿','🔯','⚜️','🔱','🩸','🌑','🪬','🫧','💠',
  '🧌','👺','👹','👻','💫','☄️','🌪️','🌊','🌈','🌀',
  '💎','🪙','🏆','🎯','🎲','🎭','🎪','🎨','🎵','🎶',
  '🥇','🥈','🥉','🏅','🎖️','🎗️','🏵️','🎀','🎁','🎊',
  '🎉','🎈','🎆','🎇','🪩','🪅','🎠','🎡','🎢','🎪',
  '🌲','🌿','🌾','🌺','🌸','🍀','🍁','🌵','🎋','🎍',
  '🌊','🌋','🏔️','🏝️','🏜️','🏕️','🌄','🌅','🌃','🌆',
  '🐺','🦊','🦁','🐍','🦅','🐗','🦌','🦋','🐝','🦉',
  '🐉','🦄','🐯','🦝','🦎','🦈','🦭','🦬','🦏','🐊',
  '🏠','🏛️','🏟️','🏯','⛩️','🕌','🕍','⛪','🏗️','🏚️',
  '🍺','🍷','🍻','🧉','🍵','☕','🍖','🍗','🥩','🍕',
  '📚','📖','🔬','💡','🔭','🧬','🧫','🧪','⚗️','🔩',
  '🖊️','✏️','📐','📏','🗒️','📋','🗃️','📊','📈','📉',
  '♾️','🌀','💫','🎯','🪃','🛡️','🪖','🗡️','🔭','🧲',
  '🫀','🧠','👁️','👋','🤝','✊','🙏','💪','🫶','🤲',
];

function apIconGrid(current) {
    return ROOM_ICONS.map(e =>
        `<span class="ri-opt${e===current?' selected':''}" onclick="selectRoomIcon('${e}')">${e}</span>`
    ).join('');
}

function toggleIconPicker() {
    const p = document.getElementById('rf-icon-picker');
    if (!p) return;
    p.style.display = p.style.display === 'none' ? '' : 'none';
    if (p.style.display !== 'none') {
        // Close when clicking outside
        setTimeout(() => {
            const close = (e) => {
                if (!p.contains(e.target) && !document.getElementById('rf-i-preview').contains(e.target)) {
                    p.style.display = 'none';
                    document.removeEventListener('click', close);
                }
            };
            document.addEventListener('click', close);
        }, 10);
    }
}

function selectRoomIcon(emoji) {
    const inp  = document.getElementById('rf-i');
    const prev = document.getElementById('rf-i-preview');
    const pick = document.getElementById('rf-icon-picker');
    if (inp)  inp.value        = emoji;
    if (prev) prev.textContent = emoji;
    // Update selected state
    pick?.querySelectorAll('.ri-opt').forEach(el =>
        el.classList.toggle('selected', el.textContent === emoji));
    setTimeout(() => { if (pick) pick.style.display = 'none'; }, 150);
}

function apRoomForm(room) {
    const isE = !!room;
    const curKind = room?.kind || 'chat';
    apModal(isE?`Editar: ${room.name}`:'Nueva sala',`
        <div style="display:grid;grid-template-columns:3fr 1fr;gap:.65rem">
          <div class="ap-fg"><label class="ap-fl">Nombre</label><input class="ap-fc" id="rf-n" value="${esc(room?.name||'')}"/></div>
          <div class="ap-fg" style="position:relative">
            <label class="ap-fl">Icono</label>
            <div class="rf-icon-row">
              <div class="rf-icon-preview" id="rf-i-preview" onclick="toggleIconPicker()">${room?.icon||'💬'}</div>
              <input type="hidden" id="rf-i" value="${room?.icon||'💬'}"/>
              <span style="font-size:.75rem;color:var(--txm)">Clic para cambiar</span>
            </div>
            <div id="rf-icon-picker" class="rf-icon-picker" style="display:none">${apIconGrid(room?.icon||'💬')}</div>
          </div>
        </div>
        <div class="ap-fg"><label class="ap-fl">Descripción</label><input class="ap-fc" id="rf-d" value="${esc(room?.description||'')}"/></div>
        <div class="ap-fg"><label class="ap-fl">Topic</label><input class="ap-fc" id="rf-t" value="${esc(room?.topic||'')}"/></div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:.65rem">
          <div class="ap-fg"><label class="ap-fl">Tipo de sala</label>
            <select class="ap-fc" id="rf-kind">
              <option value="chat" ${curKind==='chat'?'selected':''}>💬 Chat</option>
              <option value="docs" ${curKind==='docs'?'selected':''}>📄 Documentos PDF</option>
              <option value="web"  ${curKind==='web' ?'selected':''}>🌐 Web embebida</option>
            </select></div>
          <div class="ap-fg"><label class="ap-fl">Acceso</label>
            <select class="ap-fc" id="rf-tp">
              <option value="public"  ${room?.type==='public' ?'selected':''}>🌍 Pública</option>
              <option value="private" ${room?.type==='private'?'selected':''}>🔐 Privada</option>
              <option value="admin"   ${room?.type==='admin'  ?'selected':''}>👮 Solo staff</option>
            </select></div>
        </div>
        <div id="rf-web-fields" style="display:${curKind==='web'?'':'none'}">
          <div class="ap-fg">
            <label class="ap-fl">🌐 URL a embeber</label>
            <input class="ap-fc" id="rf-embed-url" value="${esc(room?.embed_url||'')}"
              placeholder="https://ejemplo.com"/>
            <small style="color:var(--txm);font-size:.73rem">
              Sitios que bloquean iframes (Instagram, Twitter/X, Facebook) mostrarán un botón para abrir en pestaña nueva.
            </small>
          </div>
        </div>
        <div id="rf-docs-fields" style="display:${curKind==='docs'?'':'none'}">
          <div class="ap-fg"><label class="ap-fl">¿Quién puede subir PDFs?</label>
            <select class="ap-fc" id="rf-upload-perm">
              <option value="all"   ${(room?.upload_permission||'all')==='all'  ?'selected':''}>Todos los miembros</option>
              <option value="staff" ${(room?.upload_permission||'')==='staff'   ?'selected':''}>Solo staff (admin/mod)</option>
            </select>
          </div>
        </div>
        <div id="rf-chat-fields" style="display:${curKind!=='chat'?'none':''}">
          <div class="ap-fg">
            <label class="ap-fl">🖼️ Imagen de sala (URL directa — banner)</label>
            <input class="ap-fc" id="rf-img" value="${esc(room?.image_url||'')}" placeholder="https://i.imgur.com/ejemplo.jpg"/>
            ${room?.image_url?`<img src="${esc(room.image_url)}" style="width:100%;max-height:60px;object-fit:cover;border-radius:6px;margin-top:.3rem;border:1px solid var(--bd)" onerror="this.style.display='none'"/>`:''} 
          </div>
          <div class="ap-fg"><label class="ap-fl">Modo lento (segundos, 0=off)</label>
            <input class="ap-fc" type="number" id="rf-sl" value="${room?.slow_mode_sec||0}" min="0" max="3600"/></div>
        </div>
        ${isE?`<div style="display:flex;gap:1rem;flex-wrap:wrap">
          <label style="display:flex;align-items:center;gap:.4rem;cursor:pointer;font-size:.85rem">
            <input type="checkbox" id="rf-ac" ${room?.is_active?'checked':''}/> Sala activa</label>
          <label style="display:flex;align-items:center;gap:.4rem;cursor:pointer;font-size:.85rem">
            <input type="checkbox" id="rf-ao" ${room?.admin_only?'checked':''}/> 🔒 Solo admin habla</label>
        </div>`:''}`,
        [{lbl:isE?'💾 Guardar':'＋ Crear',cls:'b-go', async fn(){
            const kind = document.getElementById('rf-kind')?.value || 'chat';
            const payload={
                name:        document.getElementById('rf-n').value.trim(),
                icon:        document.getElementById('rf-i').value||'💬',
                description: document.getElementById('rf-d').value,
                topic:       document.getElementById('rf-t').value,
                type:        document.getElementById('rf-tp').value,
                kind,
                embed_url:         kind==='web'  ? (document.getElementById('rf-embed-url')?.value?.trim()||null) : null,
                upload_permission: kind==='docs' ? (document.getElementById('rf-upload-perm')?.value||'all')      : 'all',
                image_url:         kind==='chat' ? (document.getElementById('rf-img')?.value?.trim()||null)       : null,
                slow_mode_sec:     kind==='chat' ? parseInt(document.getElementById('rf-sl')?.value||'0')         : 0,
                ...(isE?{
                    is_active:  document.getElementById('rf-ac').checked,
                    admin_only: document.getElementById('rf-ao').checked,
                }:{}),
            };
            if (!payload.name) { toast('El nombre es requerido','error'); return; }
            if (kind==='web' && !payload.embed_url) { toast('La URL es requerida para salas web','error'); return; }
            if(isE) await apApi('PUT',`/api/admin/rooms/${room.id}`,payload);
            else    await apApi('POST','/api/admin/rooms',payload);
            toast(isE?'Sala actualizada':'Sala creada','success');
            closeModal(); apRooms();
            if(window.loadRooms) loadRooms();
        }}]);
    // Wire kind change listener after modal DOM is ready (avoids inline onchange scope issues)
    setTimeout(() => {
        const ks = document.getElementById('rf-kind');
        if (ks) {
            ks.addEventListener('change', function() { apRoomKindChange(this.value); });
            // Apply initial state in case kind != 'chat' (edit mode)
            apRoomKindChange(ks.value);
        }
    }, 0);
}

function apRoomKindChange(kind) {
    const web  = document.getElementById('rf-web-fields');
    const docs = document.getElementById('rf-docs-fields');
    const chat = document.getElementById('rf-chat-fields');
    if (web)  web.style.display  = kind === 'web'  ? '' : 'none';
    if (docs) docs.style.display = kind === 'docs' ? '' : 'none';
    if (chat) chat.style.display = kind === 'chat' ? '' : 'none';
}

async function apPurgeRoom(id, name) {
    if(!confirm(`¿Purgar TODOS los mensajes de "${name}"?`)) return;
    const d = await apApi('DELETE',`/api/admin/rooms/${id}/messages`);
    toast(`${d.purged} mensajes eliminados`,'success');
}
async function apDeleteRoom(id, name) {
    if(!confirm(`¿Eliminar la sala "${name}"? Esta acción es irreversible.`)) return;
    try {
        await apApi('DELETE',`/api/admin/rooms/${id}`);
        toast('Sala eliminada','success');
        apRooms();
        if(window.loadRooms) loadRooms();
    } catch(e) {
        toast('Error al eliminar: ' + e.message, 'error');
    }
}

/* ── AUDITORÍA ────────────────────────────────────────────────────────────── */
async function apAudit() {
    AP.current="audit"; apLoading();
    const ip  = '', action = '', from = '', to = '';
    const renderAudit = async () => {
        const ip  = document.getElementById('aa-ip')?.value||'';
        const act = document.getElementById('aa-act')?.value||'';
        const fr  = document.getElementById('aa-from')?.value||'';
        const to  = document.getElementById('aa-to')?.value||'';
        const logs= await apApi('GET',`/api/admin/audit?ip=${encodeURIComponent(ip)}&action=${act}&from=${fr}&to=${to}&limit=200`);
        document.getElementById('aa-body').innerHTML = logs.map(l=>`
            <tr>
              <td style="font-size:.75rem;white-space:nowrap">${fdt(l.created_at)}</td>
              <td>${l.username?`<strong>${esc(l.username)}</strong>`:'—'}</td>
              <td style="color:var(--go);font-size:.8rem">${l.action}</td>
              <td><code style="font-size:.74rem">${l.ip_address||'—'}</code>
                ${l.ip_address?`<button class="ap-btn b-gh" style="padding:1px 3px;font-size:.72rem" onclick="apGeoIp('${l.ip_address}')">🌍</button>`:''}
              </td>
              <td style="font-size:.8rem">${l.geo_country||'—'}</td>
              <td style="font-size:.8rem">${l.geo_city||'—'}</td>
            </tr>`).join('')||'<tr><td colspan="6" style="text-align:center;padding:2rem;color:var(--txm)">Sin registros</td></tr>';
    };
    apContainer().innerHTML = `
        <div class="ap-filters">
          <input class="ap-fi" id="aa-ip" placeholder="Filtrar IP..."/>
          <select class="ap-fi" id="aa-act">
            <option value="">Todas</option>
            <option value="login_success">Login ok</option><option value="login_fail">Login fallido</option>
            <option value="register">Registro</option><option value="user_approved">Aprobación</option>
            <option value="user_banned">Ban</option><option value="user_muted">Silencio</option>
            <option value="user_warned">Advertencia</option><option value="message_deleted">Msg borrado</option>
            <option value="room_purged">Sala purgada</option>
          </select>
          <input class="ap-fi" type="date" id="aa-from"/>
          <input class="ap-fi" type="date" id="aa-to"/>
          <button class="ap-btn b-go" onclick="apAuditFilter()">🔍 Filtrar</button>
        </div>
        <div class="ap-card">
          <table class="ap-table"><thead><tr><th>Fecha/Hora</th><th>Usuario</th><th>Acción</th><th>IP</th><th>País</th><th>Ciudad</th></tr></thead>
          <tbody id="aa-body"><tr><td colspan="6" style="text-align:center;padding:1.5rem;color:var(--txm)">Usá los filtros y presioná 🔍 Filtrar</td></tr>
          </tbody></table>
        </div>`;
    window.apAuditFilter = renderAudit;
}

/* ── GEOIP ────────────────────────────────────────────────────────────────── */
async function apGeoIp(ip) {
    try {
        const {geo,history} = await apApi('GET',`/api/admin/geoip/${ip}`);
        apModal(`🌍 GeoIP: ${ip}`,`
            <div style="background:var(--b2);border:1px solid var(--bd);border-radius:8px;padding:.85rem;margin-bottom:.85rem">
              <div style="display:flex;align-items:center;gap:.75rem;margin-bottom:.5rem">
                <span style="font-size:1.8rem">${geo?.country_flag_emoji||'🌍'}</span>
                <div>
                  <div style="font-size:1rem;font-weight:600;color:var(--tb)">${geo?.city||'—'}, ${geo?.region||'—'}</div>
                  <div style="font-size:.82rem;color:var(--txm)">${geo?.country_name||'—'} · ${geo?.org||'—'}</div>
                </div>
              </div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:.3rem;font-size:.82rem;color:var(--txm)">
                <span>Coords: ${geo?.latitude||'?'}, ${geo?.longitude||'?'}</span>
                <span>TZ: ${geo?.timezone||'—'}</span>
              </div>
            </div>
            <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:.07em;color:var(--txm);margin-bottom:.5rem">Historial de esta IP</div>
            <div style="max-height:180px;overflow-y:auto">
              ${history.slice(0,20).map(h=>`<div class="audit-row">
                <span class="audit-t">${fdt(h.created_at)}</span>
                <span class="audit-a">${h.action}</span>
                <span class="audit-m">${esc(h.username||'anónimo')}</span>
              </div>`).join('')||'<div style="color:var(--txm);padding:.5rem">Sin historial</div>'}
            </div>`,
            [{lbl:'🚫 Banear esta IP',cls:'b-dn',fn(){closeModal();apIpBanForm(ip);}}]);
    } catch(e) { toast('GeoIP error: '+e.message,'error'); }
}

/* ── IP BANS ──────────────────────────────────────────────────────────────── */
async function apIpBans() {
    AP.current="ipbans"; apLoading();
    const bans = await apApi('GET','/api/admin/ip-bans');
    apContainer().innerHTML = `
        <div class="ap-filters">
          <button class="ap-btn b-dn" onclick="apIpBanForm()">＋ Banear IP</button>
          <button class="ap-btn b-gh" onclick="apIpBans()">↺</button>
        </div>
        <div class="ap-card">
          <table class="ap-table"><thead><tr><th>IP</th><th>Razón</th><th>Baneado por</th><th>Expira</th><th>Fecha</th><th></th></tr></thead>
          <tbody>${bans.map(b=>`<tr>
            <td><code>${b.ip_address}</code></td>
            <td style="font-size:.82rem">${esc(b.reason||'—')}</td>
            <td>${b.banned_by_username||'—'}</td>
            <td style="font-size:.78rem;color:var(--txm)">${b.expires_at?fd(b.expires_at):'Permanente'}</td>
            <td style="font-size:.78rem;color:var(--txm)">${fd(b.created_at)}</td>
            <td><button class="ap-btn b-gh" onclick="apRemoveIpBan('${b.id}')">↩ Quitar</button></td>
          </tr>`).join('')||'<tr><td colspan="6" style="text-align:center;padding:2rem;color:var(--txm)">Sin bans de IP</td></tr>'}
          </tbody></table>
        </div>`;
}

function apIpBanForm(prefill='') {
    apModal('Banear IP / CIDR',`
        <div class="ap-fg"><label class="ap-fl">IP o bloque CIDR (ej: 192.168.1.0/24)</label>
          <input class="ap-fc" id="ib-ip" value="${prefill}" placeholder="1.2.3.4"/></div>
        <div class="ap-fg"><label class="ap-fl">Razón</label>
          <textarea class="ap-fc" id="ib-r" placeholder="Motivo del ban..." rows="2"></textarea></div>
        <div class="ap-fg"><label class="ap-fl">Expira (vacío = permanente)</label>
          <input class="ap-fc" type="datetime-local" id="ib-ex"/></div>`,
        [{lbl:'🚫 Banear IP',cls:'b-dn',async fn(){
            await apApi('POST','/api/admin/ip-bans',{
                ip_address: document.getElementById('ib-ip').value,
                reason:     document.getElementById('ib-r').value,
                expires_at: document.getElementById('ib-ex').value||null,
            });
            toast('IP baneada','success'); closeModal(); apIpBans();
        }}]);
}

async function apRemoveIpBan(id) {
    await apApi('DELETE',`/api/admin/ip-bans/${id}`);
    toast('Ban de IP eliminado','success'); apIpBans();
}

/* ── PALABRAS BLOQUEADAS ──────────────────────────────────────────────────── */
async function apWords() {
    AP.current="words"; apLoading();
    const words = await apApi('GET','/api/admin/banned-words').catch(()=>[]);
    apContainer().innerHTML = `
        <div class="ap-card">
          <div class="ap-card-hdr">Filtro de palabras</div>
          <div style="padding:1rem">
            <div style="margin-bottom:1rem;padding:.75rem;background:var(--b2);border:1px solid var(--bd);border-radius:8px">
              <div style="display:flex;gap:.5rem;margin-bottom:.65rem">
                <input class="ap-fi" id="w-word" placeholder="Palabra o frase..." style="flex:1"/>
                <select class="ap-fi" id="w-act">
                  <option value="censor">Censurar (****)</option>
                  <option value="block">Bloquear mensaje</option>
                  <option value="warn">Advertir al usuario</option>
                </select>
                <button class="ap-btn b-go" onclick="apAddWord()">＋ Agregar</button>
              </div>
              <div style="font-size:.78rem;color:var(--txm)">
                <strong>Censurar:</strong> reemplaza la palabra con ****. 
                <strong>Bloquear:</strong> rechaza el mensaje. 
                <strong>Advertir:</strong> agrega una advertencia automática.
              </div>
            </div>
            <div id="words-list" style="display:flex;flex-wrap:wrap;gap:.35rem">
              ${words.map(w=>`
                <span class="word-chip">
                  <span style="color:var(--go)">[${w.action}]</span> ${esc(w.word)}
                  <button onclick="apRemoveWord('${w.id}')">✕</button>
                </span>`).join('')||'<span style="color:var(--txm);font-size:.85rem">Sin palabras bloqueadas</span>'}
            </div>
          </div>
        </div>`;
}

async function apAddWord() {
    const word = document.getElementById('w-word')?.value?.trim();
    const action = document.getElementById('w-act')?.value;
    if(!word){toast('Escribí una palabra','warn');return;}
    await apApi('POST','/api/admin/banned-words',{word,action});
    toast('Palabra agregada','success'); apWords();
}
async function apRemoveWord(id) {
    await apApi('DELETE',`/api/admin/banned-words/${id}`);
    toast('Palabra eliminada','success'); apWords();
}

/* ── LOGS ─────────────────────────────────────────────────────────────────── */
async function apLogs() {
    AP.current="logs"; apLoading();
    const {log} = await apApi('GET','/api/admin/server-logs');
    apContainer().innerHTML = `
        <div class="ap-filters">
          <button class="ap-btn b-gh" onclick="apLogs()">↺ Actualizar</button>
          <button class="ap-btn b-gh" onclick="document.getElementById('ap-log-out').scrollTop=99999">↓ Final</button>
        </div>
        <div id="ap-log-out">${esc(log)}</div>`;
    setTimeout(()=>{ const o=document.getElementById('ap-log-out'); if(o) o.scrollTop=o.scrollHeight; },100);
}

/* ── SETTINGS ─────────────────────────────────────────────────────────────── */
async function apSettings() {
    AP.current = 'settings';
    const el = apContainer();
    if (!el) { console.error('[apSettings] container no encontrado'); return; }

    if (S?.user?.role !== 'admin') {
        el.innerHTML = '<div style="padding:2rem;text-align:center;color:var(--txm)">Solo el administrador puede acceder.</div>';
        return;
    }

    el.innerHTML = '<div style="text-align:center;padding:3rem;color:var(--txm)">⏳ Cargando configuración...</div>';

    let settings = {}, tunnel = { running: false, url: null, log: [] };

    try {
        settings = await apApi('GET', '/api/settings');
    } catch(e) {
        el.innerHTML = '<div style="color:var(--red);padding:2rem;text-align:center">Error al cargar settings: ' + esc(e.message) + '</div>';
        return;
    }

    try {
        tunnel = await apApi('GET', '/api/tunnel/status');
    } catch(_) {
        tunnel = { running: false, url: null, log: [] };
    }

    const get = k => (settings[k] ? settings[k].value || '' : '');

    // Construir HTML en partes para evitar template literals anidados complejos
    let tunnelHtml = '';
    if (tunnel.running && tunnel.url) {
        tunnelHtml = '<div style="background:rgba(39,174,96,.12);border:1px solid rgba(39,174,96,.35);border-radius:8px;padding:.9rem">'
            + '<div style="color:var(--onl);font-weight:600;margin-bottom:.65rem">🟢 Túnel activo</div>'
            + '<div class="ap-fg"><label class="ap-fl">Tu link público</label>'
            + '<div style="display:flex;gap:.4rem">'
            + '<input class="ap-fc" id="tunnel-url-input" value="' + esc(tunnel.url) + '" readonly style="flex:1;color:var(--go);font-weight:600"/>'
            + '<button class="ap-btn b-go" onclick="apCopyTunnelUrl()">📋 Copiar</button>'
            + '</div></div>'
            + '<button class="ap-btn b-dn" style="margin-top:.5rem" onclick="apStopTunnel()">⏹ Detener túnel</button>'
            + '</div>';
    } else {
        tunnelHtml = '<div style="text-align:center;padding:.85rem;background:var(--b2);border:1px solid var(--bd);border-radius:8px">'
            + '<div style="font-size:.88rem;color:var(--txm);margin-bottom:.75rem">⚫ Túnel inactivo — solo red local</div>'
            + '<button class="ap-btn b-go" onclick="apStartTunnel()" id="tunnel-start-btn">🚀 Iniciar túnel gratuito</button>'
            + '</div>'
            + '<div style="margin-top:.85rem;background:var(--b1);border:1px solid var(--bd);border-radius:8px;padding:.8rem">'
            + '<div style="font-size:.75rem;color:var(--txm);margin-bottom:.4rem">Si cloudflared no está instalado:</div>'
            + '<code style="font-size:.71rem;color:var(--go);word-break:break-all;display:block">curl -fsSL https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o /usr/local/bin/cloudflared &amp;&amp; chmod +x /usr/local/bin/cloudflared</code>'
            + '<button class="ap-btn b-gh" style="font-size:.75rem;margin-top:.4rem" onclick="apCopyInstallCmd()">📋 Copiar</button>'
            + '</div>';
    }

    let logHtml = (tunnel.log || []).slice(-20).join('\n') || 'Sin actividad';

    el.innerHTML = '<div class="ap-2col">'
        + '<div>'
        + '<div class="ap-section">'
        + '<div class="ap-section-hdr">🖥️ Configuración del servidor</div>'
        + '<div class="ap-section-body">'
        + '<div class="ap-fg"><label class="ap-fl">Nombre del servidor</label>'
        + '<input class="ap-fc" id="ss-name" value="' + esc(get('server_name')) + '"/></div>'
        + '<div class="ap-fg"><label class="ap-fl">🖼️ Fondo del LOGIN (URL de imagen directa)</label>'
        + '<input class="ap-fc" id="ss-bg" value="' + esc(get('bg_image_url')) + '" placeholder="https://i.imgur.com/xxx.jpg"/>'
        + '<small style="color:var(--txm);font-size:.72rem">Detrás del formulario de acceso</small></div>'
        + '<div class="ap-fg"><label class="ap-fl">🖼️ Fondo del CHAT (URL de imagen directa)</label>'
        + '<input class="ap-fc" id="ss-chat-bg" value="' + esc(get('chat_bg_image_url')) + '" placeholder="https://i.imgur.com/xxx.jpg"/>'
        + '<small style="color:var(--txm);font-size:.72rem">Detrás de toda la UI del chat</small></div>'
        + '<div class="ap-fg"><label class="ap-fl">Opacidad overlay fondo chat: <span id="ss-opacity-val" style="color:var(--go)">' + (get('chat_bg_opacity')||'0.72') + '</span></label>'
        + '<input class="ap-fc" type="range" id="ss-chat-opacity" min="0" max="1" step="0.05" value="' + (get('chat_bg_opacity')||'0.72') + '" style="padding:.3rem 0"/></div>'
        + '<div class="ap-fg"><label class="ap-fl">Máx. archivo (MB)</label>'
        + '<input class="ap-fc" type="number" id="ss-mb" value="' + (get('max_file_mb')||'50') + '" min="1" max="500"/></div>'
        + '<div class="ap-fg"><label class="ap-fl">Advertencias hasta ban automático</label>'
        + '<input class="ap-fc" type="number" id="ss-warns" value="' + (get('auto_ban_warnings')||'3') + '" min="1" max="20"/></div>'
        + '<div style="display:flex;align-items:center;gap:.5rem;margin-bottom:.85rem">'
        + '<input type="checkbox" id="ss-reg" ' + (get('registration_open') !== 'false' ? 'checked' : '') + '/>'
        + '<label for="ss-reg" style="font-size:.85rem;cursor:pointer">Permitir registro de nuevos usuarios</label></div>'
        + '<div class="ap-fg" style="margin-top:.5rem">'
        + '<label class="ap-fl">📐 Posición del formulario de login</label>'
        + '<div style="display:flex;gap:.5rem">'
        + '<button class="ap-btn ' + (get('login_side')!=='right'?'b-go':'b-gh') + '" id="ss-side-left"  onclick="apSetLoginSide(\'left\')">← Login a la izquierda</button>'
        + '<button class="ap-btn ' + (get('login_side')==='right'?'b-go':'b-gh') + '" id="ss-side-right" onclick="apSetLoginSide(\'right\')">Login a la derecha →</button>'
        + '</div></div>'
        + '<div class="ap-fg">'
        + '<label class="ap-fl">↔ Espacio entre columnas: <span id="ss-gap-val">' + (get('login_gap')||'3rem') + '</span></label>'
        + '<input class="ap-fc" type="range" id="ss-gap" min="0" max="8" step="0.5" value="' + parseFloat(get('login_gap')||3) + '" style="padding:.3rem 0"/>'
        + '<small style="color:var(--txm);font-size:.72rem">0 = sin espacio — 8 = máximo separación</small></div>'
        + '<div class="ap-fg">'
        + '<label class="ap-fl">📜 Cartelera de novedades</label>'
        + '<div class="ann-editor-toolbar" id="ann-toolbar">'
        + '<button class="ann-tb-btn" onclick="annCmd(\'bold\')">𝐁</button>'
        + '<button class="ann-tb-btn" onclick="annCmd(\'italic\')"><em>I</em></button>'
        + '<button class="ann-tb-btn" onclick="annCmd(\'underline\')"><u>U</u></button>'
        + '<div class="ann-tb-sep"></div>'
        + '<button class="ann-tb-btn" onclick="annCmd(\'justifyLeft\')">⬅</button>'
        + '<button class="ann-tb-btn" onclick="annCmd(\'justifyCenter\')">≡</button>'
        + '<button class="ann-tb-btn" onclick="annCmd(\'justifyRight\')">⮕</button>'
        + '<div class="ann-tb-sep"></div>'
        + '<button class="ann-tb-btn" onclick="annCmd(\'insertUnorderedList\')">• Lista</button>'
        + '<button class="ann-tb-btn" onclick="annCmd(\'insertOrderedList\')">1. Lista</button>'
        + '<div class="ann-tb-sep"></div>'
        + '<button class="ann-tb-btn" onclick="annInsertHR()">─ Línea</button>'
        + '<button class="ann-tb-btn" onclick="annInsertLink()">🔗 Link</button>'
        + '<div class="ann-tb-sep"></div>'
        + '<select class="ann-tb-btn" onchange="annCmd(\'fontSize\',this.value);this.value=\'\'">'
        + '<option value="">Tamaño</option>'
        + '<option value="2">Pequeño</option>'
        + '<option value="3">Normal</option>'
        + '<option value="4">Grande</option>'
        + '<option value="5">Muy grande</option>'
        + '</select>'
        + '<select class="ann-tb-btn" onchange="annCmd(\'foreColor\',this.value);this.value=\'\'">'
        + '<option value="">Color</option>'
        + '<option value="#c9a84c">Dorado</option>'
        + '<option value="#2ecc71">Verde</option>'
        + '<option value="#e74c3c">Rojo</option>'
        + '<option value="#5dade2">Azul</option>'
        + '<option value="#e67e22">Naranja</option>'
        + '<option value="#d4cbb8">Blanco</option>'
        + '</select>'
        + '<div class="ann-tb-sep"></div>'
        + '<button class="ann-tb-btn" onclick="annClear()" style="color:var(--red)">✕ Limpiar</button>'
        + '</div>'
        + '<div class="ann-editor" id="ss-announcement" contenteditable="true" spellcheck="true">' + (get('announcement')||'') + '</div>'
        + '<small style="color:var(--txm);font-size:.72rem">Formato HTML. Se muestra a la derecha/izquierda del formulario de acceso.</small></div>'
        + '<button class="ap-btn b-go" onclick="apSaveServer()">💾 Guardar</button>'
        + '</div></div>'
        + '</div>'
        + '<div>'
        + '<div class="ap-section">'
        + '<div class="ap-section-hdr">🌐 Acceso externo — Cloudflare Tunnel</div>'
        + '<div class="ap-section-body">'
        + '<div style="background:var(--b1);border:1px solid var(--bd);border-radius:8px;padding:.8rem;margin-bottom:1rem;font-size:.83rem;color:var(--txm);line-height:1.65">Crea un túnel HTTPS gratuito. Genera un link <code style="color:var(--go)">xxxx.trycloudflare.com</code> que podés compartir. <strong style="color:var(--tx)">Sin cuenta, sin configuración.</strong></div>'
        + tunnelHtml
        + '<div style="margin-top:.85rem">'
        + '<div style="font-size:.72rem;text-transform:uppercase;color:var(--txm);margin-bottom:.35rem;display:flex;align-items:center;justify-content:space-between"><span>Log del túnel</span>'
        + '<button class="ap-btn b-gh" style="padding:1px 5px;font-size:.72rem" onclick="apRefreshTunnelLog()">↺</button></div>'
        + '<div id="tunnel-log" style="background:#050709;border:1px solid var(--bd);border-radius:6px;padding:.6rem;font-family:monospace;font-size:.72rem;color:#7ec17e;height:140px;overflow-y:auto;white-space:pre-wrap">' + esc(logHtml) + '</div>'
        + '</div>'
        + '</div></div>'
        + '</div>'
        + '</div>';

    const slider = document.getElementById('ss-chat-opacity');
    if (slider) {
        slider.oninput = function() {
            const v = parseFloat(this.value).toFixed(2);
            const sp = document.getElementById('ss-opacity-val');
            if (sp) sp.textContent = v;
            const ov = document.getElementById('chat-bg-overlay');
            if (ov) ov.style.background = 'rgba(8,10,15,' + this.value + ')';
        };
    }

    // Inicializar estado del lado del login
    const settings2 = await apApi('GET', '/api/settings').catch(() => ({}));
    window._loginSide = (settings2.login_side ? settings2.login_side.value : null) || 'left';

    // Slider de gap
    const gapSlider = document.getElementById('ss-gap');
    const gapVal    = document.getElementById('ss-gap-val');
    if (gapSlider && gapVal) {
        gapSlider.oninput = function() {
            const v = this.value + 'rem';
            gapVal.textContent = v;
            // Preview en vivo en la pantalla de login (si estuviera visible)
            const cols = document.getElementById('auth-columns');
            if (cols) cols.style.setProperty('--login-gap', v);
        };
    }

    // Hacer el contenteditable enfocable
    const annEd = document.getElementById('ss-announcement');
    if (annEd) {
        document.execCommand('defaultParagraphSeparator', false, 'p');
    }
}




async function apSaveServer() {
    const chatBgUrl     = document.getElementById('ss-chat-bg')?.value?.trim() || '';
    const chatBgOpacity = document.getElementById('ss-chat-opacity')?.value || '0.72';
    // Rich text: leer innerHTML del contenteditable
    const annEl         = document.getElementById('ss-announcement');
    const announcement  = annEl ? annEl.innerHTML.trim() : '';
    const annUpdated    = announcement ? new Date().toLocaleDateString('es-AR', {day:'2-digit',month:'2-digit',year:'numeric'}) : '';
    const loginSide     = window._loginSide || 'left';
    const gapVal        = document.getElementById('ss-gap')?.value || '3';
    const loginGap      = gapVal + 'rem';
    await Promise.all([
        apApi('PUT','/api/settings/server_name',          {value:document.getElementById('ss-name').value}),
        apApi('PUT','/api/settings/bg_image_url',         {value:document.getElementById('ss-bg').value}),
        apApi('PUT','/api/settings/chat_bg_image_url',    {value:chatBgUrl}),
        apApi('PUT','/api/settings/chat_bg_opacity',      {value:chatBgOpacity}),
        apApi('PUT','/api/settings/max_file_mb',          {value:document.getElementById('ss-mb').value}),
        apApi('PUT','/api/settings/registration_open',    {value:document.getElementById('ss-reg').checked?'true':'false'}),
        apApi('PUT','/api/settings/auto_ban_warnings',    {value:document.getElementById('ss-warns').value}),
        apApi('PUT','/api/settings/announcement',         {value:announcement}),
        apApi('PUT','/api/settings/announcement_updated', {value:annUpdated}),
        apApi('PUT','/api/settings/login_side',           {value:loginSide}),
        apApi('PUT','/api/settings/login_gap',            {value:loginGap}),
    ]);
    toast('Configuración guardada','success');
    // Aplicar el fondo del chat inmediatamente
    if(window.applyChatBg) window.applyChatBg(chatBgUrl, chatBgOpacity);
    if(window.loadPublicSettings) loadPublicSettings();
}
/* ── PERMISOS DE ROLES ────────────────────────────────────────────────────── */
const ALL_PERMS = {
    chat_public:    { label:'Ver y escribir en salas públicas',    group:'Chat' },
    chat_private:   { label:'Ver y escribir en salas privadas',    group:'Chat' },
    create_polls:   { label:'Crear encuestas',                     group:'Chat' },
    upload_files:   { label:'Subir archivos',                      group:'Chat' },
    use_commands:   { label:'Usar comandos (/dado /me emotes)',     group:'Chat' },
    send_dm:        { label:'Enviar mensajes privados',            group:'Chat' },
    delete_own_msg: { label:'Eliminar sus propios mensajes',       group:'Chat' },
    mod_delete_msg: { label:'Eliminar mensajes de otros',          group:'Moderación' },
    mod_mute:       { label:'Silenciar usuarios',                   group:'Moderación' },
    mod_warn:       { label:'Emitir advertencias',                  group:'Moderación' },
    mod_kick:       { label:'Expulsar de sala',                     group:'Moderación' },
    admin_ban:      { label:'Banear/desbanear usuarios',            group:'Admin' },
    admin_rooms:    { label:'Crear, editar y borrar salas',         group:'Admin' },
    admin_users:    { label:'Gestionar usuarios y cambiar roles',   group:'Admin' },
    admin_settings: { label:'Cambiar configuración del servidor',   group:'Admin' },
};

async function apRoles() {
    AP.current = 'roles'; apLoading();
    try {
        const perms = await apApi('GET','/api/roles');
        const c = apContainer(); if (!c) return;

        const groups = [...new Set(Object.values(ALL_PERMS).map(p => p.group))];

        c.innerHTML = `
            <div style="max-width:700px">
              <div style="background:rgba(201,168,76,.08);border:1px solid var(--bdg);
                border-radius:8px;padding:.75rem 1rem;margin-bottom:1.25rem;font-size:.85rem">
                ℹ️ El rol <strong style="color:var(--go)">Admin</strong> siempre tiene todos los permisos y no es editable.
                Los cambios se aplican a usuarios nuevos en su próxima acción; los activos no se ven afectados hasta reconectar.
              </div>
              ${['user','moderator'].map(role => `
                <div class="ap-section" style="margin-bottom:1rem">
                  <div class="ap-section-hdr" style="display:flex;align-items:center;justify-content:space-between">
                    <span>${role==='user'?'👤 Usuario':'🛡️ Moderador'}</span>
                    <div style="display:flex;gap:.5rem">
                      <button class="ap-btn b-gh" style="font-size:.75rem"
                        onclick="apRoleSelectAll('${role}',true)">Seleccionar todo</button>
                      <button class="ap-btn b-gh" style="font-size:.75rem"
                        onclick="apRoleSelectAll('${role}',false)">Limpiar</button>
                    </div>
                  </div>
                  <div class="ap-section-body">
                    ${groups.map(grp => {
                        const grpPerms = Object.entries(ALL_PERMS).filter(([,v])=>v.group===grp);
                        return `<div style="margin-bottom:.85rem">
                          <div style="font-size:.68rem;text-transform:uppercase;letter-spacing:.08em;
                            color:var(--txm);margin-bottom:.45rem">${grp}</div>
                          ${grpPerms.map(([key,info]) => `
                            <label style="display:flex;align-items:center;gap:.55rem;
                              padding:.35rem 0;cursor:pointer;font-size:.88rem">
                              <input type="checkbox" id="perm-${role}-${key}"
                                ${(perms[role]||[]).includes(key)?'checked':''}/>
                              ${esc(info.label)}
                            </label>`).join('')}
                        </div>`;
                    }).join('')}
                  </div>
                </div>`).join('')}
              <button class="ap-btn b-go" onclick="apSaveRoles()">💾 Guardar permisos</button>
            </div>`;
    } catch(e) {
        const c = apContainer();
        if (c) c.innerHTML = `<div style="color:var(--red);padding:1rem">Error: ${esc(e.message)}</div>`;
    }
}

function apRoleSelectAll(role, val) {
    Object.keys(ALL_PERMS).forEach(key => {
        const el = document.getElementById(`perm-${role}-${key}`);
        if (el) el.checked = val;
    });
}

async function apSaveRoles() {
    const perms = {};
    ['user','moderator'].forEach(role => {
        perms[role] = Object.keys(ALL_PERMS).filter(key => {
            const el = document.getElementById(`perm-${role}-${key}`);
            return el?.checked;
        });
    });
    try {
        await apApi('PUT','/api/roles', perms);
        toast('Permisos guardados','success');
    } catch(e) { toast('Error: '+e.message,'error'); }
}


async function apStartTunnel() {
    const btn = document.getElementById('tunnel-start-btn');
    if (btn) { btn.disabled=true; btn.textContent='⏳ Iniciando túnel...'; }
    try {
        const d = await apApi('POST', '/api/tunnel/start');
        toast(d.message || 'Túnel iniciando...','success');
        // Poll hasta obtener URL (max 30s)
        let tries = 0;
        const poll = setInterval(async () => {
            tries++;
            const st = await apApi('GET','/api/tunnel/status').catch(()=>({running:false}));
            if (st.url || tries > 30) {
                clearInterval(poll);
                apSettings();
            } else {
                const logEl = document.getElementById('tunnel-log');
                if (logEl && st.log) { logEl.textContent = st.log.slice(-10).join('\n'); logEl.scrollTop=logEl.scrollHeight; }
            }
        }, 1000);
    } catch(e) {
        toast('Error: '+e.message,'error');
        if (btn) { btn.disabled=false; btn.textContent='🚀 Iniciar túnel gratuito'; }
    }
}

async function apStopTunnel() {
    try {
        await apApi('POST', '/api/tunnel/stop');
        toast('Túnel detenido','success');
        setTimeout(()=>apSettings(), 800);
    } catch(e) { toast(e.message,'error'); }
}

async function apRefreshTunnelLog() {
    try {
        const {log} = await apApi('GET','/api/tunnel/log');
        const el = document.getElementById('tunnel-log');
        if(el){ el.textContent=log.slice(-20).join('\n')||'Sin actividad'; el.scrollTop=el.scrollHeight; }
    } catch(_) {}
}

function apCopyTunnelUrl() {
    const inp = document.getElementById('tunnel-url-input');
    if (!inp?.value) { toast('No hay URL activa','warn'); return; }
    navigator.clipboard.writeText(inp.value)
        .then(()=>toast('✓ URL copiada al portapapeles','success'))
        .catch(()=>{ inp.select(); document.execCommand('copy'); toast('URL copiada','success'); });
}

function apCopyInstallCmd() {
    const cmd = 'curl -fsSL https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o /usr/local/bin/cloudflared && chmod +x /usr/local/bin/cloudflared';
    navigator.clipboard.writeText(cmd)
        .then(()=>toast('Comando copiado','success'))
        .catch(()=>toast('Copiá el comando manualmente','warn'));
}


/* ── Editor rich text de cartelera ───────────────────────────────────────── */
function annCmd(cmd, val) {
    const ed = document.getElementById('ss-announcement');
    if (ed) { ed.focus(); document.execCommand(cmd, false, val || null); }
}
function annInsertHR() {
    const ed = document.getElementById('ss-announcement');
    if (ed) { ed.focus(); document.execCommand('insertHTML', false, '<hr/>'); }
}
function annInsertLink() {
    const url = prompt('URL del link:');
    if (!url) return;
    const ed = document.getElementById('ss-announcement');
    if (ed) { ed.focus(); document.execCommand('createLink', false, url); }
}
function annClear() {
    const ed = document.getElementById('ss-announcement');
    if (ed && confirm('¿Borrar toda la cartelera?')) { ed.innerHTML = ''; }
}
function apSetLoginSide(side) {
    window._loginSide = side;
    // Actualizar botones activos
    const btnL = document.getElementById('ss-side-left');
    const btnR = document.getElementById('ss-side-right');
    if (btnL) { btnL.className = 'ap-btn ' + (side === 'left' ? 'b-go' : 'b-gh'); }
    if (btnR) { btnR.className = 'ap-btn ' + (side === 'right' ? 'b-go' : 'b-gh'); }
    // Preview en vivo
    const cols = document.getElementById('auth-columns');
    if (cols) cols.classList.toggle('login-right', side === 'right');
}

/* ── Exponer funciones al window para que app.js las llame ───────────────── */
/* Wrappers para goToSection — setean AP.current antes de llamar la función */
window.loadAdminDash     = () => { AP.current='dashboard'; apDash();     };
window.loadAdminPending  = () => { AP.current='pending';   apPending();  };
window.loadAdminUsers    = () => { AP.current='users';     apUsers();    };
window.loadAdminConns    = () => { AP.current='conns';     apConns();    };
window.loadAdminRooms    = () => { AP.current='rooms';     apRooms();    };
window.loadAdminAudit    = () => { AP.current='audit';     apAudit();    };
window.loadAdminIpBans   = () => { AP.current='ipbans';    apIpBans();   };
window.loadAdminLogs     = () => { AP.current='logs';      apLogs();     };
window.loadAdminSettings = () => { AP.current='settings';  apSettings(); };
window.loadAdminWords    = () => { AP.current='words';     apWords();    };
window.loadAdminRoles    = () => { AP.current='roles';     apRoles();    };

/* ── ROLES / PERMISOS ─────────────────────────────────────────────────────── */
async function apRoles() {
    AP.current = 'roles'; apLoading();
    try {
        // Cargar configuración actual de permisos desde settings
        const s = await apApi('GET', '/api/settings');
        const get = key => s[key]?.value || '';

        // Cargar usuarios con rol moderador/admin para gestión rápida
        const { users } = await apApi('GET', '/api/admin/users?limit=200');
        const mods   = users.filter(u => u.role === 'moderator');
        const admins = users.filter(u => u.role === 'admin');
        const regular = users.filter(u => u.role === 'user' && u.status === 'active');

        const c = apContainer();
        if (!c) return;
        c.innerHTML = `
        <div class="ap-2col">

          <!-- Panel izquierdo: Configuración de permisos -->
          <div>
            <div class="ap-section">
              <div class="ap-section-hdr">⚙️ Configuración de permisos por rol</div>
              <div class="ap-section-body">
                <p style="font-size:.85rem;color:var(--txm);margin-bottom:1rem">
                  Configurá qué puede hacer cada rol. Los cambios aplican de inmediato.
                </p>

                <div style="margin-bottom:1.25rem">
                  <div style="font-family:'Cinzel',serif;font-size:.82rem;color:var(--go);margin-bottom:.65rem">
                    👤 Usuario — permisos base
                  </div>
                  ${renderPermCheck('perm_user_polls',    get('perm_user_polls')!=='false',    'Puede crear encuestas')}
                  ${renderPermCheck('perm_user_files',    get('perm_user_files')!=='false',    'Puede subir archivos')}
                  ${renderPermCheck('perm_user_dm',       get('perm_user_dm')!=='false',       'Puede enviar mensajes privados')}
                  ${renderPermCheck('perm_user_reactions',get('perm_user_reactions')!=='false','Puede dar like/dislike')}
                  ${renderPermCheck('perm_user_dice',     get('perm_user_dice')!=='false',     'Puede usar /dado y /me')}
                </div>

                <div style="margin-bottom:1.25rem">
                  <div style="font-family:'Cinzel',serif;font-size:.82rem;color:#5dade2;margin-bottom:.65rem">
                    🛡️ Moderador — permisos adicionales
                  </div>
                  ${renderPermCheck('perm_mod_delete_msg',  get('perm_mod_delete_msg')!=='false',  'Puede eliminar mensajes')}
                  ${renderPermCheck('perm_mod_mute',        get('perm_mod_mute')!=='false',        'Puede silenciar usuarios')}
                  ${renderPermCheck('perm_mod_warn',        get('perm_mod_warn')!=='false',        'Puede advertir usuarios')}
                  ${renderPermCheck('perm_mod_view_audit',  get('perm_mod_view_audit')!=='false',  'Puede ver auditoría')}
                  ${renderPermCheck('perm_mod_view_conns',  get('perm_mod_view_conns')!=='false',  'Puede ver conexiones activas')}
                  ${renderPermCheck('perm_mod_kick',        get('perm_mod_kick')!=='false',        'Puede expulsar conexiones')}
                </div>

                <button class="ap-btn b-go" onclick="apSavePerms()">💾 Guardar permisos</button>
              </div>
            </div>

            <div class="ap-section" style="margin-top:1rem">
              <div class="ap-section-hdr">🚫 Límites y restricciones</div>
              <div class="ap-section-body">
                <div class="ap-fg"><label class="ap-fl">Límite de mensajes por 2 segundos (anti-flood)</label>
                  <input class="ap-fc" type="number" id="r-flood" value="${get('flood_limit')||'5'}" min="1" max="20"/></div>
                <div class="ap-fg"><label class="ap-fl">XP por mensaje</label>
                  <input class="ap-fc" type="number" id="r-xp-msg" value="${get('xp_per_message')||'2'}" min="0"/></div>
                <div class="ap-fg"><label class="ap-fl">XP por archivo subido</label>
                  <input class="ap-fc" type="number" id="r-xp-file" value="${get('xp_per_file')||'5'}" min="0"/></div>
                <div class="ap-fg"><label class="ap-fl">XP por encuesta creada</label>
                  <input class="ap-fc" type="number" id="r-xp-poll" value="${get('xp_per_poll')||'10'}" min="0"/></div>
                <div class="ap-fg"><label class="ap-fl">XP por voto en encuesta</label>
                  <input class="ap-fc" type="number" id="r-xp-vote" value="${get('xp_per_vote')||'3'}" min="0"/></div>
                <button class="ap-btn b-go" onclick="apSaveLimits()">💾 Guardar límites</button>
              </div>
            </div>
          </div>

          <!-- Panel derecho: Asignación de roles -->
          <div>
            <div class="ap-section">
              <div class="ap-section-hdr">🔑 Asignación rápida de roles</div>
              <div class="ap-section-body">
                <p style="font-size:.82rem;color:var(--txm);margin-bottom:1rem">
                  Hacé click en un usuario para cambiar su rol directamente.
                </p>

                <div style="margin-bottom:1.1rem">
                  <div style="font-size:.75rem;text-transform:uppercase;letter-spacing:.07em;
                    color:var(--go);margin-bottom:.5rem">⚔ Administradores (${admins.length})</div>
                  ${admins.map(u => renderRoleCard(u)).join('') ||
                    '<div style="color:var(--txm);font-size:.82rem;padding:.35rem">Ninguno</div>'}
                </div>

                <div style="margin-bottom:1.1rem">
                  <div style="font-size:.75rem;text-transform:uppercase;letter-spacing:.07em;
                    color:#5dade2;margin-bottom:.5rem">🛡️ Moderadores (${mods.length})</div>
                  ${mods.map(u => renderRoleCard(u)).join('') ||
                    '<div style="color:var(--txm);font-size:.82rem;padding:.35rem">Ninguno</div>'}
                </div>

                <div>
                  <div style="font-size:.75rem;text-transform:uppercase;letter-spacing:.07em;
                    color:var(--txm);margin-bottom:.5rem">
                    Promover usuario a moderador
                  </div>
                  <div style="display:flex;gap:.5rem">
                    <select class="ap-fi" id="r-promote-sel" style="flex:1">
                      <option value="">Elegir usuario activo...</option>
                      ${regular.slice(0,100).map(u =>
                        `<option value="${u.id}">${esc(u.username)} — Nv.${u.level||1} — ${u.msg_count||0} msgs</option>`
                      ).join('')}
                    </select>
                    <button class="ap-btn b-ok" onclick="apPromoteToMod()">🛡️ Promover</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>`;
    } catch(e) {
        const c = apContainer();
        if (c) c.innerHTML = `<div style="color:var(--red);padding:1.5rem">Error: ${esc(e.message)}</div>`;
    }
}

function renderPermCheck(id, checked, label) {
    return `<label style="display:flex;align-items:center;gap:.5rem;padding:.32rem 0;
        cursor:pointer;font-size:.85rem;color:var(--tx)">
        <input type="checkbox" id="${id}" ${checked?'checked':''}/>
        ${label}
    </label>`;
}

function renderRoleCard(u) {
    const isSelf = u.id === S?.user?.id;
    return `<div style="display:flex;align-items:center;gap:.55rem;padding:.42rem .35rem;
        border-bottom:1px solid var(--bd);font-size:.85rem">
      <span style="font-size:1.1rem">${window.FACES?.[(u.face_id||1)-1]||'👤'}</span>
      <span style="flex:1;font-weight:600">${esc(u.username)}</span>
      <span style="font-size:.75rem;color:var(--txm)">Nv.${u.level||1}</span>
      ${!isSelf ? `
        <button class="ap-btn b-gh" style="padding:2px 7px;font-size:.76rem"
          onclick="apSetRole('${u.id}','user')">👤</button>
        <button class="ap-btn b-ok" style="padding:2px 7px;font-size:.76rem"
          onclick="apSetRole('${u.id}','moderator')">🛡️</button>
        <button class="ap-btn b-go" style="padding:2px 7px;font-size:.76rem"
          onclick="apSetRole('${u.id}','admin')">⚔</button>
      ` : '<span style="font-size:.72rem;color:var(--txm)">(vos)</span>'}
    </div>`;
}

async function apSetRole(userId, role) {
    try {
        await apApi('PUT', `/api/admin/users/${userId}`, { role });
        toast('Rol actualizado','success');
        apRoles(); // recargar
    } catch(e) { toast(e.message,'error'); }
}

async function apPromoteToMod() {
    const sel = document.getElementById('r-promote-sel');
    const userId = sel?.value;
    if (!userId) { toast('Seleccioná un usuario','warn'); return; }
    await apSetRole(userId, 'moderator');
    sel.value = '';
}

async function apSavePerms() {
    const perms = [
        'perm_user_polls','perm_user_files','perm_user_dm',
        'perm_user_reactions','perm_user_dice',
        'perm_mod_delete_msg','perm_mod_mute','perm_mod_warn',
        'perm_mod_view_audit','perm_mod_view_conns','perm_mod_kick',
    ];
    try {
        await Promise.all(perms.map(k => {
            const el = document.getElementById(k);
            if (el) return apApi('PUT', `/api/settings/${k}`, { value: el.checked ? 'true' : 'false' });
        }).filter(Boolean));
        toast('Permisos guardados','success');
    } catch(e) { toast(e.message,'error'); }
}

async function apSaveLimits() {
    try {
        await Promise.all([
            apApi('PUT','/api/settings/flood_limit',    {value:document.getElementById('r-flood')?.value||'5'}),
            apApi('PUT','/api/settings/xp_per_message', {value:document.getElementById('r-xp-msg')?.value||'2'}),
            apApi('PUT','/api/settings/xp_per_file',    {value:document.getElementById('r-xp-file')?.value||'5'}),
            apApi('PUT','/api/settings/xp_per_poll',    {value:document.getElementById('r-xp-poll')?.value||'10'}),
            apApi('PUT','/api/settings/xp_per_vote',    {value:document.getElementById('r-xp-vote')?.value||'3'}),
        ]);
        toast('Límites guardados','success');
    } catch(e) { toast(e.message,'error'); }
}


/* ── BACKUPS & BASE DE DATOS ──────────────────────────────────────────────── */
async function apBackup() {
    AP.current = 'backup';
    const el = apContainer();
    if (!el) return;
    if (S && S.user && S.user.role !== 'admin') {
        el.innerHTML = '<div style="padding:2rem;text-align:center;color:var(--txm)">Solo administradores.</div>';
        return;
    }
    el.innerHTML = '<div style="text-align:center;padding:3rem;color:var(--txm)">⏳ Cargando...</div>';
    let data = { files: [], log: [] };
    try { data = await apApi('GET', '/api/admin/backups'); } catch(e) {
        el.innerHTML = '<div style="color:var(--red);padding:2rem">Error: ' + esc(e.message) + '</div>'; return;
    }
    const fmtSz = b => b > 1048576 ? (b/1048576).toFixed(1)+' MB' : Math.round(b/1024)+' KB';
    const rows = data.files.length === 0
        ? '<div style="padding:1.5rem;text-align:center;color:var(--txm)">Sin backups aún.</div>'
        : '<table class="ap-table"><thead><tr><th>Archivo</th><th>Tamaño</th><th>Fecha</th><th></th></tr></thead><tbody>'
          + data.files.map(function(f){
              return '<tr><td style="font-size:.8rem;font-family:monospace">'+esc(f.filename)+'</td>'
                + '<td style="font-size:.8rem">'+fmtSz(f.size_bytes)+'</td>'
                + '<td style="font-size:.78rem;color:var(--txm)">'+fd(f.created_at)+'</td>'
                + '<td style="white-space:nowrap">'
                + '<a class="ap-btn b-go" href="/api/admin/backups/'+encodeURIComponent(f.filename)+'/download" download="'+esc(f.filename)+'" style="text-decoration:none">⬇</a> '
                + '<button class="ap-btn b-dn" onclick="apDelBackup(\''+esc(f.filename)+'\')">🗑</button>'
                + '</td></tr>';
            }).join('')
          + '</tbody></table>';
    el.innerHTML = '<div class="ap-card" style="margin-bottom:1.2rem">'
        + '<div class="ap-card-hdr">💾 Crear backup manual <button class="ap-btn b-go" id="ap-bk-btn" onclick="apMakeBackup()">💾 Crear ahora</button></div>'
        + '<div style="display:flex;gap:.5rem;padding:.4rem 0;align-items:center">'
        + '<input class="ap-fc" id="ap-bk-note" placeholder="Nota opcional..." style="flex:1;max-width:360px" maxlength="200"/></div>'
        + '<div id="ap-bk-status" style="font-size:.82rem;color:var(--txm);min-height:1.2rem"></div>'
        + '</div>'
        + '<div class="ap-card" style="margin-bottom:1.2rem">'
        + '<div class="ap-card-hdr">📥 Importar / Restaurar BD <span style="font-size:.74rem;color:var(--red);font-weight:400">⚠ Reemplaza datos actuales</span></div>'
        + '<div style="display:flex;gap:.5rem;align-items:center;flex-wrap:wrap;padding:.4rem 0">'
        + '<input type="file" id="ap-imp-file" accept=".sql,.gz" style="background:var(--b1);border:1px solid var(--bd);border-radius:6px;padding:.3rem .5rem;color:var(--txt);font-size:.82rem;flex:1;max-width:340px"/>'
        + '<button class="ap-btn b-dn" onclick="apImportDB()">📥 Importar</button></div>'
        + '<div id="ap-imp-status" style="font-size:.82rem;color:var(--txm);min-height:1.2rem"></div>'
        + '</div>'
        + '<div class="ap-card"><div class="ap-card-hdr">📋 Backups disponibles (' + data.files.length + ')</div>' + rows + '</div>';
}
async function apMakeBackup() {
    const btn  = document.getElementById('ap-bk-btn');
    const note = (document.getElementById('ap-bk-note')||{value:''}).value.trim();
    const stat = document.getElementById('ap-bk-status');
    if (btn) { btn.disabled = true; btn.textContent = '⏳ Creando...'; }
    if (stat) { stat.style.color='var(--txm)'; stat.textContent = 'Creando backup...'; }
    try {
        const d = await apApi('POST', '/api/admin/backups', { note });
        if (stat) { stat.style.color='var(--go)'; stat.textContent = '✓ '+d.filename+' ('+Math.round(d.size_bytes/1024)+' KB)'; }
        setTimeout(function(){ apBackup(); }, 1200);
    } catch(e) {
        if (stat) { stat.style.color='var(--red)'; stat.textContent = '✗ '+e.message; }
    } finally { if (btn) { btn.disabled=false; btn.textContent='💾 Crear ahora'; } }
}
async function apDelBackup(filename) {
    if (!confirm('¿Eliminar backup "'+filename+'"?')) return;
    try { await apApi('DELETE', '/api/admin/backups/'+encodeURIComponent(filename)); apBackup(); }
    catch(e) { alert('Error: '+e.message); }
}
async function apImportDB() {
    const fi   = document.getElementById('ap-imp-file');
    const stat = document.getElementById('ap-imp-status');
    if (!fi || !fi.files || !fi.files[0]) { alert('Seleccioná un archivo .sql primero.'); return; }
    if (!confirm('⚠ Esto reemplazará los datos actuales de la BD.\n¿Estás seguro?')) return;
    const fd = new FormData();
    fd.append('backup_file', fi.files[0]);
    if (stat) { stat.style.color='var(--txm)'; stat.textContent='⏳ Importando... (puede tardar)'; }
    try {
        const r = await fetch('/api/admin/backups/import', { method:'POST', headers:{'Authorization':'Bearer '+S.token}, body:fd });
        const d = await r.json();
        if (!r.ok) throw new Error(d.error);
        if (stat) { stat.style.color='var(--go)'; stat.textContent='✓ '+d.message; }
    } catch(e) { if (stat) { stat.style.color='var(--red)'; stat.textContent='✗ '+e.message; } }
}

/* ── MENSAJES PROGRAMADOS ──────────────────────────────────────────────────── */
async function apScheduled() {
    AP.current = 'scheduled';
    const el = apContainer();
    if (!el) return;
    if (S && S.user && S.user.role !== 'admin') {
        el.innerHTML = '<div style="padding:2rem;text-align:center;color:var(--txm)">Solo administradores.</div>';
        return;
    }
    el.innerHTML = '<div style="text-align:center;padding:3rem;color:var(--txm)">⏳ Cargando...</div>';
    let msgs = [], rooms = [];
    try {
        [msgs, rooms] = await Promise.all([
            apApi('GET','/api/admin/scheduled-messages'),
            apApi('GET','/api/admin/rooms'),
        ]);
    } catch(e) {
        el.innerHTML = '<div style="color:var(--red);padding:2rem">Error: '+esc(e.message)+'</div>'; return;
    }
    const roomOpts = rooms.map(function(r){ return '<option value="'+r.id+'">'+esc((r.icon||'💬')+' '+r.name)+'</option>'; }).join('');
    const tbl = msgs.length === 0
        ? '<div style="padding:1.5rem;text-align:center;color:var(--txm)">Sin mensajes programados aún.</div>'
        : '<table class="ap-table"><thead><tr><th>Sala</th><th>Mensaje</th><th>Cron</th><th>Estado</th><th>Último</th><th></th></tr></thead><tbody>'
          + msgs.map(function(m){
              return '<tr>'
                + '<td style="white-space:nowrap">'+esc(m.room_name||'—')+'</td>'
                + '<td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="'+esc(m.content)+'">'+esc(m.content)+'</td>'
                + '<td><code style="font-size:.78rem">'+esc(m.cron_expr)+'</code></td>'
                + '<td><button class="ap-btn '+(m.is_active?'b-ok':'b-dn')+'" onclick="apToggleSched(\''+m.id+'\','+(!m.is_active)+')">'+
                  (m.is_active?'🟢 Activo':'🔴 Inactivo')+'</button></td>'
                + '<td style="font-size:.78rem;color:var(--txm)">'+(m.last_run?fd(m.last_run):'—')+'</td>'
                + '<td><button class="ap-btn b-dn" onclick="apDelSched(\''+m.id+'\')">🗑</button></td>'
                + '</tr>';
            }).join('')
          + '</tbody></table>';
    el.innerHTML = '<div class="ap-card" style="margin-bottom:1.2rem">'
        + '<div class="ap-card-hdr">➕ Nuevo mensaje programado</div>'
        + '<div style="display:grid;gap:.5rem;max-width:580px;padding:.25rem 0">'
        + '<div class="ap-fg"><label class="ap-fl">Sala</label><select class="ap-fc" id="sm-room">'+roomOpts+'</select></div>'
        + '<div class="ap-fg"><label class="ap-fl">Mensaje</label><textarea class="ap-fc" id="sm-content" rows="2" placeholder="Texto del mensaje de sistema..." style="resize:vertical"></textarea></div>'
        + '<div class="ap-fg"><label class="ap-fl">Expresión Cron <span style="font-size:.72rem;color:var(--txm);font-weight:400">— ej: <code>0 9 * * *</code> = todos los días 9am · <code>0 */6 * * *</code> = cada 6hs</span></label>'
        + '<input class="ap-fc" id="sm-cron" placeholder="0 9 * * *" style="font-family:monospace"/></div>'
        + '<button class="ap-btn b-go" style="width:fit-content" onclick="apCreateSched()">⏰ Programar</button>'
        + '<div id="sm-status" style="font-size:.82rem;color:var(--txm);min-height:1.2rem"></div>'
        + '</div></div>'
        + '<div class="ap-card"><div class="ap-card-hdr">📋 Mensajes programados ('+msgs.length+')</div>'+tbl+'</div>';
}
async function apCreateSched() {
    const room_id   = (document.getElementById('sm-room')||{value:''}).value;
    const content   = ((document.getElementById('sm-content')||{value:''}).value||'').trim();
    const cron_expr = ((document.getElementById('sm-cron')||{value:''}).value||'').trim();
    const stat      = document.getElementById('sm-status');
    if (!room_id||!content||!cron_expr) {
        if(stat){stat.style.color='var(--red)';stat.textContent='Sala, mensaje y cron son requeridos.';} return;
    }
    try {
        await apApi('POST','/api/admin/scheduled-messages',{room_id,content,cron_expr,is_active:true});
        if(stat){stat.style.color='var(--go)';stat.textContent='✓ Mensaje programado creado';}
        setTimeout(function(){apScheduled();},1000);
    } catch(e){if(stat){stat.style.color='var(--red)';stat.textContent='✗ '+e.message;}}
}
async function apToggleSched(id, is_active) {
    try{await apApi('PUT','/api/admin/scheduled-messages/'+id,{is_active});apScheduled();}
    catch(e){alert('Error: '+e.message);}
}
async function apDelSched(id) {
    if(!confirm('¿Eliminar este mensaje programado?'))return;
    try{await apApi('DELETE','/api/admin/scheduled-messages/'+id);apScheduled();}
    catch(e){alert('Error: '+e.message);}
}
