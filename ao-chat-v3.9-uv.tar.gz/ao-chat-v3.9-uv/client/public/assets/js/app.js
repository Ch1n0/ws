'use strict';
/* AO Chat v3.2 — Cliente unificado (todos los rangos) */

const FACES=['🧙','⚔️','🛡️','🏹','🧝','🧟','👤','🧛','🧜','🦸','🧚','🧌','👺','👹','🤡','🥷','🧑‍⚕️','🧑‍🔬','🧑‍🏫','🧑‍🎤','🧑‍⚖️','🧑‍🚀','🧑‍🍳','🧑‍🌾','🤴','👸','🤵','🥸','🧓','👴','💀','👻','👿','😈','🤖','👽','🧠','🦴','🩸','🕷️','🐲','🦂','🐛','🪲','🦇','🐙','🦑','🐚','🕸️','🫀','🦊','🐺','🦁','🐗','🦅','🐍','🦌','🐻','🐯','🦝','🦉','🦎','🐴','🦄','🐘','🦏','🦬','🐃','🦆','🦚','🐊','🦈','🐋','🦭','🦋','🐝','🦟','🦩','🐓','🦜','🐉','🔮','🌟','⚡','🔥','❄️','🌙','☀️','🌪️','🌊','✨','💫','🌈','☄️','🌑','💎','🪄','🔯','⚜️','🔱','🧿','🫧','🌀','💠','🔷','🧪','📜','🗡️','🏹','⚓','👑','🏴‍☠️','🎭','🎯','🎲','🗝️','🏆','🪬','🧲','💡','🔭','🎪','🎠','🎡','🏯','⛩️','🌋','🏔️','🏝️','🌺'];
const CLS_COLOR={Guerrero:'#e74c3c',Mago:'#9b59b6',Clérigo:'#f1c40f',Arquero:'#27ae60',
    Druida:'#1abc9c',Bardo:'#3498db',Asesino:'#e67e22',Paladín:'#f0e6a2',
    Nigromante:'#8e44ad',default:'#95a5a6'};
const EMOTES={
    '/espada':'⚔️','/escudo':'🛡️','/flecha':'🏹','/hacha':'🪓',
    '/daga':'🗡️','/lanza':'🪃','/martillo':'🔨','/bomba':'💣',
    '/explosion':'💥','/sangre':'🩸','/veneno':'☠️','/calavera':'💀',
    '/golpe':'👊','/knockout':'🥊','/escapa':'🏃',
    '/magia':'✨','/fuego':'🔥','/hielo':'❄️','/rayo':'⚡',
    '/viento':'🌪️','/agua':'🌊','/tierra':'🪨','/oscuridad':'🌑',
    '/luz':'☀️','/dragon':'🐉','/fenix':'🦅','/cristal':'💎',
    '/pocion':'🧪','/grimorio':'📜','/varita':'🪄','/portal':'🌀',
    '/luna':'🌙','/estrella':'⭐','/meteoro':'☄️','/cosmos':'🌌',
    '/cofre':'📦','/llave':'🗝️','/corona':'👑','/mapa':'🗺️',
    '/libro':'📚','/carta':'✉️','/bolsa':'💰','/moneda':'🪙',
    '/reliquia':'🏺','/gema':'💍','/trofeo':'🏆','/escroll':'📃',
    '/antorcha':'🔦','/vela':'🕯️','/campana':'🔔','/pocion2':'🍶',
    '/arbol':'🌲','/flor':'🌺','/hongo':'🍄','/hoja':'🍀',
    '/lobo':'🐺','/aguila':'🦅','/serpiente':'🐍','/dragon2':'🦎',
    '/lluvia':'🌧️','/nieve':'❄️','/tormenta':'⛈️','/noche':'🌃',
    '/desierto':'🏜️','/bosque':'🌳','/volcan':'🌋','/isla':'🏝️',
    '/corazon':'❤️','/risa':'😄','/lloro':'😢','/enojo':'😡',
    '/asombro':'😲','/miedo':'😱','/guino':'😉','/cool':'😎',
    '/hola':'👋','/aplausos':'👏','/saludo':'🫡','/brindis':'🍺',
    '/silencio':'🤫','/pensar':'🤔','/ok':'👍','/no':'👎',
    '/amor':'💕','/fuerte':'💪','/dormir':'😴','/fiesta':'🎉',
};
var EMOTE_CATS=[
  {name:'⚔️',label:'Combate',emotes:['/espada','/escudo','/flecha','/hacha','/daga','/lanza','/martillo','/bomba','/explosion','/sangre','/veneno','/calavera','/golpe','/knockout','/escapa']},
  {name:'✨',label:'Magia',emotes:['/magia','/fuego','/hielo','/rayo','/viento','/agua','/tierra','/oscuridad','/luz','/dragon','/fenix','/cristal','/pocion','/grimorio','/varita','/portal','/luna','/estrella','/meteoro','/cosmos']},
  {name:'📦',label:'Objetos',emotes:['/cofre','/llave','/corona','/mapa','/libro','/carta','/bolsa','/moneda','/reliquia','/gema','/trofeo','/escroll','/antorcha','/vela','/campana','/pocion2']},
  {name:'🌲',label:'Naturaleza',emotes:['/arbol','/flor','/hongo','/hoja','/lobo','/aguila','/serpiente','/dragon2','/lluvia','/nieve','/tormenta','/noche','/desierto','/bosque','/volcan','/isla']},
  {name:'❤️',label:'Social',emotes:['/corazon','/risa','/lloro','/enojo','/asombro','/miedo','/guino','/cool','/hola','/aplausos','/saludo','/brindis','/silencio','/pensar','/ok','/no','/amor','/fuerte','/dormir','/fiesta']},
];
const STATUS_ICONS={online:'🟢',busy:'🟡',afk:'⚫',invisible:'👻'};
const THEMES=['dark-gold','blood-red','forest-green','deep-blue','light'];
const THEME_NAMES={'dark-gold':'Dorado Oscuro','blood-red':'Sangre','forest-green':'Bosque','deep-blue':'Océano','light':'Claro'};

const S={
    token:  localStorage.getItem('ao_token'),
    user:   null, socket: null,
    room:   null, rooms:  [],
    attach: null, replyTo: null,
    reactions: {}, typingUsers: {}, typingTimer: null,
    pollOpts: [], dmUserId: null, dmUsername: null,
    unread: {}, searchTimeout: null,
};

/* ── Init ─────────────────────────────────────────────────────────────────── */

/* ── YouTube helpers ──────────────────────────────────────────────────────── */
function ytId(url) {
    const m = url.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([a-zA-Z0-9_-]{11})/);
    return m ? m[1] : null;
}
function embedYoutube(text) {
    const ytRe = /https?:\/\/(?:www\.|m\.)?(?:youtube\.com\/(?:watch\?v=|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})[^\s<]*/g;
    return text.replace(ytRe, (_full, id) =>
        '<div class="yt-embed"><iframe src="https://www.youtube.com/embed/' + id + '?rel=0" allowfullscreen loading="lazy"></iframe></div>');
}

document.addEventListener('DOMContentLoaded', async () => {
    applyTheme(localStorage.getItem('ao_theme') || 'dark-gold');
    buildFaces();
    buildEmotePanel();
    initPollOpts();
    await loadPublicSettings();
    if (S.token) {
        try {
            S.user = await api('GET', '/api/users/me');
            if (S.user.status === 'pending') { showScreen('pending-screen'); return; }
            if (S.user.status !== 'active')  { logout(); return; }
            enterChat();
        } catch { logout(); }
    } else showScreen('auth-screen');
});

/* ── Theme ────────────────────────────────────────────────────────────────── */
function applyTheme(t) {
    document.documentElement.dataset.theme = THEMES.includes(t) ? t : 'dark-gold';
    localStorage.setItem('ao_theme', t);
}
function openThemePicker() {
    closeUserMenu();
    const cur = document.documentElement.dataset.theme;
    openModal('🎨 Tema de color', `
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:.65rem">
          ${THEMES.map(t => `
            <div onclick="applyTheme('${t}');closeModal()"
              style="cursor:pointer;padding:.85rem;background:var(--b2);
              border:2px solid ${cur===t?'var(--go)':'var(--bd)'};
              border-radius:8px;text-align:center;transition:border .2s">
              <div style="font-size:1.6rem;margin-bottom:.3rem">${
                {dark_gold:'🌑','dark-gold':'🌑','blood-red':'🩸','forest-green':'🌿','deep-blue':'🌊',light:'☀️'}[t]||'🎨'
              }</div>
              <div style="font-size:.85rem">${THEME_NAMES[t]}</div>
            </div>`).join('')}
        </div>`);
}

/* ── Public settings ──────────────────────────────────────────────────────── */
async function loadPublicSettings() {
    try {
        const cfg = await api('GET', '/api/settings/public', null, true);

        // Fondo pantalla de login
        if (cfg.bg_image_url?.trim()) {
            const url = cfg.bg_image_url.trim();
            document.querySelectorAll('.auth-bg').forEach(el => {
                el.style.backgroundImage    = `url("${url}")`;
                el.style.backgroundSize     = 'cover';
                el.style.backgroundPosition = 'center top';
            });
        }

        // Fondo del chat (imagen general detrás de toda la UI)
        if (cfg.chat_bg_image_url?.trim()) {
            applyChatBg(cfg.chat_bg_image_url.trim(), cfg.chat_bg_opacity || '0.72');
        }

        // Nombre del servidor
        if (cfg.server_name) {
            document.title = cfg.server_name + ' — Chat';
            ['server-name-label','sb-srvname'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.textContent = cfg.server_name;
            });
        }

        // Cartelera de novedades + configuración de layout
        const annBody   = document.getElementById('ann-body');
        const annFooter = document.getElementById('ann-footer');
        const cols      = document.getElementById('auth-columns');

        if (annBody) {
            // Soporta HTML rico + embeds de YouTube
            let html = cfg.announcement || '';
            // Procesar URLs de YouTube que estén como texto plano
            if (html && !html.includes('<iframe')) {
                html = embedYoutube(html);
            }
            annBody.innerHTML = html;
            const annWrap = document.querySelector('.auth-announcement');
            if (annWrap) annWrap.style.display = html.trim() ? '' : 'none';
        }
        if (annFooter && cfg.announcement_updated) {
            annFooter.textContent = 'Actualizado: ' + cfg.announcement_updated;
        }
        // Posición del login (izquierda por defecto)
        if (cols) {
            const side = cfg.login_side || 'left';
            cols.classList.toggle('login-right', side === 'right');
            // Gap entre columnas
            const gap = cfg.login_gap || '3rem';
            cols.style.setProperty('--login-gap', gap);
        }
    } catch(_) {}
}

function applyChatBg(url, opacity = '0.72') {
    const bg  = document.getElementById('chat-bg');
    const ov  = document.getElementById('chat-bg-overlay');
    if (!bg || !ov) return;
    if (url) {
        bg.style.backgroundImage = `url("${url}")`;
        ov.style.background = `rgba(8,10,15,${opacity})`;
        document.body.classList.add('has-chat-bg');
    } else {
        bg.style.backgroundImage = '';
        document.body.classList.remove('has-chat-bg');
    }
}

/* ── Screens ──────────────────────────────────────────────────────────────── */
function showScreen(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById(id).classList.add('active');
}
function switchTab(tab) {
    document.querySelectorAll('.atab').forEach((b, i) =>
        b.classList.toggle('active', (i===0&&tab==='login')||(i===1&&tab==='register')));
    document.getElementById('tab-login').classList.toggle('active', tab==='login');
    document.getElementById('tab-register').classList.toggle('active', tab==='register');
}

/* ── Sections navigation (dentro del chat) ───────────────────────────────── */
function goToSection(id) {
    closeUserMenu();
    // Desactivar todas las secciones
    document.querySelectorAll('.main-section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.sb-nav-item').forEach(i => i.classList.remove('active'));

    const secId = 'sec-' + id;
    const sec = document.getElementById(secId);
    if (sec) sec.classList.add('active');

    // Marcar nav item activo
    const navItem = document.querySelector(`.sb-nav-item[data-sec="${id}"]`);
    if (navItem) navItem.classList.add('active');

    // Ocultar el panel de miembros si no es el chat
    if (id !== 'chat') document.getElementById('members-panel').classList.add('hidden');

    // Cargar contenido según la sección
    const loaders = {
        'dm-list':        loadDmList,
        'leaderboard':    loadLeaderboard,
        'my-profile':     loadMyProfile,
        'admin-dash':     window.loadAdminDash,
        'admin-pending':  window.loadAdminPending,
        'admin-users':    window.loadAdminUsers,
        'admin-conns':    window.loadAdminConns,
        'admin-rooms':    window.loadAdminRooms,
        'admin-audit':    window.loadAdminAudit,
        'admin-ipbans':   window.loadAdminIpBans,
        'admin-logs':     window.loadAdminLogs,
        'admin-settings': window.loadAdminSettings,
        'admin-roles':    window.loadAdminRoles,
        'admin-roles':    window.loadAdminRoles,
        'admin-words':    window.loadAdminWords,
    };
    if (loaders[id]) loaders[id]();
}

/* ── Auth ─────────────────────────────────────────────────────────────────── */
async function doLogin(e) {
    e.preventDefault();
    const btn = document.getElementById('l-btn');
    const err = document.getElementById('l-err');
    btn.disabled = true; btn.textContent = 'Ingresando...';
    err.classList.add('hidden');
    try {
        const d = await api('POST', '/api/auth/login', {
            username: document.getElementById('l-user').value.trim(),
            password: document.getElementById('l-pass').value,
        });
        S.token = d.token; S.user = d.user;
        localStorage.setItem('ao_token', d.token);
        if (d.user.status === 'pending') { showScreen('pending-screen'); return; }
        if (d.user.theme) applyTheme(d.user.theme);
        enterChat();
    } catch(ex) {
        err.textContent = ex.message || 'Usuario o contraseña incorrectos';
        err.classList.remove('hidden');
    } finally { btn.disabled = false; btn.textContent = '⚔ Entrar al mundo'; }
}

async function doRegister(e) {
    e.preventDefault();
    const btn = document.getElementById('r-btn');
    const err = document.getElementById('r-err');
    err.classList.add('hidden');
    const p1 = document.getElementById('r-pass').value;
    const p2 = document.getElementById('r-pass2').value;
    if (p1 !== p2) { err.textContent = 'Las contraseñas no coinciden'; err.classList.remove('hidden'); return; }
    btn.disabled = true; btn.textContent = 'Creando personaje...';
    try {
        await api('POST', '/api/auth/register', {
            username:   document.getElementById('r-user').value.trim(),
            password:   p1,
            race:       document.getElementById('r-race').value,
            gender:     document.getElementById('r-gender').value,
            class:      document.getElementById('r-class').value,
            profession: document.getElementById('r-prof').value,
            face_id:    parseInt(document.getElementById('r-face').value, 10),
        });
        showScreen('pending-screen');
    } catch(ex) {
        err.textContent = ex.message || 'Error al crear personaje';
        err.classList.remove('hidden');
    } finally { btn.disabled = false; btn.textContent = '⚔ Crear personaje'; }
}

function doLogout() { logout(); }
function logout() {
    if (S.token) api('POST', '/api/auth/logout').catch(() => {});
    S.token = null; S.user = null;
    localStorage.removeItem('ao_token');
    S.socket?.disconnect();
    // Limpiar polling
    if (window._dmPollInterval) { clearInterval(window._dmPollInterval); delete window._dmPollInterval; }
    S.room = null; S.rooms = [];
    showScreen('auth-screen');
}

/* ── Enter chat ───────────────────────────────────────────────────────────── */
async function enterChat() {
    showScreen('chat-screen');
    buildSidebar();
    updateUserCard();
    await loadRooms();
    connectSocket();
    checkDmUnread();
    requestNotificationPermission();
    // Actualizar contador de DMs cada 30 segundos
    if (!window._dmPollInterval) {
        window._dmPollInterval = setInterval(checkDmUnread, 30000);
    }
    // Si venía de /admin, abrir el dashboard automáticamente
    if (sessionStorage.getItem('ao_open_admin') &&
        ['admin','moderator'].includes(S.user?.role)) {
        sessionStorage.removeItem('ao_open_admin');
        goToSection('admin-dash');
    }
}

/* ── Build sidebar según rol ─────────────────────────────────────────────── */
function buildSidebar() {
    const u    = S.user;
    const nav  = document.getElementById('sb-nav');
    const isMod   = ['admin','moderator'].includes(u?.role);
    const isAdmin = u?.role === 'admin';

    let html = `<div class="sb-nav-section">Salas</div>
        <div id="rooms-list-inner"></div>
        <div class="sb-separator"></div>
        <div class="sb-nav-section">Personal</div>
        <div class="sb-nav-item" data-sec="leaderboard"     onclick="goToSection('leaderboard')">
            <span class="ni-ico">🏆</span><span class="ni-name">Tabla de líderes</span></div>
        <div class="sb-nav-item" data-sec="my-profile"      onclick="goToSection('my-profile')">
            <span class="ni-ico">👤</span><span class="ni-name">Mi perfil</span></div>
        <div class="sb-nav-item" data-sec="dm-list"         onclick="goToSection('dm-list')">
            <span class="ni-ico">✉️</span><span class="ni-name">Mensajes privados</span>
            <span id="dm-badge" class="ni-badge hidden">0</span></div>`;

    if (isMod) {
        html += `<div class="sb-separator"></div>
            <div class="sb-nav-section">
                ${isAdmin ? '🛡️ Administración' : '🔰 Moderación'}
            </div>
            <div class="sb-nav-item" data-sec="admin-dash"     onclick="goToSection('admin-dash')">
                <span class="ni-ico">📊</span><span class="ni-name">Dashboard</span></div>
            <div class="sb-nav-item" data-sec="admin-conns"    onclick="goToSection('admin-conns')">
                <span class="ni-ico">🔌</span><span class="ni-name">Conexiones activas</span>
                <span id="nb-online" class="ni-cnt">0</span></div>
            <div class="sb-nav-item" data-sec="admin-audit"    onclick="goToSection('admin-audit')">
                <span class="ni-ico">📋</span><span class="ni-name">Auditoría</span></div>`;
        if (isAdmin) {
            html += `
            <div class="sb-nav-item" data-sec="admin-pending"  onclick="goToSection('admin-pending')">
                <span class="ni-ico">⏳</span><span class="ni-name">Pendientes</span>
                <span id="nb-pending" class="ni-badge hidden">0</span></div>
            <div class="sb-nav-item" data-sec="admin-users"    onclick="goToSection('admin-users')">
                <span class="ni-ico">👥</span><span class="ni-name">Usuarios</span></div>
            <div class="sb-nav-item" data-sec="admin-rooms"    onclick="goToSection('admin-rooms')">
                <span class="ni-ico">🏛️</span><span class="ni-name">Salas</span></div>
            <div class="sb-nav-item" data-sec="admin-ipbans"   onclick="goToSection('admin-ipbans')">
                <span class="ni-ico">🚫</span><span class="ni-name">Bans de IP</span></div>
            <div class="sb-nav-item" data-sec="admin-logs"     onclick="goToSection('admin-logs')">
                <span class="ni-ico">📟</span><span class="ni-name">Logs</span></div>
            <div class="sb-nav-item" data-sec="admin-settings" onclick="goToSection('admin-settings')">
                <span class="ni-ico">⚙️</span><span class="ni-name">Configuración</span></div>
            <div class="sb-nav-item" data-sec="admin-roles"    onclick="goToSection('admin-roles')">
                <span class="ni-ico">⚡</span><span class="ni-name">Permisos de roles</span></div>`;
        }
    }

    nav.innerHTML = html;
}

/* ── Update user card ─────────────────────────────────────────────────────── */
function updateUserCard() {
    const u = S.user; if (!u) return;
    document.getElementById('uc-name').textContent = u.username;
    document.getElementById('uc-sub').innerHTML =
        `<span style="color:${CLS_COLOR[u.class]||'var(--txm)'}">${u.class||'—'}</span>` +
        ` · <span style="color:var(--go)">Nv.${u.level||1}</span>` +
        ` · <span class="st-badge role-${u.role}">${u.role==='admin'?'Admin':u.role==='moderator'?'Mod':'User'}</span>`;
    const av = document.getElementById('uc-av');
    av.textContent = FACES[(u.face_id||1)-1] || '👤';
    av.style.borderColor = (CLS_COLOR[u.class]||'transparent') + '88';
    // Mostrar secciones admin si corresponde
    if (['admin','moderator'].includes(u.role)) {
        document.querySelectorAll('.admin-only').forEach(el => el.style.display = '');
    }
}

/* ── Load rooms ───────────────────────────────────────────────────────────── */
async function loadRooms() {
    try {
        S.rooms = await api('GET', '/api/rooms');
        renderRoomsInSidebar();
    } catch(e) {
        console.error('Error cargando salas:', e);
        toast('Error cargando salas: ' + e.message, 'error');
    }
}
function renderRoomsInSidebar() {
    const list = document.getElementById('rooms-list-inner');
    if (!list) return;
    if (!S.rooms.length) {
        list.innerHTML = '<div style="padding:.4rem .9rem;font-size:.8rem;color:var(--txm)">Sin salas disponibles</div>';
        return;
    }
    const KIND_SUFFIX = { docs:'📄', web:'🌐' };
    list.innerHTML = S.rooms.map(r => {
        const unread  = S.unread[r.id] || 0;
        const kindTag = KIND_SUFFIX[r.kind]
            ? `<span class="ni-kind-badge" title="${r.kind==='docs'?'Documentos':'Web embebida'}">${KIND_SUFFIX[r.kind]}</span>`
            : '';
        return `<div class="sb-nav-item" data-sec="chat" data-rid="${r.id}" onclick="joinRoomById('${r.id}')">
            <span class="ni-ico">${r.icon||'💬'}</span>
            <span class="ni-name">${esc(r.name)}${kindTag}</span>
            <span class="ni-cnt" id="cnt-${r.id}">${r.kind==='web'?'':r.online_count||0}</span>
            ${unread ? `<span class="ni-badge">${unread}</span>` : ''}
        </div>`;
    }).join('');
}

/* Wrapper seguro: busca la sala en S.rooms por ID */
function joinRoomById(roomId) {
    const room = S.rooms.find(r => r.id === roomId);
    if (room) joinRoom(room);
    else { toast('Sala no encontrada','error'); loadRooms(); }
}

/* ── Join room — dispatches by room kind ─────────────────────────────────── */
async function joinRoom(room) {
    if (S.room?.id === room.id) { goToSection('chat'); return; }
    S.room = room;
    delete S.unread[room.id];

    document.querySelectorAll('.sb-nav-item').forEach(el => el.classList.remove('active'));
    document.querySelector(`.sb-nav-item[data-rid="${room.id}"]`)?.classList.add('active');

    goToSection('chat');
    document.getElementById('chat-welcome').classList.add('hidden');
    document.getElementById('chat-room').classList.remove('hidden');

    const hasBanner = !!(room.image_url?.trim());
    const banner = document.getElementById('room-banner');
    const plain  = document.getElementById('room-hdr-plain');
    if (hasBanner) {
        document.getElementById('room-banner-img').src = room.image_url.trim();
        document.getElementById('rbi-ico').textContent   = room.icon || '💬';
        document.getElementById('rbi-name').textContent  = room.name;
        document.getElementById('rbi-topic').textContent = room.topic || room.description || '';
        banner.classList.add('has-img'); plain.style.display = 'none';
    } else {
        banner.classList.remove('has-img'); plain.style.display = '';
    }
    document.getElementById('rh-ico').textContent    = room.icon || '💬';
    document.getElementById('rh-name').textContent   = room.name;
    document.getElementById('rh-topic').textContent  = room.topic || room.description || '';

    _roomRestoreChat();
    const kind = room.kind || 'chat';
    if (kind === 'docs') { await joinDocsRoom(room); return; }
    if (kind === 'web')  { joinWebRoom(room); return; }
    await joinChatRoom(room);
}

function _roomRestoreChat() {
    const mw = document.getElementById('msgs-wrap');
    const ia = document.querySelector('.input-area');
    const dv = document.getElementById('docs-room-view');
    const wv = document.getElementById('web-room-view');
    if (mw) mw.style.display = '';
    if (ia) ia.style.display = '';
    if (dv) dv.style.display = 'none';
    if (wv) wv.style.display = 'none';
    document.getElementById('members-panel').classList.remove('hidden');
    // Restore room header elements hidden by web room
    const banner = document.getElementById('room-banner');
    const plain  = document.getElementById('room-hdr-plain');
    if (plain)  plain.style.display  = '';
    // banner visibility is controlled by joinRoom hasBanner logic — just clear forced hide
    if (banner) banner.style.removeProperty('display');
}

/* ── CHAT room ──────────────────────────────────────────────────────────────── */
async function joinChatRoom(room) {
    document.getElementById('msgs-list').innerHTML = '';
    S.reactions = {}; S.replyTo = null;
    clearReply(); clearSearch();
    try {
        const hist = await api('GET', `/api/messages/${room.id}?limit=60`);
        hist.reverse().forEach(m => appendMsg(m, false));
        scrollBottom();
    } catch(e) { toast('Error cargando mensajes: ' + e.message, 'error'); }
    S.socket?.emit('room:join', { roomId: room.id });
}

/* ── Docs helpers ──────────────────────────────────────────────────────────── */
function _canUploadDocs(room) {
    const role = S.user?.role;
    if (['admin','moderator'].includes(role)) return true;     // staff always can
    if (room.upload_permission === 'staff') return false;      // room restricted to staff
    return true;                                                // 'all' — any member can
}

/* ── DOCS room ──────────────────────────────────────────────────────────────── */
async function joinDocsRoom(room) {
    document.getElementById('msgs-wrap').style.display  = 'none';
    document.querySelector('.input-area').style.display = 'none';
    document.getElementById('members-panel').classList.add('hidden');

    let dv = document.getElementById('docs-room-view');
    if (!dv) {
        dv = document.createElement('div');
        dv.id = 'docs-room-view';
        document.getElementById('chat-room').appendChild(dv);
    }
    dv.style.display = '';
    dv.innerHTML = `
      <div class="docs-layout">
        <div class="docs-sidebar">
          <div class="docs-sidebar-hdr">
            <span style="font-weight:500">📄 Documentos</span>
            ${_canUploadDocs(room) ? `<label class="docs-upload-btn" title="Subir PDF">
              ＋ Subir PDF
              <input type="file" accept=".pdf,application/pdf" style="display:none"
                onchange="uploadDocToRoom(this,'${room.id}')"/>
            </label>` : ''}
          </div>
          <div id="docs-list" class="docs-list"><div class="docs-empty">Cargando…</div></div>
        </div>
        <div id="docs-viewer" class="docs-viewer">
          <div class="docs-viewer-ph">
            <div style="font-size:3.5rem;opacity:.15">📄</div>
            <p style="color:var(--txm);margin-top:.5rem">Hacé clic en un documento para verlo</p>
          </div>
        </div>
      </div>`;

    await loadDocsList(room.id);
    S.socket?.emit('room:join', { roomId: room.id });
}

// Tracks currently loaded room for refreshes
let _docsCurrentRoomId = null;
let _docsSelected = new Set();

async function loadDocsList(roomId) {
    _docsCurrentRoomId = roomId;
    _docsSelected.clear();
    const listEl = document.getElementById('docs-list');
    if (!listEl) return;
    try {
        const docs = await api('GET', `/api/rooms/${roomId}/documents`);
        _renderDocsList(docs, roomId);
    } catch(e) {
        listEl.innerHTML = `<div class="docs-empty" style="color:var(--red)">Error: ${esc(e.message)}</div>`;
    }
}

function _renderDocsList(docs, roomId) {
    const listEl = document.getElementById('docs-list');
    if (!listEl) return;
    const isStaff = ['admin','moderator'].includes(S.user?.role);

    if (!docs.length) {
        listEl.innerHTML = '<div class="docs-empty">No hay documentos. ¡Subí el primero!</div>';
        return;
    }

    // Toolbar with bulk actions (staff only)
    const toolbar = isStaff ? `
      <div class="docs-bulk-bar" id="docs-bulk-bar" style="display:none">
        <span id="docs-sel-count">0 sel.</span>
        <button class="di-bulk-del" onclick="deleteSelectedDocs('${roomId}')">🗑 Eliminar sel.</button>
        <button class="di-bulk-all" onclick="deleteAllDocs('${roomId}')">🗑 Todos</button>
        <button class="di-bulk-clear" onclick="clearDocSelection()">✕</button>
      </div>` : '';

    listEl.innerHTML = toolbar + docs.map(d => `
      <div class="docs-item" id="di-${d.id}"
           onclick="openDocViewer('${d.id}','${esc(d.original_name)}')"
           title="${esc(d.original_name)}">
        ${isStaff ? `<input type="checkbox" class="di-check" data-id="${d.id}"
          onclick="event.stopPropagation();toggleDocSelect('${d.id}')" title="Seleccionar"/>` : ''}
        <div class="di-ico">📄</div>
        <div class="di-info">
          <div class="di-name">${esc(d.original_name)}</div>
          <div class="di-meta">${esc(d.uploader)} · ${fmtBytes(d.size_bytes)}</div>
        </div>
        <button class="di-dl" title="Descargar"
          onclick="event.stopPropagation();downloadFile('${d.id}')">⬇</button>
        ${isStaff ? `<button class="di-del" title="Eliminar"
          onclick="event.stopPropagation();deleteOneDoc('${d.id}','${roomId}')">🗑</button>` : ''}
      </div>`).join('');
}

function toggleDocSelect(id) {
    if (_docsSelected.has(id)) _docsSelected.delete(id);
    else _docsSelected.add(id);
    const bar = document.getElementById('docs-bulk-bar');
    const cnt = document.getElementById('docs-sel-count');
    const el  = document.getElementById(`di-${id}`);
    if (el) el.classList.toggle('selected', _docsSelected.has(id));
    if (bar) bar.style.display = _docsSelected.size ? '' : 'none';
    if (cnt) cnt.textContent = `${_docsSelected.size} sel.`;
    // Check the checkbox
    const cb = document.querySelector(`#di-${id} .di-check`);
    if (cb) cb.checked = _docsSelected.has(id);
}

function clearDocSelection() {
    _docsSelected.clear();
    document.querySelectorAll('.docs-item').forEach(el => el.classList.remove('selected'));
    document.querySelectorAll('.di-check').forEach(cb => cb.checked = false);
    const bar = document.getElementById('docs-bulk-bar');
    if (bar) bar.style.display = 'none';
}

async function deleteOneDoc(fileId, roomId) {
    if (!confirm('¿Eliminar este documento?')) return;
    try {
        await api('DELETE', `/api/files/${fileId}`);
        toast('Documento eliminado', 'success');
        await loadDocsList(roomId);
    } catch(e) { toast(e.message, 'error'); }
}

async function deleteSelectedDocs(roomId) {
    if (!_docsSelected.size) return;
    if (!confirm(`¿Eliminar ${_docsSelected.size} documento(s)?`)) return;
    try {
        await api('DELETE', '/api/files/bulk', { ids: [..._docsSelected] });
        toast('Documentos eliminados', 'success');
        _docsSelected.clear();
        await loadDocsList(roomId);
    } catch(e) { toast(e.message, 'error'); }
}

async function deleteAllDocs(roomId) {
    const all = [...document.querySelectorAll('.di-check')].map(el => el.dataset.id);
    if (!all.length) return;
    if (!confirm(`¿Eliminar TODOS los documentos (${all.length})?`)) return;
    try {
        await api('DELETE', '/api/files/bulk', { ids: all });
        toast('Todos los documentos eliminados', 'success');
        await loadDocsList(roomId);
    } catch(e) { toast(e.message, 'error'); }
}

async function openDocViewer(fileId, fileName) {
    const viewer = document.getElementById('docs-viewer');
    if (!viewer) return;
    document.querySelectorAll('.docs-item').forEach(el => el.classList.remove('active'));
    document.querySelector(`.docs-item[onclick*="${fileId}"]`)?.classList.add('active');

    viewer.innerHTML = `
      <div class="docs-viewer-toolbar">
        <span class="dvt-name">📄 ${esc(fileName)}</span>
        <button class="ico-btn" title="Descargar" onclick="downloadFile('${fileId}')">⬇ Descargar</button>
      </div>
      <iframe class="docs-pdf-iframe"
        src="/api/files/${fileId}/view?token=${encodeURIComponent(S.token||'')}"
        onload="this.style.opacity='1'"
        style="width:100%;flex:1;border:none;opacity:0;transition:opacity .3s;min-height:0;height:100%">
      </iframe>`;
}

async function uploadDocToRoom(inp, roomId) {
    const f = inp.files[0]; if (!f) return;
    if (!f.type.includes('pdf')) { toast('Solo se permiten archivos PDF', 'error'); inp.value=''; return; }
    if (f.size > 50 * 1024 * 1024) { toast('El archivo supera 50 MB', 'error'); inp.value=''; return; }

    const listEl = document.getElementById('docs-list');
    const origHtml = listEl?.innerHTML;
    if (listEl) listEl.innerHTML = '<div class="docs-empty">Subiendo…</div>';

    try {
        const fd = new FormData();
        fd.append('file', f);
        fd.append('roomId', roomId);
        const r = await fetch('/api/files/upload', {
            method:'POST', headers:{'Authorization':'Bearer '+S.token}, body:fd
        });
        const d = await r.json(); if (!r.ok) throw new Error(d.error);
        toast('PDF subido', 'success');
        await loadDocsList(roomId);
    } catch(e) {
        toast('Error al subir: ' + e.message, 'error');
        if (listEl && origHtml) listEl.innerHTML = origHtml;
    } finally { inp.value = ''; }
}

/* ── WEB room ───────────────────────────────────────────────────────────────── */
function joinWebRoom(room) {
    // Hide ALL standard chat UI — we take over the entire chat-room div
    document.getElementById('msgs-wrap').style.display     = 'none';
    document.querySelector('.input-area').style.display    = 'none';
    document.getElementById('members-panel').classList.add('hidden');
    // Also hide the room header/banner so iframe fills ALL vertical space
    const banner = document.getElementById('room-banner');
    const plain  = document.getElementById('room-hdr-plain');
    if (banner) banner.style.display = 'none';
    if (plain)  plain.style.display  = 'none';

    let wv = document.getElementById('web-room-view');
    if (!wv) {
        wv = document.createElement('div');
        wv.id = 'web-room-view';
        document.getElementById('chat-room').appendChild(wv);
    }
    wv.style.display = '';
    // Store original URL for browser navigation
    const baseUrl = room.embed_url?.trim() || '';
    _webRoomCurrentUrl = baseUrl;

    if (!baseUrl) {
        wv.innerHTML = `<div class="web-room-nourl">
            <div style="font-size:3rem;opacity:.2">🌐</div>
            <p style="color:var(--txm);margin-top:.5rem">Sin URL configurada para esta sala.</p></div>`;
        return;
    }

    // Browser-tab chrome
    // Build the proxied URL — server fetches with Firefox UA, strips X-Frame-Options
    const pxUrl = _proxyUrl(baseUrl);

    wv.innerHTML = `
      <div class="wb-chrome">
        <div class="wb-tabbar">
          <div class="wb-tab active">
            <span class="wb-tab-favicon" id="wb-favicon">🌐</span>
            <span class="wb-tab-title" id="wb-tab-title">${esc(room.name)}</span>
          </div>
        </div>
        <div class="wb-toolbar">
          <button class="wb-nav-btn" id="wb-back"    title="Atrás"    onclick="webRoomNav('back')"    disabled>‹</button>
          <button class="wb-nav-btn" id="wb-forward" title="Adelante" onclick="webRoomNav('forward')" disabled>›</button>
          <button class="wb-nav-btn" title="Recargar" onclick="webRoomNav('reload')">↻</button>
          <div class="wb-addr-wrap">
            <div class="wb-secure" id="wb-secure">🔒</div>
            <input class="wb-addr" id="wb-addr" value="${esc(baseUrl)}"
              onkeydown="if(event.key==='Enter')webRoomNav('go')"
              onfocus="this.select()"/>
            <button class="wb-addr-go" onclick="webRoomNav('go')" title="Ir">→</button>
          </div>
          <a class="wb-nav-btn wb-ext" href="${esc(baseUrl)}" id="wb-ext-link"
             target="_blank" rel="noopener noreferrer" title="Abrir en nueva pestaña">↗</a>
        </div>
        <div class="wb-frame-wrap">
          <div class="wb-loading" id="wb-loading">
            <div class="wb-spinner"></div>
            <span id="wb-loading-txt">Cargando…</span>
          </div>
          <iframe id="web-room-iframe" class="wb-iframe"
            src="${pxUrl}"
            allow="fullscreen"
            loading="lazy">
          </iframe>
          <div id="wb-blocked" class="wb-blocked hidden">
            <div style="font-size:3rem;opacity:.2;margin-bottom:1rem">🌐</div>
            <div style="font-weight:500;margin-bottom:.4rem">Error al cargar</div>
            <p style="color:var(--txm);font-size:.85rem;margin-bottom:1.2rem;max-width:320px;text-align:center">
              El sitio no respondió o bloqueó la carga. Podés intentar abrirlo directamente.
            </p>
            <a class="btn-go-ext" id="wb-ext-btn" href="${esc(baseUrl)}"
               target="_blank" rel="noopener noreferrer">↗ Abrir en nueva pestaña</a>
          </div>
        </div>
      </div>`;

    // Listen for postMessage events from the proxied page
    window.removeEventListener('message', _webRoomMsgHandler);
    window.addEventListener('message', _webRoomMsgHandler);

    const iframe = document.getElementById('web-room-iframe');
    iframe.addEventListener('load', () => webRoomLoaded());
    iframe.addEventListener('error', () => webRoomShowBlocked());

    // If iframe doesn't fire load in 12s, show error
    window._webRoomBlockTimeout = setTimeout(() => webRoomShowBlocked(), 12000);

    (window.__uvSWReady||Promise.resolve(false)).then(function(ok){
        _uvReady=!!ok;
        _updateUVBadge(document.getElementById('wb-uv-badge'));
    });
    S.socket?.emit('room:join', { roomId: room.id });
}

function _proxyUrl(url) {
    if (!url) return '';
    // Token must be in query param — iframes can't send Authorization headers
    const tok = S.token || localStorage.getItem('ao_token') || '';
    return `/api/web-proxy?url=${encodeURIComponent(url)}&token=${encodeURIComponent(tok)}`;
}

// Handle postMessage from proxied page (navigation, title changes)
function _webRoomMsgHandler(e) {
    if (!e.data || typeof e.data !== 'object') return;
    if (e.data.type === 'wb-navigate') {
        // Page navigated internally — update address bar to real URL
        const pxed = e.data.url || '';
        // Extract the original URL from proxy URL for display
        try {
            const u = new URL(pxed, location.origin);
            const orig = decodeURIComponent(u.searchParams.get('url') || pxed);
            const addr = document.getElementById('wb-addr');
            if (addr) addr.value = orig;
            const ext = document.getElementById('wb-ext-link');
            if (ext) ext.href = orig;
            // Track in history
            if (_webRoomHistory[_webRoomHistPos] !== orig) {
                _webRoomHistory = _webRoomHistory.slice(0, _webRoomHistPos + 1);
                _webRoomHistory.push(orig);
                _webRoomHistPos = _webRoomHistory.length - 1;
                _updateWebNavBtns();
            }
        } catch(_) {}
    }
    if (e.data.type === 'wb-title') {
        const el = document.getElementById('wb-tab-title');
        if (el && e.data.title) el.textContent = String(e.data.title).slice(0, 32);
    }
}

// Current URL tracked for browser nav
let _webRoomCurrentUrl = '';
let _webRoomHistory = [];
let _webRoomHistPos  = -1;

function webRoomLoaded() {
    const loading = document.getElementById('wb-loading');
    const blocked = document.getElementById('wb-blocked');
    const iframe  = document.getElementById('web-room-iframe');
    if (loading) loading.classList.add('hidden');
    if (blocked) blocked.classList.add('hidden');
    clearTimeout(window._webRoomBlockTimeout);

    // Try to read title (only works same-origin, fails silently cross-origin)
    try {
        const title = iframe.contentDocument?.title;
        if (title) {
            const el = document.getElementById('wb-tab-title');
            if (el) el.textContent = title.slice(0, 32);
        }
    } catch(_) {}

    // Track history
    const addr = document.getElementById('wb-addr');
    const url = (addr?.value || _webRoomCurrentUrl).trim();
    if (_webRoomHistory[_webRoomHistPos] !== url) {
        _webRoomHistory = _webRoomHistory.slice(0, _webRoomHistPos + 1);
        _webRoomHistory.push(url);
        _webRoomHistPos = _webRoomHistory.length - 1;
    }
    _updateWebNavBtns();
}

function webRoomShowBlocked() {
    const loading = document.getElementById('wb-loading');
    const blocked = document.getElementById('wb-blocked');
    if (loading) loading.classList.add('hidden');
    if (blocked) blocked.classList.remove('hidden');
}

function webRoomError() {
    webRoomShowBlocked();
}

function _updateWebNavBtns() {
    const back = document.getElementById('wb-back');
    const fwd  = document.getElementById('wb-forward');
    if (back) back.disabled = _webRoomHistPos <= 0;
    if (fwd)  fwd.disabled  = _webRoomHistPos >= _webRoomHistory.length - 1;
}

function webRoomNav(action) {
    const iframe   = document.getElementById('web-room-iframe');
    const addrInp  = document.getElementById('wb-addr');
    const loading  = document.getElementById('wb-loading');
    const blocked  = document.getElementById('wb-blocked');
    const extLink  = document.getElementById('wb-ext-link');
    const extBtn   = document.getElementById('wb-ext-btn');
    if (!iframe) return;

    const showLoading = () => {
        if (loading) loading.classList.remove('hidden');
        if (blocked) blocked.classList.add('hidden');
        clearTimeout(window._webRoomBlockTimeout);
        window._webRoomBlockTimeout = setTimeout(webRoomShowBlocked, 7000);
    };

    if (action === 'back') {
        if (_webRoomHistPos > 0) {
            _webRoomHistPos--;
            const url = _webRoomHistory[_webRoomHistPos];
            if (addrInp) addrInp.value = url;
            if (extLink) extLink.href = url;
            showLoading();
            iframe.src = _proxyUrl(url);
            _updateWebNavBtns();
        }
    } else if (action === 'forward') {
        if (_webRoomHistPos < _webRoomHistory.length - 1) {
            _webRoomHistPos++;
            const url = _webRoomHistory[_webRoomHistPos];
            if (addrInp) addrInp.value = url;
            if (extLink) extLink.href = url;
            showLoading();
            iframe.src = _proxyUrl(url);
            _updateWebNavBtns();
        }
    } else if (action === 'reload') {
        showLoading();
        iframe.src = _proxyUrl(_webRoomCurrentUrl || (addrInp?.value || '').trim());
    } else if (action === 'go') {
        let url = (addrInp?.value || '').trim();
        if (!url) return;
        if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
        if (addrInp) addrInp.value = url;
        if (extLink) extLink.href = url;
        if (extBtn)  extBtn.href  = url;
        _webRoomCurrentUrl = url;
        // Track in history
        if (_webRoomHistory[_webRoomHistPos] !== url) {
            _webRoomHistory = _webRoomHistory.slice(0, _webRoomHistPos + 1);
            _webRoomHistory.push(url);
            _webRoomHistPos = _webRoomHistory.length - 1;
            _updateWebNavBtns();
        }
        showLoading();
        iframe.src = _proxyUrl(url); // always go through proxy
    }
}

/* ── Link Previews ──────────────────────────────────────────────────────────── */
const _previewCache = {};

function _extractUrls(text) {
    return [...new Set((text.match(/https?:\/\/[^\s<>"']{10,500}/g) || []))].slice(0, 3);
}

async function _fetchPreview(url) {
    if (_previewCache[url] !== undefined) return _previewCache[url];
    try {
        const r = await fetch(`/api/link-preview?url=${encodeURIComponent(url)}`,
            { headers: { 'Authorization': 'Bearer ' + S.token } });
        const d = r.ok ? await r.json() : null;
        _previewCache[url] = d;
        return d;
    } catch { _previewCache[url] = null; return null; }
}

async function attachLinkPreviews(msgEl, rawText) {
    const urls = _extractUrls(rawText)
        .filter(u => !/youtube\.com|youtu\.be/.test(u)); // YouTube already embedded
    if (!urls.length) return;

    const body = msgEl.querySelector('.msg-body');
    if (!body) return;

    for (const url of urls) {
        const data = await _fetchPreview(url);
        if (!data || !data.title) continue;

        const card = document.createElement('div');
        card.className = 'link-preview-card';
        card.onclick = () => window.open(url, '_blank', 'noopener,noreferrer');
        const imgHtml = data.image
            ? `<div class="lp-img-wrap"><img class="lp-img" src="${esc(data.image)}"
                loading="lazy" onerror="this.parentElement.classList.add('lp-noimg')" alt=""/></div>`
            : '<div class="lp-img-wrap lp-noimg"></div>';
        card.innerHTML = `${imgHtml}
          <div class="lp-body">
            ${data.site ? `<div class="lp-site">${esc(data.site)}</div>` : ''}
            <div class="lp-title">${esc(data.title)}</div>
            ${data.description ? `<div class="lp-desc">${esc(data.description.slice(0,140))}</div>` : ''}
            <div class="lp-url">${esc(url.slice(0,72))}${url.length>72?'…':''}</div>
          </div>`;
        body.appendChild(card);
    }
}

/* ── Inject styles for new features ─────────────────────────────────────────── */
(function injectStyles() {
    if (document.getElementById('ao-extra-styles')) return;
    const s = document.createElement('style');
    s.id = 'ao-extra-styles';
    s.textContent = `
/* ── Docs room ── */
.docs-layout{display:flex;height:100%;overflow:hidden}
.docs-sidebar{width:260px;min-width:160px;flex-shrink:0;display:flex;flex-direction:column;border-right:1px solid var(--bd);background:var(--b3)}
.docs-sidebar-hdr{display:flex;align-items:center;justify-content:space-between;padding:.5rem .7rem;border-bottom:1px solid var(--bd);gap:.4rem;font-size:.83rem}
.docs-upload-btn{cursor:pointer;background:var(--go);color:#fff;border:none;border-radius:6px;padding:.26rem .6rem;font-size:.76rem;white-space:nowrap;line-height:1.4}
.docs-upload-btn:hover{filter:brightness(1.1)}
.docs-list{flex:1;overflow-y:auto;padding:.25rem 0}
.docs-empty{padding:1.2rem .75rem;font-size:.8rem;color:var(--txm);text-align:center}
.docs-bulk-bar{display:flex;align-items:center;gap:.4rem;padding:.35rem .6rem;background:var(--b5);border-bottom:1px solid var(--bd);font-size:.75rem}
.docs-bulk-bar span{flex:1;color:var(--txm)}
.di-bulk-del,.di-bulk-all,.di-bulk-clear{background:none;border:1px solid var(--bd);border-radius:4px;padding:.2rem .45rem;cursor:pointer;font-size:.73rem;color:var(--red);white-space:nowrap}
.di-bulk-clear{color:var(--txm)}
.di-bulk-del:hover,.di-bulk-all:hover{background:var(--red);color:#fff;border-color:var(--red)}
.docs-item{display:flex;align-items:center;gap:.4rem;padding:.45rem .65rem;cursor:pointer;border-radius:6px;margin:0 .2rem;transition:background .12s}
.docs-item:hover{background:var(--b4)}
.docs-item.active,.docs-item.selected{background:var(--b5)}
.di-check{width:14px;height:14px;flex-shrink:0;cursor:pointer;accent-color:var(--go)}
.di-ico{font-size:1.25rem;flex-shrink:0}
.di-info{flex:1;min-width:0}
.di-name{font-size:.79rem;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.di-meta{font-size:.71rem;color:var(--txm);margin-top:.08rem}
.di-dl,.di-del{background:none;border:none;color:var(--txm);cursor:pointer;font-size:.82rem;opacity:.5;padding:.12rem .22rem;border-radius:4px;flex-shrink:0}
.di-dl:hover{opacity:1;color:var(--go)}
.di-del:hover{opacity:1;color:var(--red)}
.docs-viewer{flex:1;display:flex;flex-direction:column;overflow:hidden;background:var(--b2)}
.docs-viewer-toolbar{display:flex;align-items:center;padding:.4rem .7rem;border-bottom:1px solid var(--bd);gap:.7rem;font-size:.8rem;background:var(--b3);flex-shrink:0}
.dvt-name{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:500}
.docs-viewer-ph{display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;text-align:center}
#docs-room-view{flex:1;display:flex;flex-direction:column;overflow:hidden;min-height:0}
/* ── Web room browser chrome ── */
#web-room-view{position:absolute;inset:0;display:flex;flex-direction:column;background:var(--b2);z-index:10}
.wb-chrome{flex:1;display:flex;flex-direction:column;overflow:hidden;min-height:0;background:var(--b3)}
.wb-tabbar{display:flex;align-items:flex-end;padding:.3rem .5rem 0;gap:.25rem;background:var(--b4);border-bottom:1px solid var(--bd)}
.wb-tab{display:flex;align-items:center;gap:.35rem;padding:.3rem .7rem .35rem;border-radius:6px 6px 0 0;background:var(--b3);border:1px solid var(--bd);border-bottom:none;font-size:.78rem;max-width:200px;position:relative;bottom:-1px}
.wb-tab-favicon{font-size:.85rem}
.wb-tab-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:120px;font-size:.78rem}
.wb-toolbar{display:flex;align-items:center;gap:.3rem;padding:.3rem .5rem;background:var(--b3);border-bottom:1px solid var(--bd);flex-shrink:0}
.wb-nav-btn{background:none;border:none;color:var(--txt);cursor:pointer;font-size:1.1rem;width:28px;height:28px;border-radius:5px;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:background .12s}
.wb-nav-btn:hover:not(:disabled){background:var(--b5)}
.wb-nav-btn:disabled{opacity:.3;cursor:default}
.wb-nav-btn.wb-ext{text-decoration:none;color:var(--go)!important;font-size:.85rem}
.wb-uv-toggle{font-size:.68rem!important;padding:0 .42rem!important;height:22px;border:1px solid var(--bd)!important;border-radius:10px!important;white-space:nowrap;min-width:52px}
.wb-uv-toggle:not(:disabled):hover{background:var(--b5)!important;cursor:pointer}
.wb-uv-toggle:disabled{opacity:.55;cursor:default}
.wb-addr-wrap{flex:1;display:flex;align-items:center;background:var(--b2);border:1px solid var(--bd);border-radius:20px;padding:0 .4rem;gap:.25rem;min-width:0;transition:border-color .15s}
.wb-addr-wrap:focus-within{border-color:var(--go)}
.wb-secure{font-size:.75rem;flex-shrink:0;opacity:.6}
.wb-addr{flex:1;background:none;border:none;outline:none;font-size:.78rem;color:var(--txt);padding:.22rem 0;min-width:0}
.wb-addr-go{background:none;border:none;color:var(--txm);cursor:pointer;font-size:.85rem;padding:.1rem .2rem;border-radius:4px;flex-shrink:0}
.wb-addr-go:hover{color:var(--go)}
.wb-frame-wrap{flex:1;position:relative;min-height:0;display:flex;flex-direction:column}
.wb-iframe{width:100%;flex:1;border:none;background:#fff;min-height:0}
.wb-loading{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.8rem;background:var(--b2);z-index:5;transition:opacity .2s}
.wb-loading.hidden{display:none}
.wb-spinner{width:32px;height:32px;border:3px solid var(--bd);border-top-color:var(--go);border-radius:50%;animation:wb-spin .7s linear infinite}
@keyframes wb-spin{to{transform:rotate(360deg)}}
.wb-blocked{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;background:var(--b2);z-index:4;padding:2rem}
.wb-blocked.hidden{display:none}
.btn-go-ext{display:inline-block;padding:.5rem 1.2rem;background:var(--go);color:#fff;border-radius:8px;text-decoration:none;font-size:.85rem;font-weight:500}
.btn-go-ext:hover{filter:brightness(1.1)}
.web-room-nourl{display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%}
/* ── Link previews ── */
.link-preview-card{display:flex;gap:.5rem;background:var(--b3);border:1px solid var(--bd);border-radius:8px;overflow:hidden;margin-top:.5rem;cursor:pointer;max-width:420px;transition:border-color .14s}
.link-preview-card:hover{border-color:var(--go)}
.lp-img-wrap{width:80px;min-width:80px;max-height:80px;background:var(--b4);overflow:hidden;flex-shrink:0}
.lp-img-wrap.lp-noimg{display:none}
.lp-img{width:100%;height:100%;object-fit:cover;display:block}
.lp-body{padding:.45rem .6rem;display:flex;flex-direction:column;gap:.12rem;min-width:0;flex:1}
.lp-site{font-size:.69rem;color:var(--go);font-weight:600;text-transform:uppercase;letter-spacing:.04em}
.lp-title{font-size:.8rem;font-weight:500;line-height:1.3;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
.lp-desc{font-size:.75rem;color:var(--txm);line-height:1.4;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
.lp-url{font-size:.69rem;color:var(--txm);opacity:.55;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:.1rem}
.ni-kind-badge{font-size:.68rem;opacity:.65;margin-left:.2rem}
`;
    document.head.appendChild(s);
})();

/* ── Append message ───────────────────────────────────────────────────────── */
function appendMsg(msg, scroll = true) {
    const list = document.getElementById('msgs-list'); if (!list) return;

    if (msg.type === 'system') {
        const el = document.createElement('div');
        el.className = 'msg sys'; el.textContent = msg.content;
        list.appendChild(el);
        if (scroll) scrollBottom();
        return;
    }

    const prev = list.lastElementChild;
    const sameUser = prev && prev.dataset.uid === msg.user_id &&
        (Date.now() - new Date(prev.dataset.t).getTime()) < 5 * 60000 &&
        msg.type === prev.dataset.type;

    const face = FACES[(msg.face_id || 1) - 1] || '👤';
    const t    = new Date(msg.created_at).toLocaleTimeString('es-AR', { hour:'2-digit', minute:'2-digit' });
    const clr  = CLS_COLOR[msg.char_class] || CLS_COLOR.default;

    const badges =
        (msg.role==='admin'?'<span class="badge b-admin">Admin</span>':
         msg.role==='moderator'?'<span class="badge b-mod">Mod</span>':'') +
        `<span class="badge b-cls" style="border-color:${clr}44;color:${clr}">${esc(msg.char_class||'')}</span>`;

    const lvlHtml   = msg.level ? `<span class="msg-lvl">Nv.${msg.level}</span>` : '';
    const titleHtml = msg.custom_title ? `<span class="msg-title">"${esc(msg.custom_title)}"</span>` : '';

    // Contenido
    let contentHtml = '';
    if (msg.type === 'file')
        contentHtml = `<div class="msg-file" onclick="downloadFile('${msg.file_id}')">
            <span>📎</span><div><div class="mf-name">${esc(msg.file_name||'archivo')}</div>
            <div class="mf-size">${fmtBytes(msg.file_size||0)}</div></div></div>`;
    else if (msg.type === 'poll')
        contentHtml = `<div class="poll-card"><div class="poll-q">📊 ${esc(msg.content)}</div>
            <div id="poll-opts-${msg.id}"><div style="color:var(--txm);font-size:.8rem">Cargando...</div></div></div>`;
    else if (msg.type === 'me')
        contentHtml = `<div class="msg-text">✨ <em>${esc(msg.content)}</em></div>`;
    else if (msg.type === 'dice')
        contentHtml = `<div class="msg-text" style="color:var(--yw,#e67e22)">🎲 ${esc(msg.content)}</div>`;
    else {
        contentHtml = `<div class="msg-text">${embedYoutube(fmtText(msg.content))}</div>`;
        // Attach link preview cards asynchronously (doesn't block render)
        if (/https?:\/\//.test(msg.content)) {
            setTimeout(() => {
                const el2 = document.getElementById(`msg-${msg.id}`);
                if (el2) attachLinkPreviews(el2, msg.content);
            }, 50);
        }
    }

    const replyHtml = msg.reply_data ?
        `<div class="msg-reply-quote" onclick="scrollToMsg('${msg.reply_to_id}')">
            <span class="rq-user">↩ ${esc(msg.reply_data.username)}</span>${esc(msg.reply_data.content)}</div>` : '';

    // Reacciones
    const rxn = S.reactions[msg.id] || { likes: msg.likes||0, dislikes: msg.dislikes||0, my_vote: null };
    S.reactions[msg.id] = rxn;

    const canMod = ['admin','moderator'].includes(S.user?.role);
    const isOwnMsg = msg.user_id === S.user?.id;
    const actHtml = `<div class="msg-actions">
        <button class="ma-btn" onclick="setReply('${msg.id}','${esc(msg.username)}','${esc(msg.content.slice(0,50))}')" title="Responder">↩</button>
        ${!isOwnMsg ? `<button class="ma-btn" onclick="openDmTo('${msg.user_id}','${esc(msg.username)}')" title="DM">✉️</button>` : ''}
        ${canMod && !isOwnMsg ? `<button class="ma-btn" style="color:var(--yw,#e67e22)" onclick="quickWarn('${msg.user_id}','${esc(msg.username)}','${msg.id}')" title="Advertir">⚠️</button>` : ''}
        ${canMod ? `<button class="ma-btn" style="color:var(--red)" onclick="adminDeleteMsg('${msg.id}')" title="Eliminar mensaje">🗑</button>` : ''}
    </div>`;

    const el = document.createElement('div');
    el.className = `msg${sameUser?' consec':''}${msg.type==='me'?' me-msg':''}${msg.type==='dice'?' dice-msg':''}`;
    el.id = `msg-${msg.id}`; el.dataset.uid = msg.user_id;
    el.dataset.t = msg.created_at; el.dataset.type = msg.type;
    el.innerHTML = `
        <div class="msg-av" style="border-color:${clr}55" onclick="showProfile('${msg.user_id}')">${face}</div>
        <div class="msg-body">
          <div class="msg-hdr">
            <span class="msg-un" style="color:${clr}" onclick="showProfile('${msg.user_id}')">${esc(msg.username)}</span>
            ${lvlHtml}${badges}${titleHtml}
            <span class="msg-time">${t}</span>
          </div>
          ${replyHtml}${contentHtml}
          <div class="msg-reactions" id="rxn-${msg.id}">
            <button class="rxn-btn${rxn.my_vote==='like'?' active-like':''}" onclick="toggleReaction('${msg.id}','like')">
              👍 <span id="likes-${msg.id}">${rxn.likes}</span></button>
            <button class="rxn-btn${rxn.my_vote==='dislike'?' active-dislike':''}" onclick="toggleReaction('${msg.id}','dislike')">
              👎 <span id="dislikes-${msg.id}">${rxn.dislikes}</span></button>
          </div>
        </div>${actHtml}`;
    list.appendChild(el);

    if (msg.type === 'poll') loadPollCard(msg.id);

    if (scroll) {
        const w = document.getElementById('msgs-wrap');
        const atBot = w.scrollHeight - w.scrollTop - w.clientHeight < 140;
        atBot ? scrollBottom() : document.getElementById('scroll-btn').classList.remove('hidden');
    }
}

function scrollToMsg(id) {
    const el = document.getElementById(`msg-${id}`);
    if (!el) return;
    el.scrollIntoView({ behavior:'smooth', block:'center' });
    el.style.background = 'var(--b5)';
    setTimeout(() => el.style.background = '', 1200);
}
function scrollBottom() {
    const w = document.getElementById('msgs-wrap'); if (w) w.scrollTop = w.scrollHeight;
    document.getElementById('scroll-btn')?.classList.add('hidden');
}

/* ── Polls ────────────────────────────────────────────────────────────────── */
async function loadPollCard(messageId) {
    try {
        const poll = await api('GET', `/api/polls/by-message/${messageId}`);
        renderPollOpts(messageId, poll);
    } catch(_) {}
}
function renderPollOpts(messageId, poll) {
    const c = document.getElementById(`poll-opts-${messageId}`); if (!c) return;
    const total = poll.options.reduce((s, o) => s + parseInt(o.votes||0, 10), 0) || 1;
    c.innerHTML = poll.options.map(o => {
        const pct    = Math.round(parseInt(o.votes||0, 10) / total * 100);
        const voted  = poll.my_vote === o.id;
        const onClick = poll.my_vote ? '' : `onclick="votePoll('${poll.id}','${o.id}','${messageId}')"`;
        return `<div class="poll-opt${voted?' voted':''}" ${onClick}>
            <span class="poll-opt-label">${esc(o.text)}</span>
            <div class="poll-bar-wrap"><div class="poll-bar" style="width:${pct}%"></div></div>
            <span class="poll-pct">${pct}%</span>
            <span style="font-size:.72rem;color:var(--txm)"> (${o.votes})</span>
        </div>`;
    }).join('') + `<div class="poll-meta">${total === 1 ? '0' : total} voto(s)</div>`;
}
async function votePoll(pollId, optId, msgId) {
    try {
        const d = await api('POST', `/api/polls/${pollId}/vote`, { option_id: optId });
        renderPollOpts(msgId, { id: pollId, options: d.options, my_vote: optId });
        toast('Voto registrado ✓', 'success');
    } catch(e) { toast(e.message, 'error'); }
}
function initPollOpts() {
    S.pollOpts = ['po_1', 'po_2']; renderPollOptsUI();
}
function renderPollOptsUI() {
    const c = document.getElementById('poll-opts-ui'); if (!c) return;
    c.innerHTML = S.pollOpts.map((id, i) => `
        <div class="poll-opt-input">
          <input class="poll-input" id="${id}" placeholder="Opción ${i+1}..."/>
          ${S.pollOpts.length > 2 ? `<button class="ico-btn" onclick="removePollOpt('${id}')" style="color:var(--red)">✕</button>` : ''}
        </div>`).join('');
}
function addPollOpt() { if (S.pollOpts.length >= 6) { toast('Máximo 6 opciones','warn'); return; } S.pollOpts.push('po_'+Date.now()); renderPollOptsUI(); }
function removePollOpt(id) { if (S.pollOpts.length <= 2) return; S.pollOpts = S.pollOpts.filter(x=>x!==id); renderPollOptsUI(); }
function togglePollBuilder() { document.getElementById('poll-builder').classList.toggle('hidden'); }
function closePollBuilder() { document.getElementById('poll-builder').classList.add('hidden'); document.getElementById('poll-q').value = ''; initPollOpts(); }
async function submitPoll() {
    const q = document.getElementById('poll-q').value.trim();
    if (!q) { toast('Escribí una pregunta','warn'); return; }
    const opts = S.pollOpts.map(id => document.getElementById(id)?.value?.trim()).filter(Boolean);
    if (opts.length < 2) { toast('Mínimo 2 opciones','warn'); return; }
    if (!S.room) { toast('Seleccioná una sala','warn'); return; }
    try {
        const d = await api('POST', '/api/polls', { room_id: S.room.id, question: q, options: opts });
        // El mensaje ya fue creado en la DB por /api/polls.
        // Solo broadcast a la sala sin guardarlo de nuevo.
        const pollMsg = {
            id: d.message_id, room_id: S.room.id,
            user_id: S.user.id, username: S.user.username,
            role: S.user.role, char_class: S.user.class,
            face_id: S.user.face_id, level: S.user.level,
            custom_title: S.user.custom_title,
            content: q, type: 'poll',
            likes: 0, dislikes: 0,
            created_at: d.created_at || new Date().toISOString(),
        };
        // Emitir a todos via broadcast (no crea nuevo mensaje en DB)
        S.socket?.emit('message:broadcast', { roomId: S.room.id, message: pollMsg });
        // También agregar localmente para el creador
        appendMsg(pollMsg);
        closePollBuilder();
        toast('Encuesta creada','success');
    } catch(e) { toast(e.message,'error'); }
}

/* ── Reactions ────────────────────────────────────────────────────────────── */
async function toggleReaction(msgId, type) {
    try {
        const d = await api('POST', `/api/reactions/${msgId}`, { type });
        S.reactions[msgId] = d;
        updateRxnUI(msgId, d);
        S.socket?.emit('reaction:update', { roomId: S.room?.id, messageId: msgId, likes: d.likes, dislikes: d.dislikes });
    } catch(e) { toast(e.message,'error'); }
}
function updateRxnUI(msgId, d) {
    const lk = document.getElementById(`likes-${msgId}`), dk = document.getElementById(`dislikes-${msgId}`);
    if (lk) lk.textContent = d.likes;
    if (dk) dk.textContent = d.dislikes;
    const div = document.getElementById(`rxn-${msgId}`);
    if (div) {
        div.querySelectorAll('.rxn-btn')[0]?.classList.toggle('active-like',    d.my_vote==='like');
        div.querySelectorAll('.rxn-btn')[1]?.classList.toggle('active-dislike', d.my_vote==='dislike');
    }
}

/* ── Reply ────────────────────────────────────────────────────────────────── */
function setReply(msgId, username, preview) {
    S.replyTo = { id: msgId, username, preview };
    document.getElementById('reply-bar').classList.remove('hidden');
    document.getElementById('reply-username').textContent = username;
    document.getElementById('reply-preview').textContent  = preview + (preview.length >= 50 ? '...' : '');
    document.getElementById('msg-input').focus();
}
function clearReply() {
    S.replyTo = null;
    document.getElementById('reply-bar')?.classList.add('hidden');
}

/* ── Search ───────────────────────────────────────────────────────────────── */
function toggleSearch() {
    const bar = document.getElementById('search-bar-wrap');
    bar.classList.toggle('hidden');
    if (!bar.classList.contains('hidden')) document.getElementById('search-input').focus();
    else clearSearch();
}
function clearSearch() {
    document.getElementById('search-bar-wrap')?.classList.add('hidden');
    document.getElementById('search-results')?.classList.add('hidden');
    if (document.getElementById('search-input')) document.getElementById('search-input').value = '';
}
function debSearch() { clearTimeout(S.searchTimeout); S.searchTimeout = setTimeout(doSearch, 400); }
async function doSearch() {
    const q   = document.getElementById('search-input')?.value.trim();
    const res = document.getElementById('search-results');
    if (!q || !S.room || !res) { res?.classList.add('hidden'); return; }
    try {
        const rows = await api('GET', `/api/search/${S.room.id}?q=${encodeURIComponent(q)}`);
        if (!rows.length) res.innerHTML = '<div style="padding:.65rem;font-size:.82rem;color:var(--txm)">Sin resultados</div>';
        else res.innerHTML = rows.map(r => `
            <div class="sr-item" onclick="scrollToMsg('${r.id}')">
              <span class="sr-user">${esc(r.username)}</span>
              <span class="sr-text">${esc(r.content)}</span>
              <span class="sr-time">${new Date(r.created_at).toLocaleDateString('es-AR')}</span>
            </div>`).join('');
        res.classList.remove('hidden');
    } catch(_) { res.classList.add('hidden'); }
}

/* ── Toolbar ──────────────────────────────────────────────────────────────── */
function insertDice() {
    var panel = document.getElementById('dice-picker');
    if (!panel) return;
    if (!panel.dataset.built) {
        [4,6,8,10,12,20,100].forEach(function(s){
            var b=document.createElement('button');
            b.className='dice-btn';b.textContent='d'+s;b.title='Dado de '+s+' caras';
            b.onclick=function(ev){ev.stopPropagation();rollDice(s);};
            panel.appendChild(b);
        });
        panel.dataset.built='1';
    }
    var wasHidden=panel.classList.contains('hidden');
    panel.classList.toggle('hidden');
    if(wasHidden){
        setTimeout(function(){
            var close=function(e){
                if(!panel.contains(e.target)&&!e.target.closest('[onclick*="insertDice"]')){
                    panel.classList.add('hidden');
                    document.removeEventListener('click',close);
                }
            };
            document.addEventListener('click',close);
        },10);
    }
}
function insertMe(){var inp=document.getElementById('msg-input');if(!inp.value.startsWith('/me'))inp.value='/me '+inp.value;inp.focus();}
var _emoteTabIdx=0;
function buildEmotePanel(){
    var p=document.getElementById('emote-panel');
    if(!p)return;
    var search=(p.querySelector('.ep-search')||{value:''}).value.toLowerCase();
    var pairs=search
        ?Object.entries(EMOTES).filter(function(x){return x[0].includes(search);})
        :(EMOTE_CATS[_emoteTabIdx]||{emotes:[]}).emotes.map(function(cmd){return[cmd,EMOTES[cmd]];}).filter(function(x){return x[1];});
    var tabs=EMOTE_CATS.map(function(cat,i){
        return '<button class="ep-tab'+(i===_emoteTabIdx&&!search?' ep-active':'')
            +'" onclick="_emoteTabIdx='+i+';buildEmotePanel()">'+cat.name+' '+cat.label+'</button>';
    }).join('');
    var grid=pairs.map(function(x){
        return '<button class="emote-item" title="'+x[0]+'" onclick="insertEmote(\"'+x[0]+'\")">'+x[1]+'</button>';
    }).join('');
    p.innerHTML='<div class="ep-hdr"><div class="ep-tabs">'+tabs+'</div>'
        +'<input class="ep-search" placeholder="buscar..." value="'+esc(search)+'" oninput="buildEmotePanel()"'
        +' style="flex:1;min-width:0;background:var(--b1);border:1px solid var(--bd);border-radius:5px;padding:.2rem .35rem;color:var(--txt);font-size:.74rem;outline:none"/></div>'
        +'<div class="ep-grid">'+(grid||'<span style="padding:.6rem;color:var(--txm);font-size:.8rem">Sin resultados</span>')+'</div>';
}
function insertEmote(cmd){
    var inp=document.getElementById('msg-input');
    if(!inp)return;
    inp.value+=(inp.value&&!inp.value.endsWith(' ')?' ':'')+cmd+' ';
    inp.focus();
    var p=document.getElementById('emote-panel');if(p)p.classList.add('hidden');
}
function toggleEmotes(){
    var p=document.getElementById('emote-panel');
    if(!p)return;
    var hiding=!p.classList.contains('hidden');
    p.classList.toggle('hidden');
    if(!hiding){
        buildEmotePanel();
        setTimeout(function(){
            var close=function(e){
                if(!p.contains(e.target)&&!e.target.closest('[onclick*="toggleEmotes"]')){
                    p.classList.add('hidden');
                    document.removeEventListener('click',close);
                }
            };
            document.addEventListener('click',close);
        },10);
    }
}

/* ── Typing ───────────────────────────────────────────────────────────────── */
function onTyping() {
    if (!S.room) return;
    S.socket?.emit('typing:start', { roomId: S.room.id });
    clearTimeout(S.typingTimer);
    S.typingTimer = setTimeout(() => S.socket?.emit('typing:stop', { roomId: S.room.id }), 2000);
}
function renderTyping() {
    const users = Object.values(S.typingUsers).filter(u => u !== S.user?.username);
    const el    = document.getElementById('typing-indicator'); if (!el) return;
    if (!users.length) { el.innerHTML = ''; return; }
    el.innerHTML = `${users.slice(0, 2).map(esc).join(' y ')} ${users.length===1?'está':'están'} escribiendo <span class="typing-dots"><span>•</span><span>•</span><span>•</span></span>`;
}

/* ── Send ─────────────────────────────────────────────────────────────────── */
function sendMsg() {
    const inp = document.getElementById('msg-input');
    const txt = inp.value.trim();
    if (!txt && !S.attach) return;
    if (!S.room) return;
    document.getElementById('emote-panel').classList.add('hidden');
    if (S.attach) { uploadAndSend(S.attach, txt); removeAttach(); }
    else S.socket?.emit('message:send', { roomId: S.room.id, content: txt, type: 'text', reply_to_id: S.replyTo?.id || null });
    inp.value = ''; inp.style.height = 'auto';
    clearReply();
    S.socket?.emit('typing:stop', { roomId: S.room.id });
    clearTimeout(S.typingTimer);
}
function onMsgKey(e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMsg(); } }
function autoGrow(el) { el.style.height = 'auto'; el.style.height = Math.min(el.scrollHeight, 120) + 'px'; }

/* ── Files ────────────────────────────────────────────────────────────────── */
function onFileAttach(inp) {
    const f = inp.files[0]; if (!f) return;
    if (f.size > 50 * 1024 * 1024) { toast('Supera los 50 MB', 'error'); return; }
    S.attach = f;
    document.getElementById('attach-name').textContent = `📎 ${f.name} (${fmtBytes(f.size)})`;
    document.getElementById('attach-bar').classList.remove('hidden');
}
function removeAttach() { S.attach = null; document.getElementById('attach-bar').classList.add('hidden'); document.getElementById('file-input').value = ''; }
async function uploadAndSend(file, caption) {
    try {
        const fd = new FormData(); fd.append('file', file); fd.append('roomId', S.room.id);
        const r  = await fetch('/api/files/upload', { method:'POST', headers:{'Authorization':'Bearer '+S.token}, body:fd });
        const d  = await r.json(); if (!r.ok) throw new Error(d.error);
        S.socket?.emit('message:send', { roomId:S.room.id, content:caption||file.name, type:'file', file_id:d.id, file_name:file.name, file_size:file.size });
    } catch(e) { toast('Error al subir: ' + e.message, 'error'); }
}
async function downloadFile(fileId) {
    try {
        // Descargar con fetch para incluir el token de autenticación
        const resp = await fetch(`/api/files/${fileId}/download`, {
            headers: { 'Authorization': 'Bearer ' + S.token }
        });
        if (!resp.ok) {
            const d = await resp.json().catch(() => ({}));
            throw new Error(d.error || 'Error al descargar');
        }
        const blob = await resp.blob();
        const disposition = resp.headers.get('Content-Disposition') || '';
        const nameMatch = disposition.match(/filename="([^"]+)"/i);
        const filename    = nameMatch ? decodeURIComponent(nameMatch[1]) : 'archivo';
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = filename;
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 10000);
    }
    catch { toast('Error al descargar', 'error'); }
}

/* ── Mod actions desde chat ───────────────────────────────────────────────── */
async function adminDeleteMsg(msgId) {
    if (!confirm('¿Eliminar este mensaje?')) return;
    try {
        await api('DELETE', `/api/admin/messages/${msgId}`);
        const el = document.getElementById(`msg-${msgId}`);
        if (el) { const t = el.querySelector('.msg-text'); if (t) t.innerHTML = '<em style="color:var(--txm)">[Mensaje eliminado]</em>'; el.style.opacity = '.5'; }
        toast('Mensaje eliminado', 'success');
    } catch(e) { toast(e.message, 'error'); }
}
async function quickWarn(userId, username, msgId) {
    const reason = prompt(`Razón de la advertencia para ${username}:`);
    if (!reason) return;
    try {
        const d = await api('POST', `/api/warnings/${userId}`, { reason, message_id: msgId });
        toast(`${username} advertido. Total: ${d.warn_count}${d.auto_banned?' — BANEADO AUTOMÁTICAMENTE':''}`, d.auto_banned?'error':'warn');
    } catch(e) { toast(e.message, 'error'); }
}

/* ── Status ───────────────────────────────────────────────────────────────── */
function toggleUserMenu()  { document.getElementById('user-menu').classList.toggle('hidden'); }
function closeUserMenu()   { document.getElementById('user-menu')?.classList.add('hidden'); }
document.addEventListener('click', e => { if (!document.getElementById('user-card-btn')?.contains(e.target)) closeUserMenu(); });
function setStatus(st) {
    closeUserMenu();
    S.socket?.emit('user:status', { status: st, status_text: '' });
    if (S.user) S.user.user_status = st;
}

/* ── Members ──────────────────────────────────────────────────────────────── */
function toggleMembers() { document.getElementById('members-panel').classList.toggle('hidden'); }
function renderMembers(members) {
    document.getElementById('members-list').innerHTML = members.map(m => {
        const st  = m.user_status || 'online';
        const clr = CLS_COLOR[m.class] || '#555';
        return `<div class="mi" onclick="showProfile('${m.id}')">
          <div class="mi-av" style="border-color:${clr}55">${FACES[(m.face_id||1)-1]||'👤'}
            <div class="mi-dot ${st}"></div></div>
          <div>
            <div class="mi-name">${esc(m.username)}${m.level?` <span class="mi-lvl">Nv.${m.level}</span>`:''}</div>
            <div class="mi-cls">${STATUS_ICONS[st]||'🟢'} ${esc(m.race||'')} · ${esc(m.class||'')}</div>
          </div>
        </div>`;
    }).join('');
}

/* ── DM ───────────────────────────────────────────────────────────────────── */
async function loadDmList() {
    try {
        const convs = await api('GET', '/api/dm');
        const c = document.getElementById('dm-conversations-list');
        if (!convs.length) {
            c.innerHTML = '<div style="padding:2rem;text-align:center;color:var(--txm)">Sin conversaciones aún.<br>Hacé click en el avatar de un usuario para escribirle.</div>';
            return;
        }
        c.innerHTML = convs.map(cv => `
            <div onclick="openDmTo('${cv.partner_id}','${esc(cv.partner_username)}')"
              style="display:flex;align-items:center;gap:.65rem;padding:.7rem;
                border-bottom:1px solid var(--bd);cursor:pointer;transition:background .12s"
              onmouseover="this.style.background='var(--b5)'" onmouseout="this.style.background=''">
              <span style="font-size:1.4rem">${FACES[(cv.partner_face_id||1)-1]||'👤'}</span>
              <div style="flex:1;min-width:0">
                <div style="font-weight:600;font-size:.9rem">${esc(cv.partner_username)}</div>
                <div style="font-size:.78rem;color:var(--txm);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(cv.last_content||'')}</div>
              </div>
              ${cv.unread_count>0?`<span class="badge-red">${cv.unread_count}</span>`:''}
            </div>`).join('');
    } catch(e) { toast('Error cargando DMs: ' + e.message, 'error'); }
}
async function openDmTo(userId, username) {
    if (userId === S.user?.id) { toast('No podés escribirte a vos mismo','warn'); return; }
    S.dmUserId = userId; S.dmUsername = username;
    document.getElementById('dm-chat-av').textContent   = FACES[(S.user?.face_id||1)-1]||'👤';
    document.getElementById('dm-chat-name').textContent = username;
    document.getElementById('dm-msgs-list').innerHTML   = '';
    goToSection('dm-chat');
    try {
        const msgs = await api('GET', `/api/dm/${userId}`);
        const list = document.getElementById('dm-msgs-list');
        msgs.forEach(m => {
            const mine = m.sender_id === S.user?.id;
            const el   = document.createElement('div');
            el.innerHTML = `<div class="dm-bubble ${mine?'me':'them'}">${esc(m.content)}
                <div class="dm-time">${new Date(m.created_at).toLocaleTimeString('es-AR',{hour:'2-digit',minute:'2-digit'})}</div>
            </div>`;
            list.appendChild(el.firstChild);
        });
        document.getElementById('dm-msgs-wrap').scrollTop = 99999;
        checkDmUnread();
    } catch(e) { toast('Error cargando mensajes: ' + e.message, 'error'); }
}
function sendDm() {
    const inp = document.getElementById('dm-input');
    const txt = inp.value.trim();
    if (!txt || !S.dmUserId) return;
    S.socket?.emit('dm:send', { to_user_id: S.dmUserId, content: txt });
    inp.value = '';
}
function onDmKey(e) { if (e.key === 'Enter') { e.preventDefault(); sendDm(); } }
async function checkDmUnread() {
    try {
        const { unread } = await api('GET', '/api/dm/unread/count');
        const badge = document.getElementById('dm-badge');
        if (badge) { badge.textContent = unread; badge.classList.toggle('hidden', unread === 0); }
    } catch(_) {}
}

/* ── Profile ──────────────────────────────────────────────────────────────── */
async function showProfile(userId) {
    try {
        const u    = await api('GET', `/api/users/${userId}/public`);
        const face = FACES[(u.face_id||1)-1] || '👤';
        const clr  = CLS_COLOR[u.class] || '#555';
        const xpNext = Math.pow(((u.level||1)+1), 2) * 50;
        const xpCurr = Math.pow((u.level||1), 2) * 50;
        const xpPct  = Math.round(Math.max(0, Math.min(100, (u.xp-xpCurr)/(xpNext-xpCurr)*100)));

        openModal(`Personaje: ${u.username}`, `
            <div class="prof-card">
              <div class="prof-av">${face}</div>
              <div class="prof-name" style="color:${clr}">${esc(u.username)}</div>
              ${u.custom_title?`<div class="prof-title">"${esc(u.custom_title)}"</div>`:''}
              <div style="text-align:center;font-size:.8rem;color:var(--txm)">Nivel ${u.level||1} · ${u.xp||0} XP</div>
              <div class="prof-xp-bar"><div class="prof-xp-fill" style="width:${xpPct}%"></div></div>
              <div class="prof-grid">
                ${[['Raza',u.race],['Género',u.gender],['Clase',u.class],['Profesión',u.profession]].map(([l,v])=>
                    `<div class="prof-item"><div class="prof-lbl">${l}</div><div class="prof-val">${esc(v||'—')}</div></div>`).join('')}
                <div class="prof-item" style="grid-column:span 2">
                  <div class="prof-lbl">Miembro desde</div>
                  <div class="prof-val">${new Date(u.created_at).toLocaleDateString('es-AR')}</div>
                </div>
              </div>
              ${userId !== S.user?.id ? `
              <button class="btn-prim" style="margin-top:.5rem;font-size:.85rem"
                onclick="closeModal();openDmTo('${userId}','${esc(u.username)}')">✉️ Mensaje privado</button>` : ''}
            </div>`);
    } catch(e) { toast('No se pudo cargar el perfil','error'); }
}
async function loadMyProfile() {
    if (!S.user) return;
    const el = document.getElementById('my-profile-content');
    if (!el) { await showProfile(S.user.id); return; }

    try {
        const u    = await api('GET', `/api/users/${S.user.id}/public`);
        const face = FACES[(u.face_id||1)-1] || '👤';
        const clr  = CLS_COLOR[u.class] || 'var(--go)';
        const xpNext = Math.pow(((u.level||1)+1), 2) * 50;
        const xpCurr = Math.pow((u.level||1), 2) * 50;
        const xpPct  = Math.round(Math.max(0, Math.min(100, (u.xp-xpCurr)/(xpNext-xpCurr)*100)));

        el.innerHTML = `
        <div class="prof-card" style="max-width:480px;margin:0 auto">
          <div class="prof-av" style="font-size:3.5rem;text-align:center">${face}</div>
          <div class="prof-name" style="color:${clr}">${esc(u.username)}</div>
          ${u.custom_title ? `<div class="prof-title">"${esc(u.custom_title)}"</div>` : ''}
          <div style="text-align:center;font-size:.82rem;color:var(--txm)">Nivel ${u.level||1} · ${u.xp||0} XP</div>
          <div class="prof-xp-bar"><div class="prof-xp-fill" style="width:${xpPct}%"></div></div>
          <div class="prof-grid" style="margin-top:.75rem">
            ${[['Raza',u.race],['Género',u.gender],['Clase',u.class],['Profesión',u.profession]].map(([l,v])=>
                `<div class="prof-item"><div class="prof-lbl">${l}</div><div class="prof-val">${esc(v||'—')}</div></div>`).join('')}
            <div class="prof-item" style="grid-column:span 2">
              <div class="prof-lbl">Miembro desde</div>
              <div class="prof-val">${new Date(u.created_at).toLocaleDateString('es-AR')}</div>
            </div>
          </div>

          <div style="margin-top:1.25rem;border-top:1px solid var(--bd);padding-top:1rem">
            <div style="font-family:'Cinzel',serif;font-size:.78rem;color:var(--go);
              margin-bottom:.75rem;text-transform:uppercase;letter-spacing:.06em">
              ✏️ Editar mi perfil
            </div>
            <div style="display:flex;flex-direction:column;gap:.65rem">
              <div>
                <label style="font-size:.7rem;text-transform:uppercase;letter-spacing:.07em;
                  color:var(--txm);display:block;margin-bottom:.28rem">Cara del personaje</label>
                <div id="prof-face-grid" style="display:flex;flex-wrap:wrap;gap:4px;
                  background:var(--b1);border:1px solid var(--bd);border-radius:6px;
                  padding:.5rem;max-height:110px;overflow-y:auto"></div>
              </div>
              <div>
                <label style="font-size:.7rem;text-transform:uppercase;letter-spacing:.07em;
                  color:var(--txm);display:block;margin-bottom:.28rem">Descripción</label>
                <textarea id="prof-desc" style="width:100%;background:var(--b1);
                  border:1px solid var(--bd);border-radius:6px;padding:.5rem .7rem;
                  color:var(--tx);font-family:inherit;font-size:.9rem;resize:vertical;
                  min-height:72px;outline:none"
                  placeholder="Contá algo sobre tu personaje...">${esc(u.description||'')}</textarea>
              </div>
              <button class="btn-prim" style="margin-top:.25rem"
                onclick="saveMyProfile()">💾 Guardar cambios</button>
            </div>
          </div>
        </div>`;

        // Llenar la grilla de caras
        const grid = document.getElementById('prof-face-grid');
        if (grid) {
            FACES.forEach((f, i) => {
                const d = document.createElement('div');
                d.style.cssText = 'width:36px;height:36px;background:var(--b2);border:2px solid '+(i+1===u.face_id?'var(--go)':'transparent')+';border-radius:5px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;cursor:pointer;flex-shrink:0;transition:border-color .15s';
                d.textContent = f;
                d.dataset.idx = i+1;
                d.onclick = () => {
                    grid.querySelectorAll('div').forEach(x => x.style.borderColor='transparent');
                    d.style.borderColor = 'var(--go)';
                };
                grid.appendChild(d);
            });
        }
    } catch(e) { toast('Error cargando perfil','error'); }
}

async function saveMyProfile() {
    const grid = document.getElementById('prof-face-grid');
    const desc = document.getElementById('prof-desc');
    if (!grid || !desc) { toast('Error: campos no encontrados','error'); return; }
    const selected = grid.querySelector('div[style*="var(--go)"]');
    const face_id  = selected ? parseInt(selected.dataset.idx) : null;
    try {
        await api('PUT', '/api/users/me', {
            face_id:     face_id,
            description: desc.value.trim().slice(0, 500),
        });
        toast('Perfil actualizado ✓','success');
        // Actualizar avatar en sidebar
        if (face_id && S.user) {
            S.user.face_id = face_id;
            document.getElementById('uc-av').textContent = FACES[face_id-1] || '👤';
        }
    } catch(e) { toast(e.message,'error'); }
}

/* ── Leaderboard ──────────────────────────────────────────────────────────── */
async function loadLeaderboard() {
    try {
        const rows = await api('GET', '/api/leaderboard');
        const c    = document.getElementById('lb-content');
        const me   = rows.find(r => r.id === S.user?.id);
        c.innerHTML = (me?`<div style="background:var(--goa);border:1px solid var(--god);border-radius:6px;
            padding:.55rem .9rem;margin-bottom:.85rem;font-size:.85rem;display:flex;align-items:center;gap:.65rem">
            <span style="color:var(--go);font-weight:700">#${me.rank}</span>
            <span>Tu posición — Nivel ${me.level} · ${me.xp} XP</span></div>`:'') +
            rows.slice(0, 50).map(r => `
            <div class="lb-row" onclick="showProfile('${r.id}')">
              <span class="lb-rank${r.rank<=3?` top${r.rank}`:''}">${r.rank<=3?['🥇','🥈','🥉'][r.rank-1]:r.rank}</span>
              <span style="font-size:1.1rem">${FACES[(r.face_id||1)-1]||'👤'}</span>
              <div style="flex:1;min-width:0">
                <span class="lb-name">${esc(r.username)}</span>
                <div style="font-size:.72rem;color:var(--txm)">${esc(r.race||'')} · ${esc(r.class||'')}</div>
              </div>
              <div style="text-align:right">
                <span class="lb-lvl">Nv.${r.level}</span>
                <div class="lb-xp">${r.xp} XP</div>
                <div style="font-size:.7rem;color:var(--txm)">${r.msg_count} msgs</div>
              </div>
            </div>`).join('');
    } catch(e) { toast('Error: ' + e.message,'error'); }
}

/* ── Socket ───────────────────────────────────────────────────────────────── */
function connectSocket() {
    S.socket = io({ auth: { token: S.token }, transports: ['websocket'] });

    S.socket.on('connect', () => {
        const st = document.getElementById('sb-status');
        if (st) { st.textContent = '● En línea'; st.style.color = 'var(--onl)'; }
        // Reconectar a sala activa tras reconexión
        if (S.room) S.socket.emit('room:join', { roomId: S.room.id });
    });
    S.socket.on('disconnect', () => {
        const st = document.getElementById('sb-status');
        if (st) { st.textContent = '● Reconectando...'; st.style.color = 'var(--go)'; }
    });
    S.socket.on('message:new', msg => {
        if (msg.room_id === S.room?.id) { appendMsg(msg); playSound('message'); }
        else {
            S.unread[msg.room_id] = (S.unread[msg.room_id]||0) + 1;
            renderRoomsInSidebar();
            const r = S.rooms.find(x => x.id === msg.room_id);
            if (r) notifyDesktop(`${msg.username} en ${r.name}`, msg.content);
        }
    });
    S.socket.on('room:members', ({ roomId, members, count }) => {
        const cnt = document.getElementById(`cnt-${roomId}`); if (cnt) cnt.textContent = count;
        if (roomId === S.room?.id) {
            document.getElementById('rh-cnt').textContent  = `${count} en línea`;
            document.getElementById('rbi-cnt').textContent = `${count} en línea`;
            if (!document.getElementById('members-panel').classList.contains('hidden')) renderMembers(members);
        }
    });
    S.socket.on('room:user_joined', ({ user, roomId }) => {
        if (roomId === S.room?.id) appendMsg({ type:'system', content:`${user.username} entró a la sala.`, created_at:new Date() });
    });
    S.socket.on('room:user_left', ({ user, roomId }) => {
        if (roomId === S.room?.id) appendMsg({ type:'system', content:`${user.username} salió.`, created_at:new Date() });
    });
    S.socket.on('typing:update', ({ user_id, username, typing }) => {
        if (typing) S.typingUsers[user_id] = username; else delete S.typingUsers[user_id];
        renderTyping();
    });
    S.socket.on('reaction:update', ({ messageId, likes, dislikes }) => {
        const c = S.reactions[messageId];
        if (c) { c.likes = likes; c.dislikes = dislikes; updateRxnUI(messageId, { ...c, likes, dislikes }); }
    });
    S.socket.on('dm:new', msg => {
        const inDm = document.getElementById('sec-dm-chat').classList.contains('active') && S.dmUserId === msg.sender_id;
        if (inDm) {
            const mine = msg.sender_id === S.user?.id;
            const list = document.getElementById('dm-msgs-list');
            const el   = document.createElement('div');
            el.innerHTML = `<div class="dm-bubble ${mine?'me':'them'}">${esc(msg.content)}
                <div class="dm-time">${new Date(msg.created_at).toLocaleTimeString('es-AR',{hour:'2-digit',minute:'2-digit'})}</div>
            </div>`;
            list.appendChild(el.firstChild);
            document.getElementById('dm-msgs-wrap').scrollTop = 99999;
        } else if (msg.sender_id !== S.user?.id) {
            toast(`✉️ DM de ${esc(msg.sender_username||'alguien')}: ${msg.content.slice(0,40)}`, 'dm');
            notifyDesktop(`DM de ${msg.sender_username}`, msg.content);
            playSound('dm');
            checkDmUnread();
        }
    });
    S.socket.on('level_up', ({ level, xp }) => {
        showLevelUp(level, xp);
        if (S.user) S.user.level = level;
        updateUserCard();
    });
    S.socket.on('achievement', ach => showAchievement(ach));
    S.socket.on('admin:stats_update', d => {
        const el = document.getElementById('nb-online'); if (el) el.textContent = d.online;
    });
    S.socket.on('admin:kick', ({ reason }) => { toast('Fuiste desconectado: ' + reason, 'error'); setTimeout(logout, 1800); });
    S.socket.on('error', ({ message }) => toast(message, 'warn'));
    S.socket.on('connect_error', e => { if (e.message === 'unauthorized') logout(); });
}

/* ── Notificaciones & sonidos ─────────────────────────────────────────────── */
function requestNotificationPermission() {
    if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission();
}
function notifyDesktop(title, body) {
    if (document.hasFocus()) return;
    if ('Notification' in window && Notification.permission === 'granted')
        new Notification(title, { body: body.slice(0, 100) });
}
function playSound(type) {
    try {
        const ctx  = new(window.AudioContext || window.webkitAudioContext)();
        const osc  = ctx.createOscillator(), gain = ctx.createGain();
        osc.connect(gain); gain.connect(ctx.destination);
        osc.frequency.setValueAtTime(type==='dm'?880:type==='levelup'?1047:440, ctx.currentTime);
        gain.gain.setValueAtTime(.1, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(.001, ctx.currentTime + .25);
        osc.start(); osc.stop(ctx.currentTime + .25);
    } catch(_) {}
}

/* ── Level-up & achievements ──────────────────────────────────────────────── */
function showLevelUp(level, xp) {
    const el = document.createElement('div');
    el.className = 'level-up-popup';
    el.innerHTML = `<div class="lup-icon">⭐</div>
        <div class="lup-title">¡SUBISTE DE NIVEL!</div>
        <div class="lup-sub">Ahora sos <strong style="color:var(--go)">Nivel ${level}</strong> · ${xp} XP</div>`;
    document.body.appendChild(el);
    playSound('levelup');
    setTimeout(() => { el.style.opacity='0'; el.style.transition='opacity .5s'; setTimeout(()=>el.remove(),500); }, 3000);
}
function showAchievement(ach) {
    const el = document.createElement('div');
    el.className = 'ach-popup';
    el.innerHTML = `<div class="ach-icon">${ach.icon||'🏅'}</div>
        <div><div class="ach-name">🏆 ${esc(ach.name)}</div>
        <div class="ach-desc">${esc(ach.description||'')}</div>
        ${ach.xp_reward?`<div class="ach-xp">+${ach.xp_reward} XP</div>`:''}</div>`;
    document.body.appendChild(el);
    setTimeout(() => { el.style.opacity='0'; el.style.transition='opacity .5s'; setTimeout(()=>el.remove(),500); }, 4500);
}

/* ── Modal ────────────────────────────────────────────────────────────────── */
function openModal(title, body, footerBtns = []) {
    document.getElementById('modal-title').textContent = title;
    document.getElementById('modal-body').innerHTML    = body;
    const mf = document.getElementById('modal-footer');
    if (footerBtns.length) {
        mf.innerHTML = footerBtns.map((b,i) => `<button class="adm-btn ${b.cls}" id="mfb-${i}">${b.lbl}</button>`).join('');
        mf.classList.remove('hidden');
        footerBtns.forEach((b,i) => document.getElementById(`mfb-${i}`).addEventListener('click', async () => {
            try { await b.fn(); } catch(e) { toast('Error: ' + e.message, 'error'); }
        }));
    } else mf.classList.add('hidden');
    document.getElementById('modal').classList.remove('hidden');
}
function closeModal(e) {
    if (e && e.target !== document.getElementById('modal')) return;
    document.getElementById('modal').classList.add('hidden');
}

/* ── Toast ────────────────────────────────────────────────────────────────── */
function toast(msg, type = 'info') {
    const c  = document.getElementById('toasts');
    const el = document.createElement('div');
    el.className = `toast ${type}`; el.textContent = msg; c.appendChild(el);
    setTimeout(() => { el.style.opacity='0'; el.style.transition='opacity .3s'; setTimeout(()=>el.remove(),300); }, 4000);
}

/* ── Helpers ──────────────────────────────────────────────────────────────── */
function buildFaces() {
    const g = document.getElementById('face-grid'); if (!g) return;
    FACES.forEach((f, i) => {
        const el = document.createElement('div');
        el.className = `face-opt${i===0?' sel':''}`; el.textContent = f; el.title = `Cara ${i+1}`;
        el.onclick = () => { document.querySelectorAll('.face-opt').forEach(x => x.classList.remove('sel')); el.classList.add('sel'); document.getElementById('r-face').value = i+1; };
        g.appendChild(el);
    });
}
async function api(m, p, b, noAuth = false) {
    const h = { 'Content-Type': 'application/json' };
    if (!noAuth && S.token) h['Authorization'] = 'Bearer ' + S.token;
    const r = await fetch(p, { method:m, headers:h, body:b?JSON.stringify(b):undefined });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || `HTTP ${r.status}`);
    return d;
}
function esc(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function fmtText(s) {
    return esc(s)
        .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.+?)\*/g,     '<em>$1</em>')
        .replace(/`(.+?)`/g,       '<code style="background:var(--b2);padding:1px 4px;border-radius:3px;font-size:.9em">$1</code>')
        .replace(/\n/g,            '<br>');
}


function fmtBytes(b) { if(b<1024) return b+' B'; if(b<1048576) return (b/1024).toFixed(1)+' KB'; return (b/1048576).toFixed(1)+' MB'; }
function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }


/* ── Sidebar ──────────────────────────────────────────────────────────────── */
function toggleSidebar() {
    const sb  = document.getElementById('sidebar');
    const exp = document.getElementById('sb-expand-btn');
    const tog = document.getElementById('sb-toggle-btn');
    if (!sb) return;
    const collapsed = sb.classList.toggle('collapsed');
    if (exp) exp.classList.toggle('hidden', !collapsed);
    if (tog) tog.textContent = collapsed ? '›' : '‹';
}

/* ── Guardar estado de texto personalizado ────────────────────────────────── */
function saveStatusText() {
    const txt = document.getElementById('status-text-inp')?.value || '';
    S.socket?.emit('user:status', { status: S.user?.user_status || 'online', status_text: txt });
    closeUserMenu();
    toast('Estado actualizado', 'success');
}

/* Redirigir /admin a / (el panel admin ahora está integrado) */
if (window.location.pathname.startsWith('/admin')) {
    // Si ya hay token, redirigir al chat principal
    if (localStorage.getItem('ao_token')) {
        window.location.replace('/');
    }
}

