#!/usr/bin/env bash
# =============================================================================
#  ARGENTUM ONLINE CHAT SERVER — DESINSTALADOR v3.0
#  Uso: sudo bash installer/uninstall.sh
# =============================================================================
set -uo pipefail

R='\033[1;31m' G='\033[1;32m' Y='\033[1;33m' B='\033[1;34m'
C='\033[1;36m' M='\033[1;35m' W='\033[1m' NC='\033[0m'

ok()   { echo -e "${G}  ✓  ${NC}$*"; }
warn() { echo -e "${Y}  ⚠  ${NC}$*"; }
info() { echo -e "${C}  ℹ  ${NC}$*"; }
step() { echo -e "\n${W}${Y}▶ $*${NC}"; }
ask()  { echo -ne "${Y}  ?  ${NC}$*"; }
line() { echo -e "${B}  ──────────────────────────────────────────────${NC}"; }

LOG="/tmp/ao-chat-uninstall.log"
DEST="/opt/ao-chat"
DB_NAME="ao_chat"
DB_USER="ao_admin"
MODE=""
BACKUP_FILE=""

[[ $EUID -eq 0 ]] || { echo -e "${R}Ejecutar como root: sudo bash installer/uninstall.sh${NC}"; exit 1; }

# Leer .env para obtener el puerto
APP_PORT="8080"
[[ -f "$DEST/.env" ]] && source "$DEST/.env" 2>/dev/null || true
APP_PORT="${PORT:-8080}"

# ── Pantalla de opciones ──────────────────────────────────────────────────────
menu() {
    clear
    echo -e "${R}"
    cat << 'EOF'
  ╔════════════════════════════════════════════════════════════╗
  ║                                                            ║
  ║    ⚠   DESINSTALADOR — ARGENTUM ONLINE CHAT  ⚠            ║
  ║                                                            ║
  ╚════════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"
    echo -e "  ${W}${R}Esta operación puede ser irreversible.${NC}"
    echo
    echo -e "  Se puede eliminar:"
    echo -e "  ${R}  ✗${NC}  Aplicación: ${W}$DEST${NC}"
    echo -e "  ${R}  ✗${NC}  Base de datos: ${W}${DB_NAME}${NC} y usuario ${W}${DB_USER}${NC}"
    echo -e "  ${R}  ✗${NC}  Proceso PM2: ${W}ao-chat${NC}"
    echo -e "  ${R}  ✗${NC}  Reglas de firewall (puerto $APP_PORT)"
    echo -e "  ${R}  ✗${NC}  Reglas de Fail2Ban"
    echo -e "  ${Y}  ⚠${NC}  Los paquetes del sistema (Node.js, PostgreSQL, Redis)"
    echo -e "       ${Y}NO${NC} se desinstalan — pueden ser usados por otras apps"
    echo
    line; echo
    echo -e "  ${W}Opciones:${NC}"
    echo -e "  ${C}  [1]${NC} Desinstalar todo (app + BD + configs)"
    echo -e "  ${C}  [2]${NC} Hacer backup PRIMERO y luego desinstalar todo"
    echo -e "  ${C}  [3]${NC} Solo detener el servidor (conservar archivos y BD)"
    echo -e "  ${C}  [4]${NC} Solo eliminar la base de datos (conservar archivos)"
    echo -e "  ${C}  [0]${NC} Cancelar"
    echo
    ask "Selección [0-4]: "; read -r CHOICE || CHOICE="0"

    case "$CHOICE" in
        1) MODE="full"   ;;
        2) MODE="backup" ;;
        3) MODE="stop"   ;;
        4) MODE="db"     ;;
        0|"") echo -e "\n  Cancelado."; exit 0 ;;
        *) menu; return ;;
    esac

    if [[ "$MODE" == "full" || "$MODE" == "backup" ]]; then
        echo
        echo -ne "  ${R}Escribí ${W}CONFIRMAR${R} para continuar: ${NC}"
        read -r c || c=""
        if [[ "$c" != "CONFIRMAR" ]]; then
            echo -e "\n  Cancelado."; exit 0
        fi
    fi
}

# ── Backup ────────────────────────────────────────────────────────────────────
do_backup() {
    local ts; ts=$(date +%Y%m%d-%H%M%S)
    local bdir="/root/ao-chat-backup-${ts}"
    mkdir -p "$bdir"
    step "Creando backup en $bdir..."

    info "Exportando base de datos..."
    sudo -u postgres pg_dump "${DB_NAME}" > "$bdir/database.sql" 2>>"$LOG" \
        && ok "BD exportada: $bdir/database.sql" \
        || warn "No se pudo exportar la BD"

    if [[ -d "$DEST/uploads" ]] && ls "$DEST/uploads"/* &>/dev/null 2>&1; then
        cp -r "$DEST/uploads" "$bdir/" 2>/dev/null \
            && ok "Uploads copiados" || warn "No se pudieron copiar los uploads"
    fi

    [[ -f "$DEST/.env" ]] && cp "$DEST/.env" "$bdir/" && chmod 600 "$bdir/.env" \
        && ok ".env copiado"

    [[ -d "$DEST/logs" ]] && cp -r "$DEST/logs" "$bdir/" 2>/dev/null && ok "Logs copiados"

    # Comprimir
    tar -czf "${bdir}.tar.gz" -C /root "ao-chat-backup-${ts}" 2>/dev/null
    rm -rf "$bdir"
    BACKUP_FILE="${bdir}.tar.gz"
    ok "Backup comprimido: $BACKUP_FILE"
    echo
    ask "Presioná Enter para continuar con la desinstalación..."; read -r || true
}

# ── Detener servidor ──────────────────────────────────────────────────────────
do_stop() {
    step "Deteniendo el servidor..."
    pm2 stop   ao-chat 2>/dev/null && ok "ao-chat detenido"  || warn "ao-chat no estaba corriendo"
    pm2 delete ao-chat 2>/dev/null && ok "ao-chat eliminado de PM2" || true
    pm2 save   2>/dev/null || true
}

# ── Eliminar BD ───────────────────────────────────────────────────────────────
do_db() {
    step "Eliminando base de datos y usuario PostgreSQL..."
    sudo -u postgres psql >> "$LOG" 2>&1 << PSQL
SELECT pg_terminate_backend(pid)
FROM pg_stat_activity
WHERE datname = '${DB_NAME}' AND pid <> pg_backend_pid();
DROP DATABASE IF EXISTS ${DB_NAME};
DROP ROLE IF EXISTS ${DB_USER};
PSQL
    ok "Base de datos '${DB_NAME}' y usuario '${DB_USER}' eliminados"
}

# ── Eliminar aplicación ───────────────────────────────────────────────────────
do_app() {
    step "Eliminando directorio de la aplicación..."
    [[ -d "$DEST" ]] && rm -rf "$DEST" && ok "$DEST eliminado" || warn "$DEST no existe"

    step "Limpiando reglas de UFW..."
    ufw delete allow "${APP_PORT}/tcp" >> "$LOG" 2>&1 || true
    ok "Regla UFW eliminada (puerto $APP_PORT)"

    step "Limpiando reglas de Fail2Ban..."
    rm -f /etc/fail2ban/jail.d/ao-chat.conf   2>/dev/null || true
    rm -f /etc/fail2ban/filter.d/ao-chat.conf 2>/dev/null || true
    systemctl restart fail2ban >> "$LOG" 2>&1 || true
    ok "Reglas Fail2Ban eliminadas"

    step "Limpiando caché Redis..."
    redis-cli FLUSHDB >> "$LOG" 2>&1 \
        && ok "Cache Redis limpiada" \
        || warn "No se pudo limpiar Redis (puede que no esté corriendo)"
}

# ── Final ─────────────────────────────────────────────────────────────────────
final() {
    clear
    echo -e "${G}"
    cat << 'EOF'
  ╔════════════════════════════════════════════════════════════╗
  ║       ✓  DESINSTALACIÓN COMPLETADA                        ║
  ╚════════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"
    case "$MODE" in
        stop)
            echo -e "  El servidor fue detenido. Archivos y BD conservados."
            echo -e "  Para reiniciar: ${C}cd $DEST && pm2 start server.js --name ao-chat --cwd $DEST${NC}"
            ;;
        db)
            echo -e "  Base de datos eliminada. Archivos conservados en $DEST"
            echo -e "  Para reinstalar la BD: ${C}sudo bash installer/install.sh${NC}"
            ;;
        full|backup)
            echo -e "  AO Chat fue eliminado completamente del sistema."
            [[ -n "$BACKUP_FILE" ]] && echo -e "  ${Y}Backup guardado en: ${W}$BACKUP_FILE${NC}"
            echo
            echo -e "  Para reinstalar desde cero:"
            echo -e "  ${C}  sudo bash installer/install.sh${NC}"
            ;;
    esac
    echo
    echo -e "  ${C}Log de desinstalación: $LOG${NC}"
    line; echo
}

# ── Main ──────────────────────────────────────────────────────────────────────
: > "$LOG"
menu

case "$MODE" in
    stop)   do_stop ;;
    db)     do_stop; do_db ;;
    backup) do_backup; do_stop; do_db; do_app ;;
    full)   do_stop; do_db; do_app ;;
esac

final
