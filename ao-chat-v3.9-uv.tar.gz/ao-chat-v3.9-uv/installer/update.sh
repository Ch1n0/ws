#!/usr/bin/env bash
# =============================================================================
#  ARGENTUM ONLINE CHAT — SCRIPT DE ACTUALIZACIÓN v3.9
#  Uso: sudo bash installer/update.sh
#
#  Aplica los archivos nuevos, corre la migración de BD y reinicia el servidor.
#  NO elimina datos ni la base de datos.
# =============================================================================
set -uo pipefail

R='\033[1;31m' G='\033[1;32m' Y='\033[1;33m' B='\033[1;34m'
C='\033[1;36m' W='\033[1m' NC='\033[0m'

ok()   { echo -e "${G}  ✓  ${NC}$*"; }
warn() { echo -e "${Y}  ⚠  ${NC}$*"; }
err()  { echo -e "${R}  ✗  ${NC}$*"; }
info() { echo -e "${C}  ℹ  ${NC}$*"; }
step() { echo -e "\n${W}${Y}▶ $*${NC}"; }
line() { echo -e "${B}  ──────────────────────────────────────────────${NC}"; }

[[ $EUID -eq 0 ]] || { echo -e "\n${R}  Ejecutar como root: sudo bash installer/update.sh${NC}\n"; exit 1; }

# Detectar rutas
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
DEST="/opt/ao-chat"
DB_NAME="ao_chat"

[[ -f "$PROJECT_DIR/server/server.js" ]] || {
    echo -e "\n${R}  Archivos no encontrados en: $PROJECT_DIR${NC}\n"; exit 1; }
[[ -d "$DEST" ]] || {
    echo -e "\n${R}  Instalación no encontrada en $DEST. Corré install.sh primero.${NC}\n"; exit 1; }

clear
echo -e "${C}"
cat << 'EOF'
  ╔════════════════════════════════════════════════════════════╗
  ║    AO Chat — Actualizador v3.9                            ║
  ╚════════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}"
echo -e "  ${Y}Proyecto:${NC} $PROJECT_DIR"
echo -e "  ${Y}Destino:${NC}  $DEST"
echo -e "  ${Y}BD:${NC}       $DB_NAME"
echo
echo -e "  ${W}Este script:${NC}"
echo -e "   1. Copia los archivos nuevos a $DEST"
echo -e "   2. Corre la migración de base de datos (seguro, idempotente)"
echo -e "   3. Reinicia el servidor con PM2"
echo
echo -ne "  ${Y}  ?  ${NC}¿Continuar? [S/n]: "
read -r r || r=""
r="${r,,}"
[[ -z "$r" || "$r" == "s" || "$r" == "y" || "$r" == "si" || "$r" == "yes" ]] || {
    echo -e "\n  Cancelado."; exit 0; }

# ── 1. Copiar archivos del servidor ──────────────────────────────────────────
step "Copiando archivos del servidor..."
# Preserve .env and uploads — only update code files
rsync -av --exclude='.env' --exclude='uploads/' --exclude='logs/' --exclude='node_modules/' \
    "$PROJECT_DIR/server/" "$DEST/" >> /tmp/ao-update.log 2>&1 \
    && ok "Archivos del servidor actualizados" \
    || { err "Error al copiar archivos del servidor"; exit 1; }

step "Copiando archivos del cliente..."
rsync -av "$PROJECT_DIR/client/public/" "$DEST/public/" >> /tmp/ao-update.log 2>&1 \
    && ok "Archivos del cliente actualizados (CSS/JS/HTML)" \
    || { err "Error al copiar archivos del cliente"; exit 1; }

# ── 2. Migración de base de datos ────────────────────────────────────────────
step "Aplicando migración de base de datos..."
# Aplicar todas las migraciones disponibles (idempotente — seguro re-ejecutar)
for _sql in "$DEST/migrations/"*.sql; do
    [[ -f "$_sql" ]] || continue
    _fname=$(basename "$_sql")
    sudo -u postgres psql -d "$DB_NAME" -f "$_sql" >> /tmp/ao-update.log 2>&1 \
        && ok "Migración $_fname aplicada" \
        || warn "Migración $_fname: ya aplicada o error menor (ver /tmp/ao-update.log)"
done

# ── 3. npm install (por si hay nuevas dependencias) ──────────────────────────
step "Verificando dependencias npm..."
cd "$DEST"
npm install --production --quiet --no-progress \
    --registry https://registry.npmjs.org --strict-ssl false \
    >> /tmp/ao-update.log 2>&1 \
    && ok "Dependencias npm OK" \
    || warn "npm install tuvo advertencias (ver /tmp/ao-update.log)"

# ── 4. Reiniciar PM2 ─────────────────────────────────────────────────────────
step "Reiniciando servidor..."
if pm2 restart ao-chat >> /tmp/ao-update.log 2>&1; then
    sleep 2
    if curl -sf "http://127.0.0.1:${PORT:-8080}/api/health" > /dev/null 2>&1; then
        ok "Servidor reiniciado y respondiendo ✓"
    else
        warn "PM2 reiniciado pero el servidor no responde aún (puede tardar unos segundos)"
        info "Verificá con: pm2 logs ao-chat --lines 20 --nostream"
    fi
else
    warn "pm2 restart falló — intentando pm2 start..."
    pm2 start "$DEST/server.js" --name ao-chat --cwd "$DEST" \
        --max-memory-restart 512M >> /tmp/ao-update.log 2>&1 \
        && ok "Servidor iniciado" || err "No se pudo iniciar el servidor"
fi

pm2 save >> /tmp/ao-update.log 2>&1

# ── Final ────────────────────────────────────────────────────────────────────
clear
echo -e "${G}"
cat << 'EOF'
  ╔════════════════════════════════════════════════════════════╗
  ║     ✓  ACTUALIZACIÓN COMPLETADA — AO Chat v3.9           ║
  ╚════════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}"
IP=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "localhost")
echo -e "  ${C}URL:${NC} http://${IP}:${PORT:-8080}"
echo
echo -e "  ${W}${Y}IMPORTANTE — Hacer en el browser:${NC}"
echo -e "  Presionar ${W}Ctrl+Shift+R${NC} (o Cmd+Shift+R en Mac) para forzar recarga sin caché"
echo -e "  Esto es necesario una vez para que el browser use los nuevos JS/CSS"
echo
echo -e "  ${W}Nuevas funcionalidades:${NC}"
echo -e "   📄 Salas de Documentos — subir y visualizar PDFs"
echo -e "   🌐 Salas Web — sitios embebidos en iframe"
echo -e "   🔗 Link previews — cards de Open Graph en mensajes"
echo
echo -e "  ${C}Log completo:${NC} /tmp/ao-update.log"
line; echo
