#!/usr/bin/env bash
# =============================================================================
#  ARGENTUM ONLINE CHAT SERVER — INSTALADOR v3.9
#  Compatible con: Kali Linux / Debian / Ubuntu
#  Uso: sudo bash installer/install.sh
#
#  TODAS LAS LECCIONES APRENDIDAS APLICADAS:
#   1. Sin set -e: errores manejados manualmente con mensajes claros
#   2. confirm() acepta S/s/y/Enter como sí, n/no como no
#   3. Apache2 detenido ANTES de iniciar servicios
#   4. PostgreSQL: TEMPLATE template0 + LC_COLLATE='C' (evita collation mismatch)
#   5. npm: proxy limpiado completamente antes de cualquier npm
#   6. Script JS admin creado en $DEST (no en /tmp) → node_modules disponibles
#   7. PM2 iniciado con --cwd $DEST → dotenv encuentra .env tras reinicios
#   8. server.js usa path absoluto para dotenv (no depende de CWD)
#   9. appendFileSync en try-catch (no mata el servidor)
#  10. handlers de uncaughtException/unhandledRejection en server.js
#  11. Colores BOLD: visibles en terminal clara y oscura de Kali
#  12. Repositorios con firma inválida (Elastic/PlayOnLinux) ignorados en apt
#  13. Sin Nginx: Node corre directo en puerto 8080 (sin conflictos)
#  14. FACES 32→130 iconos, ROOM_ICONS 90→200, proxy.js eliminado
# =============================================================================
set -uo pipefail

# ── Colores BOLD ─────────────────────────────────────────────────────────────
R='\033[1;31m' G='\033[1;32m' Y='\033[1;33m' B='\033[1;34m'
C='\033[1;36m' M='\033[1;35m' W='\033[1m' NC='\033[0m'

ERRS=0
LOG="/tmp/ao-chat-install.log"

ok()   { echo -e "${G}  ✓  ${NC}$*";                _log "OK    $*"; }
warn() { echo -e "${Y}  ⚠  ${NC}$*";  ERRS=$((ERRS+1)); _log "WARN  $*"; }
err()  { echo -e "${R}  ✗  ${NC}$*";  ERRS=$((ERRS+1)); _log "ERROR $*"; }
info() { echo -e "${C}  ℹ  ${NC}$*";                _log "INFO  $*"; }
step() { echo -e "\n${W}${Y}▶ $*${NC}";             _log "STEP  $*"; }
ask()  { echo -ne "${Y}  ?  ${NC}$*"; }
line() { echo -e "${B}  ──────────────────────────────────────────────${NC}"; }
_log() { echo "$(date '+%H:%M:%S') $*" >> "$LOG"; }

# Spinner visual mientras corre un comando en background
spin() {
    local pid=$1 msg="$2" i=0
    local f=('⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏')
    while kill -0 "$pid" 2>/dev/null; do
        printf "\r  ${C}%s${NC}  %s   " "${f[$((i%10))]}" "$msg"
        i=$((i+1)); sleep 0.1
    done
    printf "\r%60s\r" ""
}

# run CMD MSG [fatal=0|1]
run() {
    local cmd="$1" msg="$2" fatal="${3:-0}"
    eval "$cmd" >> "$LOG" 2>&1 &
    local pid=$!
    spin "$pid" "$msg"
    if wait "$pid"; then
        ok "$msg"
    elif [[ "$fatal" == "1" ]]; then
        err "Crítico: $msg"
        echo -e "\n  ${Y}Últimas líneas del log ($LOG):${NC}"
        tail -8 "$LOG" | sed 's/^/    /'
        exit 1
    else
        warn "Advertencia en: $msg"
    fi
}

# confirm PREGUNTA → 0=sí, 1=no
confirm() {
    local r
    ask "$1 [S/n]: "; read -r r || r=""
    r="${r,,}"
    [[ -z "$r" || "$r" == "s" || "$r" == "si" || "$r" == "y" || "$r" == "yes" ]]
}

# Obtener directorio real del script (funciona con sudo, rutas relativas, etc.)
_script_dir() {
    local p
    p="$(readlink /proc/$$/fd/255 2>/dev/null)"
    [[ -z "$p" || ! -f "$p" ]] && p="${BASH_SOURCE[0]}"
    [[ "$p" != /* ]] && p="$(pwd -P)/$p"
    dirname "$(readlink -f "$p")"
}

SCRIPT_DIR="$(_script_dir)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
DEST="/opt/ao-chat"
DB_NAME="ao_chat"
DB_USER="ao_admin"
DB_PASS="" JWT_SECRET="" ENC_KEY=""
ADMIN_USER="" ADMIN_PASS="" ADMIN_EMAIL=""
APP_PORT="8080"

# ── Verificaciones previas ────────────────────────────────────────────────────
require_root() {
    [[ $EUID -eq 0 ]] && return
    echo -e "\n${R}  Ejecutar como root:${NC} sudo bash installer/install.sh\n"; exit 1
}

check_project() {
    [[ -f "$PROJECT_DIR/server/server.js" ]] && return
    echo -e "\n${R}  Archivos no encontrados en: $PROJECT_DIR${NC}"
    echo -e "  ${C}  cd ao-chat-final && sudo bash installer/install.sh${NC}\n"
    exit 1
}

gen_secret() { openssl rand -base64 64 | tr -d '\n/+=' | head -c 64; }

# ─────────────────────────────────────────────────────────────────────────────
#  BIENVENIDA
# ─────────────────────────────────────────────────────────────────────────────
welcome() {
    clear
    echo -e "${M}"
    cat << 'EOF'
  ╔════════════════════════════════════════════════════════════╗
  ║                                                            ║
  ║   ██████╗  ██████╗     ██████╗██╗  ██╗ █████╗ ████████╗  ║
  ║  ██╔══██╗██╔═══██╗    ██╔════╝██║  ██║██╔══██╗╚══██╔══╝  ║
  ║  ███████║██║   ██║    ██║     ███████║███████║   ██║      ║
  ║  ██╔══██║██║   ██║    ██║     ██╔══██║██╔══██║   ██║      ║
  ║  ██║  ██║╚██████╔╝    ╚██████╗██║  ██║██║  ██║   ██║      ║
  ║  ╚═╝  ╚═╝ ╚═════╝      ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝      ║
  ║                                                            ║
  ║          ONLINE CHAT SERVER  ·  Instalador v3.3            ║
  ╚════════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"
    echo -e "  ${W}Puerto 8080 directo · PostgreSQL · Redis · PM2 · DDNS${NC}"
    echo
    echo -e "  ${Y}Sistema:${NC}  $(lsb_release -d 2>/dev/null | cut -f2 || uname -sr)"
    echo -e "  ${Y}Arch:${NC}     $(uname -m)"
    echo -e "  ${Y}Proyecto:${NC} $PROJECT_DIR"
    echo -e "  ${Y}Destino:${NC}  $DEST"
    echo -e "  ${Y}Log:${NC}      $LOG"
    echo; line; echo
    confirm "¿Continuar con la instalación?" || { echo -e "\n  Cancelado.\n"; exit 0; }
}

# ─────────────────────────────────────────────────────────────────────────────
#  PASO 1 — CONFIGURACIÓN
# ─────────────────────────────────────────────────────────────────────────────
config() {
    clear
    echo -e "${W}${B}╔══════════════════════════════════════════╗${NC}"
    echo -e "${W}${B}║  PASO 1/6 — Configuración               ║${NC}"
    echo -e "${W}${B}╚══════════════════════════════════════════╝${NC}"; echo

    info "Puerto de la aplicación (default: 8080):"
    ask "  Puerto [8080]: "; read -r p || p=""
    if [[ -n "$p" && "$p" =~ ^[0-9]+$ && "$p" -ge 1024 && "$p" -le 65535 ]]; then
        APP_PORT="$p"
    fi
    ok "Puerto: $APP_PORT"; echo

    info "Datos del Administrador principal:"
    while true; do
        ask "  Nombre de usuario (mín 3, solo letras/números/_): "
        read -r ADMIN_USER || ADMIN_USER=""
        [[ ${#ADMIN_USER} -ge 3 && "$ADMIN_USER" =~ ^[a-zA-Z0-9_]+$ ]] && break
        err "Mínimo 3 caracteres, solo letras, números y guión bajo"
    done
    while true; do
        ask "  Email: "; read -r ADMIN_EMAIL || ADMIN_EMAIL=""
        [[ "$ADMIN_EMAIL" =~ ^[^@]+@[^@]+\.[^@]+$ ]] && break
        err "Email inválido (ejemplo: admin@midominio.com)"
    done
    while true; do
        ask "  Contraseña (mín 12 caracteres): "
        read -rs ADMIN_PASS || ADMIN_PASS=""; echo
        [[ ${#ADMIN_PASS} -ge 12 ]] && break
        err "Mínimo 12 caracteres"
    done
    echo

    info "Contraseña para PostgreSQL:"
    ask "  Contraseña DB [Enter = auto-generar]: "
    read -rs DB_PASS || DB_PASS=""; echo
    if [[ -z "$DB_PASS" ]]; then
        DB_PASS=$(gen_secret | head -c 28)
        ok "Contraseña DB generada automáticamente"
    fi

    # Generar secretos criptográficos
    JWT_SECRET=$(gen_secret)
    ENC_KEY=$(gen_secret)

    echo; line
    echo -e "\n${W}${G}  Resumen:${NC}"
    echo -e "  ${Y}Admin:${NC}  $ADMIN_USER  <$ADMIN_EMAIL>"
    echo -e "  ${Y}Puerto:${NC} $APP_PORT"
    echo -e "  ${Y}Destino:${NC} $DEST"
    echo
    confirm "¿Confirmar y continuar?" || { config; return; }
}

# ─────────────────────────────────────────────────────────────────────────────
#  PASO 2 — DEPENDENCIAS
# ─────────────────────────────────────────────────────────────────────────────
deps() {
    clear
    echo -e "${W}${B}╔══════════════════════════════════════════╗${NC}"
    echo -e "${W}${B}║  PASO 2/6 — Dependencias del sistema    ║${NC}"
    echo -e "${W}${B}╚══════════════════════════════════════════╝${NC}"; echo

    # Limpiar proxy npm ANTES de cualquier operación npm
    step "Limpiando proxy npm..."
    local np nh
    np=$(npm config get proxy       2>/dev/null || echo "null")
    nh=$(npm config get https-proxy 2>/dev/null || echo "null")
    if [[ "$np" != "null" && -n "$np" && "$np" != "undefined" ]]; then
        npm config delete proxy        2>/dev/null || true
        npm config delete https-proxy  2>/dev/null || true
        warn "Proxy npm eliminado: $np (normal en Kali con Burp/ZAP/proxychains)"
    else
        ok "Sin proxy npm configurado"
    fi
    # Limpiar también variables de entorno de proxy
    unset http_proxy https_proxy HTTP_PROXY HTTPS_PROXY no_proxy 2>/dev/null || true

    step "Actualizando repositorios..."
    # Ignorar errores de repos con firma inválida (Elastic, PlayOnLinux, etc.)
    run "apt-get update -qq 2>&1 | grep -v '^W:' | grep -v 'no está firmado' || true" \
        "Actualizando lista de paquetes"

    step "Herramientas base..."
    run "DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
        curl wget gnupg2 ca-certificates lsb-release build-essential \
        git openssl ufw fail2ban net-tools 2>&1" \
        "curl, git, openssl, ufw, fail2ban" 1

    step "Node.js..."
    local node_ok=0
    if command -v node &>/dev/null; then
        local v; v=$(node -v 2>/dev/null | cut -d. -f1 | tr -d v || echo 0)
        [[ "$v" -ge 20 ]] && node_ok=1 && ok "Node.js ya instalado: $(node -v)"
    fi
    if [[ $node_ok -eq 0 ]]; then
        run "curl -fsSL https://deb.nodesource.com/setup_20.x | bash -" \
            "Configurando repositorio Node.js 20" 1
        run "DEBIAN_FRONTEND=noninteractive apt-get install -y -qq nodejs" \
            "Instalando Node.js 20" 1
    fi

    step "PostgreSQL..."
    if ! command -v psql &>/dev/null; then
        run "DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
             postgresql postgresql-contrib" \
            "Instalando PostgreSQL" 1
    else
        ok "PostgreSQL ya instalado: $(psql --version 2>/dev/null | head -1)"
    fi
    # Iniciar PostgreSQL (compatible con Kali que no usa systemd por defecto)
    run "systemctl start postgresql 2>/dev/null || \
         pg_ctlcluster \$(pg_lsclusters -h 2>/dev/null | awk '{print \$1}' | tail -1) main start 2>/dev/null || true" \
        "Iniciando PostgreSQL"
    run "systemctl enable postgresql 2>/dev/null || true" \
        "Habilitando PostgreSQL al arranque"

    step "Redis..."
    if ! command -v redis-server &>/dev/null; then
        run "DEBIAN_FRONTEND=noninteractive apt-get install -y -qq redis-server" \
            "Instalando Redis" 1
    else
        ok "Redis ya instalado"
    fi
    run "systemctl start  redis-server 2>/dev/null || true" "Iniciando Redis"
    run "systemctl enable redis-server 2>/dev/null || true" "Habilitando Redis al arranque"

    # Parar Apache2 si está corriendo (ocupa puertos 80/443)
    step "Verificando conflictos de puertos..."
    if systemctl is-active apache2 &>/dev/null 2>&1 || pgrep -x apache2 &>/dev/null 2>&1; then
        warn "Apache2 detectado corriendo — deteniéndolo"
        run "systemctl stop apache2 2>/dev/null; systemctl disable apache2 2>/dev/null || true" \
            "Deteniendo Apache2"
    else
        ok "Sin conflictos de puertos"
    fi

    step "PM2 (gestor de procesos Node.js)..."
    _install_pm2
    run "pm2 startup systemd -u root --hp /root > /dev/null 2>&1 || true" \
        "Configurando PM2 para arranque automático del sistema"

    ok "✓ Todas las dependencias listas"
}

_install_pm2() {
    if command -v pm2 &>/dev/null; then
        ok "PM2 ya instalado: v$(pm2 -v 2>/dev/null)"; return 0
    fi
    info "Instalando PM2..."
    # Intento 1: npm normal sin proxy
    if env -u http_proxy -u https_proxy -u HTTP_PROXY -u HTTPS_PROXY \
       npm install -g pm2 --quiet --no-progress \
       --registry https://registry.npmjs.org --strict-ssl false \
       >> "$LOG" 2>&1; then
        ok "PM2 instalado"; return 0
    fi
    # Intento 2: curl + tarball directo
    warn "npm falló — descargando tarball de PM2 directamente..."
    local tmp; tmp=$(mktemp -d /tmp/pm2-XXXXXX)
    if curl -fsSL --retry 3 --max-time 60 \
       "https://registry.npmjs.org/pm2/-/pm2-5.3.1.tgz" \
       -o "$tmp/pm2.tgz" >> "$LOG" 2>&1 && \
       npm install -g "$tmp/pm2.tgz" --quiet --no-progress >> "$LOG" 2>&1; then
        ok "PM2 instalado desde tarball"; rm -rf "$tmp"; return 0
    fi
    rm -rf "$tmp" 2>/dev/null || true
    err "No se pudo instalar PM2 automáticamente"
    echo -e "\n  ${Y}Instalalo manualmente y volvé a ejecutar el instalador:${NC}"
    echo -e "  ${C}  npm config delete proxy && npm install -g pm2${NC}\n"
    exit 1
}

# ─────────────────────────────────────────────────────────────────────────────
#  PASO 3 — BASE DE DATOS
# ─────────────────────────────────────────────────────────────────────────────
database() {
    clear
    echo -e "${W}${B}╔══════════════════════════════════════════╗${NC}"
    echo -e "${W}${B}║  PASO 3/6 — Base de datos               ║${NC}"
    echo -e "${W}${B}╚══════════════════════════════════════════╝${NC}"; echo

    # Actualizar versión de collation para evitar el error con PostgreSQL 18 + glibc 2.42
    step "Actualizando collation version de PostgreSQL..."
    sudo -u postgres psql \
        -c "ALTER DATABASE template1 REFRESH COLLATION VERSION;" \
        >> "$LOG" 2>&1 && ok "template1 collation OK" || true
    sudo -u postgres psql \
        -c "ALTER DATABASE postgres  REFRESH COLLATION VERSION;" \
        >> "$LOG" 2>&1 && ok "postgres collation OK"  || true

    step "Creando usuario y base de datos..."
    sudo -u postgres psql >> "$LOG" 2>&1 << PSQL
DO \$\$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname='${DB_USER}') THEN
    CREATE ROLE ${DB_USER} LOGIN PASSWORD '${DB_PASS}';
  ELSE
    ALTER ROLE ${DB_USER} WITH PASSWORD '${DB_PASS}';
  END IF;
END
\$\$;

DROP DATABASE IF EXISTS ${DB_NAME};

-- CLAVE: template0 + LC_COLLATE='C' evita el error de collation mismatch
-- entre PostgreSQL 18 y glibc 2.42 en Kali
CREATE DATABASE ${DB_NAME}
    OWNER     ${DB_USER}
    ENCODING  'UTF8'
    LC_COLLATE 'C'
    LC_CTYPE   'C'
    TEMPLATE  template0;

GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};
PSQL

    # Verificar que la BD fue creada
    if ! sudo -u postgres psql -lqt 2>/dev/null | grep -q "^[[:space:]]*${DB_NAME}"; then
        err "No se pudo crear la base de datos '${DB_NAME}'"
        echo -e "  ${Y}Revisá el log: tail -30 $LOG${NC}"
        exit 1
    fi
    ok "Base de datos '${DB_NAME}' creada (template0, LC_COLLATE=C)"

    step "Creando esquema de tablas..."
    sudo -u postgres psql -d "${DB_NAME}" >> "$LOG" 2>&1 << 'PSQL'
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ── Usuarios ──────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username      VARCHAR(32)  UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    status        VARCHAR(16)  NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','active','suspended','banned')),
    role          VARCHAR(16)  NOT NULL DEFAULT 'user'
                  CHECK (role IN ('user','moderator','admin')),
    -- Moderación
    ban_reason    TEXT,
    banned_until  TIMESTAMPTZ,
    muted_until   TIMESTAMPTZ,
    mute_reason   TEXT,
    warn_count    SMALLINT     NOT NULL DEFAULT 0,
    -- Gamificación
    xp            INTEGER      NOT NULL DEFAULT 0,
    level         SMALLINT     NOT NULL DEFAULT 1,
    custom_title  VARCHAR(64),
    -- Preferencias
    theme         VARCHAR(32)  DEFAULT 'dark-gold',
    user_status   VARCHAR(16)  DEFAULT 'online'
                  CHECK (user_status IN ('online','busy','afk','invisible')),
    status_text   VARCHAR(64),
    -- Timestamps
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    approved_at   TIMESTAMPTZ,
    approved_by   UUID,
    last_login    TIMESTAMPTZ,
    last_seen     TIMESTAMPTZ
);

-- ── Personajes ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS characters (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    race        VARCHAR(32) NOT NULL,
    gender      VARCHAR(16) NOT NULL,
    class       VARCHAR(32) NOT NULL,
    profession  VARCHAR(32) NOT NULL,
    face_id     SMALLINT    NOT NULL DEFAULT 1,
    description TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Salas ─────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS rooms (
    id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name              VARCHAR(64) UNIQUE NOT NULL,
    slug              VARCHAR(64) UNIQUE NOT NULL,
    description       TEXT,
    type              VARCHAR(16) NOT NULL DEFAULT 'public'
                      CHECK (type IN ('public','private','admin')),
    -- Tipo de sala: chat=normal, docs=biblioteca PDF, web=sitio embebido
    kind              VARCHAR(16) NOT NULL DEFAULT 'chat'
                      CHECK (kind IN ('chat','docs','web')),
    topic             TEXT,
    icon              VARCHAR(16) DEFAULT '💬',
    image_url         TEXT,
    -- Para salas web: URL a embeber en iframe
    embed_url         TEXT,
    -- Para salas docs: quién puede subir ('all' = cualquier miembro, 'staff' = admin/mod)
    upload_permission VARCHAR(16) NOT NULL DEFAULT 'all'
                      CHECK (upload_permission IN ('all','staff')),
    max_users         INTEGER     DEFAULT 100,
    is_active         BOOLEAN     NOT NULL DEFAULT TRUE,
    admin_only        BOOLEAN     NOT NULL DEFAULT FALSE,
    slow_mode_sec     SMALLINT    NOT NULL DEFAULT 0,
    created_by        UUID,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Miembros de sala ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS room_members (
    room_id    UUID REFERENCES rooms(id)  ON DELETE CASCADE,
    user_id    UUID REFERENCES users(id)  ON DELETE CASCADE,
    role       VARCHAR(16) DEFAULT 'member' CHECK (role IN ('member','moderator','owner')),
    joined_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (room_id, user_id)
);

-- ── Mensajes ──────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS messages (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_id     UUID NOT NULL REFERENCES rooms(id)    ON DELETE CASCADE,
    user_id     UUID NOT NULL REFERENCES users(id)    ON DELETE CASCADE,
    content     TEXT NOT NULL,
    type        VARCHAR(16) DEFAULT 'text'
                CHECK (type IN ('text','file','system','emote','poll','dice','me')),
    file_id     UUID,
    reply_to_id UUID REFERENCES messages(id) ON DELETE SET NULL,
    edited_at   TIMESTAMPTZ,
    deleted_at  TIMESTAMPTZ,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_msg_room    ON messages(room_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_msg_reply   ON messages(reply_to_id);
CREATE INDEX IF NOT EXISTS idx_msg_content ON messages USING gin(to_tsvector('spanish', content));

-- ── Archivos ──────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS files (
    id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    uploaded_by    UUID NOT NULL REFERENCES users(id),
    room_id        UUID REFERENCES rooms(id),
    original_name  VARCHAR(255) NOT NULL,
    stored_name    VARCHAR(255) NOT NULL,
    mime_type      VARCHAR(128),
    size_bytes     BIGINT,
    is_encrypted   BOOLEAN NOT NULL DEFAULT TRUE,
    download_count INTEGER DEFAULT 0,
    deleted_at     TIMESTAMPTZ,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_files_room ON files(room_id, created_at DESC) WHERE deleted_at IS NULL;

-- ── Reacciones ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS message_reactions (
    message_id UUID NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
    user_id    UUID NOT NULL REFERENCES users(id)    ON DELETE CASCADE,
    type       VARCHAR(8) NOT NULL CHECK (type IN ('like','dislike')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (message_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_react_msg ON message_reactions(message_id);

-- ── Encuestas ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS polls (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    message_id  UUID UNIQUE NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
    question    TEXT NOT NULL,
    created_by  UUID REFERENCES users(id),
    ends_at     TIMESTAMPTZ,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS poll_options (
    id      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    poll_id UUID NOT NULL REFERENCES polls(id) ON DELETE CASCADE,
    text    VARCHAR(200) NOT NULL,
    votes   INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS poll_votes (
    poll_id    UUID NOT NULL REFERENCES polls(id)         ON DELETE CASCADE,
    option_id  UUID NOT NULL REFERENCES poll_options(id)  ON DELETE CASCADE,
    user_id    UUID NOT NULL REFERENCES users(id)         ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (poll_id, user_id)
);

-- ── Mensajes privados (DM) ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS direct_messages (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sender_id   UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    receiver_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    content     TEXT NOT NULL,
    type        VARCHAR(16) DEFAULT 'text' CHECK (type IN ('text','file')),
    file_id     UUID,
    read_at     TIMESTAMPTZ,
    deleted_at  TIMESTAMPTZ,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_dm_pair ON direct_messages(
    LEAST(sender_id::text, receiver_id::text),
    GREATEST(sender_id::text, receiver_id::text),
    created_at DESC
);
CREATE INDEX IF NOT EXISTS idx_dm_receiver ON direct_messages(receiver_id, read_at);

-- ── Advertencias ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS warnings (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    issued_by   UUID NOT NULL REFERENCES users(id),
    reason      TEXT NOT NULL,
    message_id  UUID REFERENCES messages(id) ON DELETE SET NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_warn_user ON warnings(user_id, created_at DESC);

-- ── Logros ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS achievements (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    key         VARCHAR(64) UNIQUE NOT NULL,
    name        VARCHAR(64) NOT NULL,
    description TEXT,
    icon        VARCHAR(8),
    xp_reward   INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS user_achievements (
    user_id        UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    achievement_id UUID NOT NULL REFERENCES achievements(id) ON DELETE CASCADE,
    earned_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (user_id, achievement_id)
);

-- ── Palabras prohibidas ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS banned_words (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    word        VARCHAR(128) UNIQUE NOT NULL,
    action      VARCHAR(16) DEFAULT 'censor' CHECK (action IN ('censor','block','warn')),
    added_by    UUID REFERENCES users(id),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Títulos personalizados ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS custom_titles (
    id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name       VARCHAR(64) UNIQUE NOT NULL,
    color      VARCHAR(16) DEFAULT '#c9a84c',
    min_level  SMALLINT DEFAULT 1,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Logs de auditoría ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_logs (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID REFERENCES users(id),
    action      VARCHAR(64) NOT NULL,
    target_type VARCHAR(32),
    target_id   UUID,
    ip_address  INET,
    user_agent  TEXT,
    geo_country VARCHAR(64),
    geo_city    VARCHAR(64),
    geo_lat     DECIMAL(9,6),
    geo_lon     DECIMAL(9,6),
    metadata    JSONB,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_logs(user_id,    created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_ip   ON audit_logs(ip_address, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_act  ON audit_logs(action,     created_at DESC);

-- ── Conexiones activas ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS active_connections (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    socket_id    VARCHAR(64) UNIQUE NOT NULL,
    ip_address   INET,
    user_agent   TEXT,
    geo_country  VARCHAR(64),
    geo_city     VARCHAR(64),
    room_id      UUID REFERENCES rooms(id),
    connected_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Bans de IP ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ip_bans (
    id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ip_address INET NOT NULL,
    cidr_block CIDR,
    reason     TEXT,
    banned_by  UUID REFERENCES users(id),
    expires_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Configuración ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS settings (
    key        VARCHAR(64) PRIMARY KEY,
    value      TEXT,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── Índices adicionales ───────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);
CREATE INDEX IF NOT EXISTS idx_users_xp     ON users(xp DESC);

-- ── Datos iniciales ───────────────────────────────────────────────────────────
INSERT INTO settings (key, value) VALUES
    ('server_name',          'Argentum Online Chat'),
    ('server_domain',        ''),
    ('server_port',          '8080'),
    ('cloudflare_zone_id',   ''),
    ('cloudflare_api_token', ''),
    ('cloudflare_record_id', ''),
    ('cloudflare_subdomain', ''),
    ('ddns_enabled',         'false'),
    ('ddns_interval_min',    '5'),
    ('bg_image_url',         ''),
    ('chat_bg_image_url',    ''),
    ('chat_bg_opacity',      '0.72'),
    ('announcement',         ''),
    ('announcement_updated', ''),
    ('login_side',           'left'),
    ('login_gap',            '3rem'),
    ('max_file_mb',          '50'),
    ('registration_open',    'true'),
    ('auto_ban_warnings',    '3'),
    ('xp_per_message',       '2'),
    ('xp_per_file',          '5'),
    ('xp_per_poll',          '10'),
    ('xp_per_vote',          '3'),
    ('flood_limit',          '5'),
    ('perm_user_polls',      'true'),
    ('perm_user_files',      'true'),
    ('perm_user_dm',         'true'),
    ('perm_user_reactions',  'true'),
    ('perm_user_dice',       'true'),
    ('perm_mod_delete_msg',  'true'),
    ('perm_mod_mute',        'true'),
    ('perm_mod_warn',        'true'),
    ('perm_mod_view_audit',  'true'),
    ('perm_mod_view_conns',  'true'),
    ('perm_mod_kick',        'true')
ON CONFLICT (key) DO NOTHING;

INSERT INTO rooms (name, slug, description, type, kind, icon) VALUES
    ('Metrópolis',        'metropolis',        'La ciudad capital de Argentum',          'public', 'chat', '🏛️'),
    ('Taverna',           'taverna',           'El lugar de encuentro de aventureros',   'public', 'chat', '🍺'),
    ('Nix',               'nix',               'La ciudad de las sombras',               'public', 'chat', '🌑'),
    ('Banderbill',        'banderbill',         'Ciudad portuaria del norte',             'public', 'chat', '⚓'),
    ('Biblioteca',        'biblioteca',         'Documentos y recursos del reino',        'public', 'docs', '📄'),
    ('Admin Lounge',      'admin-lounge',       'Canal exclusivo de administradores',     'admin',  'chat', '🛡️')
ON CONFLICT DO NOTHING;

INSERT INTO achievements (key, name, description, icon, xp_reward) VALUES
    ('first_message',    'Primera Palabra',       'Enviaste tu primer mensaje',            '💬', 10),
    ('messages_10',      'Conversador',            '10 mensajes enviados',                  '🗣️',  20),
    ('messages_100',     'Orador del Gremio',      '100 mensajes enviados',                 '📜', 50),
    ('messages_500',     'Cronista del Reino',     '500 mensajes enviados',                 '📚', 100),
    ('first_poll',       'Democracia',             'Creaste tu primera encuesta',           '📊', 15),
    ('first_vote',       'Ciudadano Activo',       'Votaste en una encuesta',               '✅', 5),
    ('first_like',       'Aprobado',               'Le diste like a un mensaje',            '👍', 5),
    ('first_file',       'Archivista',             'Compartiste un archivo',                '📁', 10),
    ('level_5',          'Aventurero',             'Alcanzaste el nivel 5',                 '⭐', 30),
    ('level_10',         'Veterano',               'Alcanzaste el nivel 10',                '🌟', 60),
    ('level_20',         'Maestro del Gremio',     'Alcanzaste el nivel 20',                '🏆', 120),
    ('dice_roll',        'El Destino Llama',       'Tiraste los dados por primera vez',     '🎲', 5),
    ('first_dm',         'Mensajero',              'Enviaste tu primer mensaje privado',    '✉️', 10)
ON CONFLICT (key) DO NOTHING;

INSERT INTO custom_titles (name, color, min_level) VALUES
    ('Novato del Reino',   '#7a8098', 1),
    ('Aventurero',         '#27ae60', 5),
    ('Veterano',           '#2980b9', 10),
    ('Maestro',            '#c9a84c', 15),
    ('Leyenda',            '#e74c3c', 20),
    ('Dios del Caos',      '#9b59b6', 30)
ON CONFLICT DO NOTHING;

GRANT ALL PRIVILEGES ON ALL TABLES    IN SCHEMA public TO ao_admin;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO ao_admin;

PSQL
    # Run migration for existing installations (safe: uses IF NOT EXISTS / DO NOTHING)
    for migration in "$PROJECT_DIR/server/migrations/"*.sql; do
        [[ -f "$migration" ]] || continue
        fname=$(basename "$migration")
        sudo -u postgres psql -d "${DB_NAME}" -f "$migration" >> "$LOG" 2>&1             && ok "Migración $fname aplicada" || warn "Migración $fname: ya aplicada o error menor"
    done
    if [[ -f "$PROJECT_DIR/server/migrations/005_extras.sql" ]]; then
        sudo -u postgres psql -d "${DB_NAME}" -f "$PROJECT_DIR/server/migrations/005_extras.sql"             >> "$LOG" 2>&1 && ok "Migración 005 aplicada (favoritos, msgs. programados, backups)" || warn "Migración 005 ya estaba aplicada"
    fi
    ok "18 tablas, índices, logros, settings y salas creados (v3.3)"
}

# ─────────────────────────────────────────────────────────────────────────────
#  PASO 4 — APLICACIÓN
# ─────────────────────────────────────────────────────────────────────────────
app() {
    clear
    echo -e "${W}${B}╔══════════════════════════════════════════╗${NC}"
    echo -e "${W}${B}║  PASO 4/6 — Instalando la aplicación    ║${NC}"
    echo -e "${W}${B}╚══════════════════════════════════════════╝${NC}"; echo

    step "Copiando archivos al destino ($DEST)..."
    mkdir -p "$DEST"
    cp -r "$PROJECT_DIR/server/"*     "$DEST/"
    mkdir -p "$DEST/public"
    cp -r "$PROJECT_DIR/client/public/"* "$DEST/public/"
    mkdir -p "$DEST/logs" "$DEST/uploads"
    chmod 750 "$DEST/uploads"
    ok "Archivos copiados a $DEST"

    step "Generando .env..."
    cat > "$DEST/.env" << ENV
# AO Chat Server — Configuración  ($(date))
# IMPORTANTE: este archivo contiene secretos — chmod 600, solo root
NODE_ENV=production
PORT=${APP_PORT}

# Base de datos PostgreSQL
DB_HOST=localhost
DB_PORT=5432
DB_NAME=${DB_NAME}
DB_USER=${DB_USER}
DB_PASS=${DB_PASS}

# Seguridad JWT y cifrado de archivos
JWT_SECRET=${JWT_SECRET}
JWT_EXPIRES=24h
ENCRYPTION_KEY=${ENC_KEY}

# Redis
REDIS_URL=redis://localhost:6379

# Rutas absolutas (crítico para PM2 con systemd)
UPLOAD_DIR=${DEST}/uploads
LOGS_DIR=${DEST}/logs
MAX_FILE_MB=50
ENV
    chmod 600 "$DEST/.env"
    ok ".env generado y asegurado (chmod 600)"

    step "Instalando dependencias npm..."
    cd "$DEST"
    # Siempre limpiar proxy y usar --strict-ssl false
    if ! env -u http_proxy -u https_proxy -u HTTP_PROXY -u HTTPS_PROXY \
        npm install --production --quiet --no-progress \
        --registry https://registry.npmjs.org \
        --strict-ssl false \
        >> "$LOG" 2>&1; then
        err "npm install falló"
        echo -e "  ${Y}Intentá manualmente: cd $DEST && npm install --production${NC}"
        exit 1
    fi
    ok "Dependencias npm instaladas"

    step "Creando usuario administrador en la base de datos..."
    # CRÍTICO: crear el script JS en $DEST (no en /tmp)
    # Node resuelve require() desde la ubicación del archivo
    # Si está en /tmp no encuentra node_modules de /opt/ao-chat
    local ADMIN_JS="$DEST/setup-admin-$$.js"

    cat > "$ADMIN_JS" << JSEOF
const bcrypt = require('bcryptjs');
const { Pool } = require('pg');
const pool = new Pool({
    host:     'localhost',
    database: '${DB_NAME}',
    user:     '${DB_USER}',
    password: '${DB_PASS}',
    connectionTimeoutMillis: 10000,
});
(async () => {
    const hash = await bcrypt.hash('${ADMIN_PASS}', 12);
    const { rows } = await pool.query(
        "INSERT INTO users (username, password_hash, status, role)" +
        " VALUES (\$1, \$2, 'active', 'admin')" +
        " ON CONFLICT (username) DO UPDATE" +
        " SET password_hash=\$2, role='admin', status='active'" +
        " RETURNING id, username",
        ['${ADMIN_USER}', hash]
    );
    await pool.query(
        "INSERT INTO characters (user_id, race, gender, class, profession, face_id)" +
        " VALUES (\$1, 'Humano', 'Masculino', 'Guerrero', 'Herrero', 1)" +
        " ON CONFLICT (user_id) DO NOTHING",
        [rows[0].id]
    );
    await pool.end();
    console.log('Admin ' + rows[0].username + ' creado OK');
    process.exit(0);
})().catch(e => {
    console.error('ERROR: ' + e.message);
    process.exit(1);
});
JSEOF

    # Ejecutar desde $DEST para que node encuentre node_modules
    if (cd "$DEST" && node "$ADMIN_JS"); then
        ok "Admin '${ADMIN_USER}' creado exitosamente"
    else
        warn "No se pudo crear el admin — revisá: tail -20 $LOG"
    fi
    rm -f "$ADMIN_JS"
}

# ─────────────────────────────────────────────────────────────────────────────
#  PASO 5 — FIREWALL
# ─────────────────────────────────────────────────────────────────────────────
firewall() {
    clear
    echo -e "${W}${B}╔══════════════════════════════════════════╗${NC}"
    echo -e "${W}${B}║  PASO 5/6 — Firewall y seguridad        ║${NC}"
    echo -e "${W}${B}╚══════════════════════════════════════════╝${NC}"; echo

    step "Configurando UFW..."
    ufw --force reset           >> "$LOG" 2>&1 || true
    ufw default deny incoming   >> "$LOG" 2>&1
    ufw default allow outgoing  >> "$LOG" 2>&1
    ufw allow 22/tcp            >> "$LOG" 2>&1
    ufw allow "${APP_PORT}/tcp" >> "$LOG" 2>&1
    ufw --force enable          >> "$LOG" 2>&1
    ok "UFW activo — puertos: SSH (22) y AO Chat ($APP_PORT)"

    step "Configurando Fail2Ban..."
    cat > /etc/fail2ban/filter.d/ao-chat.conf << 'F2B'
[Definition]
failregex = .*"POST /api/auth/login.*" (401|429).*<HOST>
ignoreregex =
F2B
    cat > /etc/fail2ban/jail.d/ao-chat.conf << F2B
[ao-chat]
enabled  = true
port     = ${APP_PORT}
filter   = ao-chat
logpath  = ${DEST}/logs/access.log
maxretry = 5
findtime = 300
bantime  = 3600
F2B
    run "systemctl restart fail2ban 2>/dev/null || true" \
        "Fail2Ban (bloqueo tras 5 intentos fallidos en 5 min)"
}

# ─────────────────────────────────────────────────────────────────────────────
#  PASO 6 — INICIAR SERVIDOR
# ─────────────────────────────────────────────────────────────────────────────
start() {
    clear
    echo -e "${W}${B}╔══════════════════════════════════════════╗${NC}"
    echo -e "${W}${B}║  PASO 6/6 — Iniciando el servidor       ║${NC}"
    echo -e "${W}${B}╚══════════════════════════════════════════╝${NC}"; echo

    # Limpiar conexiones activas de instalaciones previas
    sudo -u postgres psql -d "${DB_NAME}" \
        -c "TRUNCATE TABLE active_connections;" \
        >> "$LOG" 2>&1 || true

    step "Iniciando AO Chat con PM2..."
    cd "$DEST"
    pm2 delete ao-chat >> "$LOG" 2>&1 || true
    sleep 1

    # CRÍTICO: --cwd $DEST garantiza que dotenv encuentre .env
    # incluso cuando PM2 arranca via systemd (donde CWD sería /)
    if ! pm2 start server.js \
            --name    ao-chat \
            --cwd     "$DEST" \
            --max-memory-restart 512M \
            --log     "$DEST/logs/pm2.log" \
            --error   "$DEST/logs/pm2-error.log" \
            --time \
            >> "$LOG" 2>&1; then
        err "PM2 no pudo iniciar el servidor"
        echo -e "  ${Y}Ver log: pm2 logs ao-chat --lines 30 --nostream${NC}"
        exit 1
    fi
    ok "Proceso ao-chat iniciado con PM2"

    run "pm2 save" "Guardando configuración PM2 para persistencia"

    info "Esperando que el servidor responda en el puerto $APP_PORT..."
    local tries=0
    while ! curl -sf "http://127.0.0.1:${APP_PORT}/api/health" > /dev/null 2>&1; do
        sleep 1; tries=$((tries+1))
        printf "\r  ${C}⠹${NC}  Esperando... ${tries}s"
        [[ $tries -ge 30 ]] && break
    done
    printf "\r%45s\r" ""

    if curl -sf "http://127.0.0.1:${APP_PORT}/api/health" > /dev/null 2>&1; then
        ok "Servidor respondiendo en el puerto $APP_PORT ✓"
    else
        warn "El servidor no respondió en 30 segundos"
        info "Revisá con: pm2 logs ao-chat --lines 40 --nostream"
    fi
}

# ─────────────────────────────────────────────────────────────────────────────
#  PANTALLA FINAL
# ─────────────────────────────────────────────────────────────────────────────
final() {
    clear
    [[ $ERRS -eq 0 ]] && echo -e "${G}" || echo -e "${Y}"
    cat << 'EOF'
  ╔════════════════════════════════════════════════════════════╗
  ║                                                            ║
  ║        ✦  INSTALACIÓN COMPLETADA EXITOSAMENTE  ✦          ║
  ║           AO Chat v3.9 — Proxy mejorado                   ║
  ║                                                            ║
  ╚════════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"
    local ip; ip=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "localhost")

    echo -e "${W}${B}── Acceso ───────────────────────────────────────────${NC}"
    echo -e "  ${C}Chat:${NC}         http://${ip}:${APP_PORT}"
    echo -e "  ${C}Panel Admin:${NC}  http://${ip}:${APP_PORT}/admin/"
    echo
    echo -e "${W}${B}── Credenciales del administrador ───────────────────${NC}"
    echo -e "  ${Y}Usuario:${NC}   ${ADMIN_USER}"
    echo -e "  ${Y}Email:${NC}     ${ADMIN_EMAIL}"
    echo -e "  ${R}Secretos en:${NC} ${DEST}/.env  (protegido, solo root)"
    echo
    echo -e "${W}${B}── DDNS / Cloudflare ────────────────────────────────${NC}"
    echo -e "  Configuralo en ${C}Panel Admin → ⚙ Configuración${NC}"
    echo
    echo -e "${W}${B}── Imagen de fondo AO ───────────────────────────────${NC}"
    echo -e "  Panel Admin → Configuración → ${C}Imagen de fondo (URL)${NC}"
    echo -e "  Subí la imagen a imgur.com y pegá la URL directa"
    echo
    echo -e "${W}${B}── Comandos útiles ──────────────────────────────────${NC}"
    echo -e "  ${C}pm2 status${NC}                       Estado"
    echo -e "  ${C}pm2 logs ao-chat${NC}                  Logs en tiempo real"
    echo -e "  ${C}pm2 restart ao-chat${NC}               Reiniciar"
    echo -e "  ${C}pm2 logs ao-chat --lines 50 --nostream${NC}  Ver últimas líneas"
    echo
    echo -e "${W}${B}── Desinstalar ───────────────────────────────────────${NC}"
    echo -e "  ${C}sudo bash ${PROJECT_DIR}/installer/uninstall.sh${NC}"
    echo
    [[ $ERRS -gt 0 ]] && warn "${ERRS} advertencia(s) durante la instalación. Ver: $LOG"
    line
    echo -e "  ${M}¡El mundo de Argentum Online te espera, aventurero!${NC}"
    echo
}

# ─────────────────────────────────────────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────────────────────────────────────────
main() {
    require_root
    check_project
    : > "$LOG"
    _log "=== AO Chat Instalador v3.3 ==="
    _log "PROJECT_DIR=$PROJECT_DIR"
    _log "NODE=$(node -v 2>/dev/null || echo 'no encontrado')"

    welcome
    config
    deps
    database
    app
    firewall
    start
    final
}

main "$@"
